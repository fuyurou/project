let cf = require("../config.js");
module.exports = {
  // 获取主卡数据列表
  getzmklist: {
    url: cf.config.configUrl + "zmk/getzmklist",
    data: {
      wid: cf.config.wid
    },
    method: 'POST'
  },
  // 获取副卡数据列表
  getzmkorderchildren: {
    url: cf.config.configUrl + "zmk/getzmkorderchildren",
    data: {
      wid: cf.config.wid
    },
    method: 'POST'
  },
  // 获取介绍数据列表
  getinfo: {
    url: cf.config.configUrl + "business/getinfo",
    data: {
      wid: cf.config.wid
    },
    method: 'POST'
  },
  // 点击领取母卡接口
  postzmkorder: {
    url: cf.config.configUrl + "zmk/postzmkorder",
    data: {
      wid: cf.config.wid
    },
    method: 'POST'
  },
  // 点击领取母卡接口
  getzmkorderchildreninfo: {
    url: cf.config.configUrl + "zmk/getzmkorderchildreninfo",
    data: {
      wid: cf.config.wid
    },
    method: 'POST'
  },
  // 点击领取子卡
  postzmkorderchildren: {
    url: cf.config.configUrl + "zmk/postzmkorderchildren",
    data: {
      wid: cf.config.wid
    },
    method: 'POST'
  },
  checkzmkorderchildren: {
    url: cf.config.configUrl + "zmk/checkzmkorderchildren",
  data: {
    wid: cf.config.wid
  },
  method: 'POST'
},
};