let cf = require("../config.js");
module.exports = {
  getvipconfall: {
    url: cf.config.configUrl + "vip/getvipconfall",
    data: {
      uid: cf.config.wid,
    },
    method: 'POST'
  },
  getvipconf:{
    url: cf.config.configUrl + "vip/getvipconf",
  data: {
    uid: cf.config.wid,
  },
  method: 'POST'
  },
  pay: {
    url: cf.config.configUrl + "vip/wexin/pay",
    data: {
      uid: cf.config.wid,
    },
    method: 'POST'
  },
  buyvip: {
    url: cf.config.configUrl + "vip/buyvip",
    data: {
      uid: cf.config.wid,
    },
    method: 'POST'
  },
  paystatus: {
    url: cf.config.configUrl + "vip/wexin/pay",
    data: {
      uid: cf.config.wid,
    },
    method: 'POST'
  },
  checkone: {
    url: cf.config.configUrl + "vip/voucher/checkone",
    data: {
      uid: cf.config.wid,
    },
    method: 'POST'
  },
  getmyvoucher: {
    url: cf.config.configUrl + "voucher/getmyvoucher",
    data: {
      wid: cf.config.wid,
    },
    method: 'POST'
  }
};