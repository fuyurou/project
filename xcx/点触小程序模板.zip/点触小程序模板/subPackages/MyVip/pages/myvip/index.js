const App = getApp();
var vipCardAPI = require('../../../../api/vipCardAPI');
Page({
  data: {
    listytpe:{'type':0,'p':1,'totalP':1},
    myvoucher:[],
    myvoucher0: [],
    ListSorts:0,
    postpw: {}
  },
  onLoad(options) {
  },
  onShow(){
    App.GetUserInfo(this.getmyvoucher());
  },
  ListType(e) {
    const thistype = parseInt(e.currentTarget.dataset.id);
    this.setData({
      myvoucher:[],
      myvoucher0: [],
      'listytpe.type': thistype,
      'listytpe.p': 1,
      'listytpe.totalP': 1,
      ListSorts:'0'
    })
    this.getmyvoucher();
  },
  ListSorts(e){
    const thistype = e.currentTarget.dataset.id;
    this.setData({
      myvoucher:[],
      'listytpe.p': 1,
      'listytpe.totalP': 1,
      ListSorts: thistype
    })
    //this.setData({ ListSorts: thistype})
    this.getmyvoucher();
  },
  ShowListSorts(thistype){
    const myvoucher0 = this.data.myvoucher0;
    //console.log(myvoucher0);
    if (thistype == ''){
      this.setData({ myvoucher: myvoucher0 })
    }else{
      let listdb = new Array();
      var j = 0;
      for (var i = 0; i < myvoucher0.length; i++) {
        if (myvoucher0[i]['fromkey'] == thistype){
          listdb[j] = myvoucher0[i];
          j++
        }
      }
      this.setData({ myvoucher: listdb })
    }
  },
  telCall(e) {
    const tel = e.currentTarget.dataset.id;
    wx.makePhoneCall({
      phoneNumber: tel
    })
  },
  getmyvoucher() {
    let t = this;
    const listytpe = t.data.listytpe;
    let page = listytpe.p;
    let apiObj = vipCardAPI.getmyvoucher;
    apiObj.data.openid = App.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.p = page;
    apiObj.data.isused = listytpe.type,
    apiObj.data.fromkey = t.data.ListSorts,
    apiObj.success = function (resp) {
      console.log('getmyvoucher', resp);
      const datas = resp.data;
      const myvoucher = t.data.myvoucher;
      let listdb = datas.myvoucherlist;
      for (var i = 0; i < listdb.length; i++) {
        listdb[i]['lastuse_time'] = App.get_date_time(listdb[i]['lastusetime']);
      }
      let myvoucher1 = [...myvoucher, ...listdb]
      const totaP = datas.pagearray?datas.pagearray.total_page:0;
      console.log(myvoucher1);
      t.setData({
        'listytpe.p': page + 1,
        'listytpe.totalP': totaP,
        myvoucher: myvoucher1
      })
    };
    wx.request(apiObj);    
  },
  //页面上拉触底事件的处理函数
  onReachBottom() {
    this.getmyvoucher();
  },
  show_return(msg) {
    wx.showModal({
      title: '友情提示',
      content: msg,
    })
  },
  userCar(e) {
    const index = parseInt(e.currentTarget.dataset.index);
    const thisCar = this.data.myvoucher[index];
    const nowtime = parseInt(new Date().getTime() / 1000);
    if (thisCar.aftercanuse > nowtime ) {  
      var note1 = '';
      if (thisCar.voucher_checkonce == '2'){
        note1 = '每天只能用一次';
      } else if (thisCar.voucher_checkonce == '3') {
        note1 = '每周只能用一次';
      } else if (thisCar.voucher_checkonce == '4') {
        note1 = '每月只能用一次';
      }
      this.setData({
        postpw: {
          'showbox': 1, 'nouse': 1, 'name': '当前卡券还不能使用', 'note1': note1, 'time': App.get_date_time(thisCar.aftercanuse) }
      })
      return;
    }
    const dataset = e.currentTarget.dataset;
    console.log(thisCar)
    this.setData({
      surplus: thisCar.surplus,
      postpw: { 'orderid': dataset.id, 'vipId': dataset.vipid, 'showbox': 1, 'pw': '', 'num': 1, 'name': '请输入使用密码' }
    })
  },
  HidePostpw() {
    this.setData({
      postpw: {}
    })
  },
  MoveUseNum() {
    let num = this.data.postpw.num;
    if (num < 2) {
      this.show_return('使用数量必须是大于1！');
    } else {
      num--;
    }
    this.setData({ 'postpw.num': num })
  },
  AddUseNum() {
    this.setData({ 'postpw.num': this.data.postpw.num + 1 })
  },
  numChange(e) {
    let num = e.detail.value;
    if (!this.checkInt(num)) {
      this.show_return('使用数量必须是大于1的整数！');
      num = 1;
    }
    this.setData({ 'postpw.num': num })
  },
  checkInt(num) {
    let pat = new RegExp('^[0-9]+$');
    return pat.test(num)
  },
  CheckPostpw() {
    const pwinfo = this.data.postpw;
    if (!pwinfo.orderid) {
      this.show_return('没有指定使用的卡券');
      return;
    }
    if (pwinfo.pw == '') {
      this.show_return('没有输入使用密码');
      return;
    }
    if (pwinfo.num > this.data.surplus) {
      this.show_return('次数不足');
      return;
    }
    let t = this;
    let apiObj = vipCardAPI.checkone;
    let postpw = t.data.postpw;
    apiObj.data.openid = App.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.vip_id = t.data.postpw.orderid;
    apiObj.data.voucherorderid = t.data.postpw.vipId;
    apiObj.data.checkpwd = pwinfo.pw;
    apiObj.data.vouchernum = pwinfo.num;
    apiObj.success = function (resp) {
      console.log(resp.data.meta)
      const meta = resp.data.meta;
      console.log(meta)
      if (meta.code == 1) {
        t.show_return(meta.message);
        return;
      } else {
        t.show_return(meta.message);
        t.setData({
          myvoucher: [],
          listytpe: { 'type': t.data.listytpe.type, 'p': 1, 'totalP': 1 }
        })
        t.getmyvoucher();
        t.HidePostpw();
      }
    }
    wx.request(apiObj);
  },
  passChange(e) {
    let givepwd = e.detail.value;
    this.setData({ 'postpw.pw': givepwd })
  },
})