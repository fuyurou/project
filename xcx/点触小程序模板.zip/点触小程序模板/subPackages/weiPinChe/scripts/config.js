module.exports = {
  pathPrefix:'/subPackages/weiPinChe/'
};