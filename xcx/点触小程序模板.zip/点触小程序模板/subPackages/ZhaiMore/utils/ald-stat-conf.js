exports.app_key = "64a7f2b033fb593a8598bbc48c3b8486", exports.getLocation = !1, 
exports.getUserinfo = !1, exports.appid = "", exports.appsecret = "", exports.defaultPath = "pages/index/index";