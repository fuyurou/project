const App = getApp()
var priAPI = require('../../../../api/priAPI');
Page({
  data: {
    userinfo: {},
    showTypes: 1,
    activeIndex: 0,
    prinownum: 0,
    primaxnum: 0,
    priinfos: [],
    showmores: 1,
    postzmkorder: 0,
    postzmkorder1: 0,
    givepwd: '',
    zmkid: 0,
    zmkorderid: 0,
    childorder: {},
    myzmkorders: [],
    checkzmk: { id: 0, show: 0 },
    baseinfo: {},
  },
  onLoad(option) {
    if ('show' in option) {
      console.log(option.show);
    }
    if ('shows' in option) {
      this.setData({ showTypes: option.shows })
    }
    // this.checkLogin();
  },
  onShow() {
    this.setData({ showTypes: 1 })
    App.GetUserInfo(this.priinfos);
  },
  //打电话
  topPhoneCall() {
    wx.makePhoneCall({
      phoneNumber: this.data.baseinfo.contact_tel
    })
  },
  //打开地图
  topOpenMap() {
    const baseinfo = this.data.baseinfo;
    var maparr = baseinfo.contact_map.split(",");
    const latitude = parseFloat(maparr[0]);
    const longitude = parseFloat(maparr[1]);
    wx.openLocation({
      latitude: latitude,
      longitude: longitude,
      scale: 18,
      name: baseinfo.fullname,
      address: baseinfo.contact_address
    })
  },
  //下拉刷新
  onPullDownRefresh() {
    this.priinfos();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
  priinfos() {
    let t = this;
    let apiObj = priAPI.getzmklist;
    apiObj.data.openid = App.globalData.UserInfo.WeiXinOpenId;
    apiObj.success = function (resp) {
      const datas = resp.data;
      if (!datas.meta) {
        let zmklist = datas.zmklist;
        if (zmklist.length > 0) {
          for (var i = 0; i < zmklist.length; i++) {
            zmklist[i]['timestart'] = App.get_date_time(Date.parse(zmklist[i]['start_time']) / 1000);
            zmklist[i]['timeend'] = App.get_date_time(Date.parse(zmklist[i]['end_time']) / 1000);
            var childnum = parseInt(zmklist[i]['children_num']);
            if (childnum > 0) {
              zmklist[i]['starts'] = new Array(childnum);
            }
            var myorder = zmklist[i]['myorder'];
            if (zmklist[i]['children_orders'] == false) {
              var thisorders = new Array();
              for (var j = 0; j < parseInt(zmklist[i]['children_num']); j++) {
                thisorders[j] = j;
              }
              zmklist[i]['childrenorders'] = thisorders;
            } else {
              zmklist[i]['childrenorders'] = zmklist[i]['children_orders'];
            }
          }
          const prinownum = parseInt(t.data.prinownum); //console.log(zmklist);
          t.setData({ priinfos: zmklist, primaxnum: zmklist.length - 1, childorder: zmklist[prinownum] })
        }
      } else {
        wx.showModal({
          title: '友情提示',
          content: datas.meta.message,
        })
      }
    };
    wx.request(apiObj);
  },
  HideZmkorder() {
    this.setData({ givepwd: '', postzmkorder: 0 })
  },
  passChange(e) {
    let givepwd = e.detail.value;
    this.setData({ givepwd: givepwd })
  },
  bindChange(e) {
    var current = parseInt(e.detail.current);
    const priinfos = this.data.priinfos;
    this.setData({
      prinownum: current,
      childorder: priinfos[current]
    })
  },
  showTypes(e) {
    this.setData({
      showTypes: parseInt(e.currentTarget.dataset.id)
    })
  },
  showTypes2() {
    wx.navigateTo({ url: '/subPackages/Pri/pages/myorder/index' })
  },
  showmores(e) {
    this.setData({
      showmores: parseInt(e.currentTarget.dataset.id)
    })
  },
  receive_pri(e) {
    const checkzmk = e.currentTarget.dataset;
    console.log(checkzmk)
    this.setData({
      postzmkorder: 1, 
      zmkid: checkzmk.id,
    })
  },
  PostZmkorder() {
    if (this.data.zmkid == 0) {
      this.show_return('没有选中要领取的主卡');
      return;
    }
    if (this.data.givepwd == '') {
      this.show_return('请输入领到密码');
      return;
    }
    let t = this;
    let apiObj = priAPI.postzmkorder;
    apiObj.data.openid = App.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.zmkid = t.data.zmkid;
    apiObj.data.checkpwd = t.data.givepwd;
    apiObj.success = function (resp) {
      const datas = resp.data;
      if (datas.meta.code == 1) {
        t.show_return(datas.meta.message);
      } else {
        wx.showModal({
          title: '友情提示',
          content: '恭喜您主卡领取成功',
          success: function () {
            t.HideZmkorder()
            t.priinfos()
          }
        })
      }
    };
    wx.request(apiObj);
  },
  show_return(msg) {
    wx.showModal({
      title: '友情提示',
      content: msg,
    })
  },
  ShowNext() {
    const prinownum = this.data.prinownum;
    if (prinownum < this.data.primaxnum) {
      this.setData({
        prinownum: prinownum + 1,
        activeIndex: prinownum + 1
      })
    }
  },
  ShowPrav() {
    const prinownum = this.data.prinownum;
    if (prinownum > 0) {
      this.setData({
        prinownum: prinownum - 1,
        activeIndex: prinownum - 1
      })
    }
  },
  checkzmkorderchildren(e) {
    const checkzmk = e.currentTarget.dataset;
    console.log(checkzmk)
    this.setData({
      'checkzmk.id': checkzmk.id,
      'checkzmk.show': 1
    })
  },
  showFuCar(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/subPackages/Pri/pages/share/index?id={{id}}'})
    //console.log(id);
  },
  HideCheckzmk() {
    this.setData({
      'checkzmk.id': 0,
      'checkzmk.show': 0,
      givepwd: ''
    })
  },
  PostCheckzmk() {
    let t = this;
    const checkzmk = t.data.checkzmk;
    console.log(checkzmk)
    if (checkzmk.id == 0) {
      t.show_return('没有对应的副卡');
      return;
    }
    if (t.data.givepwd == '') {
      t.show_return('请输入核销密码');
      return;
    }
    let apiObj = priAPI.checkzmkorderchildren;
    apiObj.data.openid = App.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.type = '1';
    apiObj.data.zmkorderchildrenid = checkzmk.id;
    apiObj.data.checkpwd = t.data.givepwd;
    apiObj.success = function (resp) {
      const meta = resp.data.meta;
      if (meta.code == 1) {
        t.show_return(meta.message);
        return;
      } else {
        t.show_return(meta.message);
        t.priinfos();
        t.HideCheckzmk();
      }
    };
    wx.request(apiObj);
  },
  checkzmkorder(e) {
    console.log(e)
    const id = parseInt(e.currentTarget.dataset.id);
    this.setData({ postzmkorder1: 1, zmkorderid: id })
  },
  HideCheckzmkorder() {
    this.setData({ postzmkorder1: 0, zmkorderid: 0, givepwd: '' })
  },
  PosCheckzmkorder() {
    let t = this;
    const checkzmk = t.data.checkzmk;
    if (t.data.zmkorderid == 0) {
      t.show_return('没有选中要核销的主卡');
      return;
    }
    if (t.data.givepwd == '') {
      t.show_return('请输入核销密码');
      return;
    }
    let apiObj = priAPI.checkzmkorderchildren;
    apiObj.data.openid = App.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.type = '1';
    apiObj.data.zmkorderchildrenid = this.data.childorder.myorder.id;
    apiObj.data.child_mother_card_id = this.data.zmkorderid;
    apiObj.data.checkpwd = this.data.givepwd;
    apiObj.success = function (resp) {
      const datas = resp.data;
      if (datas.meta.code == 1) {
        t.show_return(datas.meta.message);
      } else {
        wx.showModal({
          title: '友情提示',
          content: '恭喜您主卡核销成功',
        })
        t.HideCheckzmkorder();
        t.priinfos();
      }
    };
    wx.request(apiObj);
  },
})