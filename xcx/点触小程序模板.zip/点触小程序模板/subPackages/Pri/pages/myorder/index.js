const App = getApp()
var priAPI = require('../../../../api/priAPI');
Page({
  data: {
    givepwd: '',
    myzmkorders: [],
    baseinfo: {},
    checkzmk: { id: 0, show: 0 }
  },
  onLoad(options) {
    App.GetUserInfo(this.getmyzmkorders());
  },
  showFuCar(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/subPackages/Pri/pages/share/index?id=' + id })
  },
  //打电话
  topPhoneCall() {
    wx.makePhoneCall({
      phoneNumber: this.data.baseinfo.contact_tel
    })
  },
  //打开地图
  topOpenMap() {
    const baseinfo = this.data.baseinfo;
    var maparr = baseinfo.contact_map.split(",");
    const latitude = parseFloat(maparr[0]);
    const longitude = parseFloat(maparr[1]);
    wx.openLocation({
      latitude: latitude,
      longitude: longitude,
      scale: 18,
      name: baseinfo.fullname,
      address: baseinfo.contact_address
    })
  },
  getmyzmkorders() {
    let t = this;
    let apiObj = priAPI.getzmkorderchildren;
    apiObj.data.openid = App.globalData.UserInfo.WeiXinOpenId;
    apiObj.success = function (resp) {
      const data = resp.data;
      if (data.zmkorderchildren.length > 0) {
        t.setData({
          myzmkorders: data.zmkorderchildren,
          baseinfo: data.shopInfo,
        })
      } else {
        t.setData({ myzmkorders: null })
      }
    };
    wx.request(apiObj);
  },
  passChange(e) {
    let givepwd = e.detail.value;
    this.setData({ givepwd: givepwd })
  },
  showTypes() {
    wx.navigateTo({ url: '/subPackages/Pri/pages/pri/index' })
  },
  checkzmkorderchildren(e) {
    const checkzmk = e.currentTarget.dataset;
    console.log('checkzmk', checkzmk)
    this.setData({
      'checkzmk.id': checkzmk.id,
      'checkzmk.cardId': checkzmk.cardid,
      'checkzmk.show': 1
    })
  },
  HideCheckzmk() {
    this.setData({
      'checkzmk.id': 0,
      'checkzmk.show': 0,
      givepwd: ''
    })
  },
  PostCheckzmk() {
    let t = this;
    const checkzmk = t.data.checkzmk;
    if (checkzmk.id == 0) {
      t.show_return('没有对应的副卡');
      return;
    }
    if (this.data.givepwd == '') {
      t.show_return('请输入核销密码');
      return;
    }
    let apiObj = priAPI.checkzmkorderchildren;
    apiObj.data.openid = App.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.type='2';
    apiObj.data.zmkorderchildrenid = checkzmk.id;
    apiObj.data.child_mother_card_id = checkzmk.cardId;
    apiObj.data.checkpwd = t.data.givepwd;
    apiObj.success = function (resp) {
      const meta = resp.data.meta;
      console.log(meta);
      if (meta.code == 1) {
        t.show_return(meta.message);
        return;
      } else {
        t.show_return(meta.message);
        t.getmyzmkorders();
        t.HideCheckzmk();
      }
    };
    wx.request(apiObj);
  },
  show_return(msg) {
    wx.showModal({
      title: '友情提示',
      content: msg,
    })
  },

})