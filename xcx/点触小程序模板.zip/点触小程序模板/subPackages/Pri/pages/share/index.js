const App = getApp()
var priAPI = require('../../../../api/priAPI');
Page({
  data: {
    userinfo: {},
    zmkorders: {},
    xcxOpenId: null,
    id: 81
  },
  onLoad(option) {
    if ('id' in option) {
      this.setData({
        id: option.id
      })
    }
  },
  onShow: function () {
    App.GetUserInfo(this.getzmkorders());
  },
  getzmkorders() {
    this.setData({
      xcxOpenId: App.globalData.UserInfo.WeiXinOpenId,
    })
    let t = this;
    let apiObj = priAPI.getzmkorderchildreninfo;
    apiObj.data.openid = App.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.zmkorderchildrenid = t.data.id;
    apiObj.success = function (resp) {
      wx.hideLoading();
      const datas = resp.data;
      if (datas.meta.code == 0) {
        const datainfo = datas.data;
        t.setData({
          zmkorders: datainfo[0]
        })
      } else {
        wx.showModal({
          title: '提示',
          content: '没有相应的副卡！',
        })
      }
    };
    wx.request(apiObj);
  },
  postzmkorderchildren() {
    const zmkorders = this.data.zmkorders;
    let t = this;
    let apiObj = priAPI.postzmkorderchildren;
    apiObj.data.openid = App.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.child_id = t.data.id;
    apiObj.data.zmkorderid = t.data.zmkorders.child_mother_card_id,
      apiObj.success = function (resp) {
      console.log(resp)
      const data = resp.data;
      console.log(resp.data)
      if (data.meta.code == 1) {
          t.pay(data.data);
        } else {
          wx.showModal({
            title: '提示',
            content: data.meta.message
          })
          t.getzmkorders();
        }
      };
    wx.request(apiObj);
  },
  //进入支付
  pay(result) {
    let that = this;
    wx.requestPayment({
      'timeStamp': result.timeStamp,
      'nonceStr': result.nonceStr,
      'package': result.package,
      'signType': result.signType,
      'paySign': result.paySign,
      success: function (res) {
        wx.showLoading({
          title: '支付成功',
        })
        that.getzmkorders();
      },
      fail: function (res) {
        console.log('支付失败');
      }
    })
  },
  onShareAppMessage: function (ops) {
    let title = this.data.zmkorders.nickname + "特意送您《" + this.data.zmkorders.children_name + "》";
    let path = '/subPackages/Pri/pages/share/index?id=' + this.data.id + '&foruid=' + App.globalData.UserInfo.WeiXinOpenId;
    console.log(path);
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: title,
      path: path,
      success: function (res) {
        console.log("转发成功:");
      },
      fail: function (res) {
        console.log("转发失败:");
      }
    }
  }
})