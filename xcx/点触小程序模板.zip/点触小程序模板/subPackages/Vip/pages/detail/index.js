const App = getApp()
var vipCardAPI = require('../../../../api/vipCardAPI');
Page({
  data: {
    userinfo: {},
    vipsetid: 1,
    orderid: null,
    OpenId:null,
    foruid: 0,
    vipinfo: {},
    vipgifts: [],
    vipuniongifts: [],
    union_num: 0,
    showType: 1,
    postpw: {},
    NoteWord: '',
    cksort: '0',
    nowDateTime: parseInt(new Date().getTime() / 1000),
    goingtime: 0,
    setInter: '',
    setInter1: '',
  },
  onLoad(options) {
    console.log(options)
    if ('vipsetid' in options) {
      this.setData({ vipsetid: options.vipsetid })
    }
    if ('orderid' in options) {
      this.setData({ orderid: options.orderid });
    }
    if ('OpenId' in options) {
      this.setData({ OpenId: options.OpenId });
    }
    if ('foruid' in options) {
      this.setData({ foruid: options.foruid });
    }
  },
  onShow() {
    App.GetUserInfo(this.getVipInfo());
  },
  onHide() {
    //页面隐藏清除检测卡券核销状态
    clearInterval(this.data.setInter1);
  },
  onUnload() {
    //页面卸载清除检测卡券核销状态
    clearInterval(this.data.setInter1);
  },
  telCall(e) {
    const tel = e.currentTarget.dataset.id;
    wx.makePhoneCall({
      phoneNumber: tel
    })
  },
  showunionsort(e) {
    const id = e.currentTarget.dataset.id;
    const vipuniongifts = this.data.vipinfo._union_gift;
    if (id == '0') {
      this.setData({ cksort: id, vipuniongifts: vipuniongifts })
    } else {
      var newarray = new Array();
      var j = 0;
      for (var i = 0; i < vipuniongifts.length; i++) {
        if (vipuniongifts[i]['union_sortid'] == id) {
          newarray[j] = vipuniongifts[i];
          j++;
        }
      }
      this.setData({ cksort: id, vipuniongifts: newarray })
    }
  },
  showUnions() {
    this.setData({ showType: 2 })
  },
  showUnions1() {
    this.setData({ showType: 1 })
  },
  getVipInfo() {
    let t = this;
    let apiObj = vipCardAPI.getvipconf;
    apiObj.data.oid = App.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.vipsetid = t.data.vipsetid;
    if (t.data.orderid) {
      apiObj.data.order_id = t.data.orderid;
    }
    apiObj.data.share_openid = t.data.OpenId;
    console.log('apiObj.data',apiObj.data)
    apiObj.success = function (resp) {
      console.log('resp', resp);
      const datas = resp.data;
      if (datas.meta.code == 0) {
        const thisvip = datas.data;
        if (thisvip._gifts) {
          t.setData({ vipgifts: thisvip._gifts })
        }
        if (thisvip._union_gift) {
          let unions = thisvip._union_gift;
          t.setData({
            vipuniongifts: unions,
            union_num: unions.length
          })
        }
        if (thisvip._give_share_gift) {
          t.setData({ vipsharegifts: thisvip._give_share_gift })
        }
          t.setData({ vipinfo: thisvip, })
        console.log(thisvip.vipbgcolor);
        t.format_showtime();
        wx.setNavigationBarColor({
          frontColor: '#ffffff', // 必写项
          backgroundColor: thisvip.vipbgcolor, // 必写项           
        })

      } else {
        this.setData({ NoteWord: datas.meta.message, })
      }
      wx.hideLoading()
    };
    wx.request(apiObj);
  },
  format_showtime() {
    const that = this;
    clearInterval(that.data.setInter);
    that.setData({
      nowDateTime: parseInt(new Date().getTime()),
      goingtime: 0
    })
    that.data.setInter = setInterval(
      function () {
        let vipinfo = that.data.vipinfo;
        var goingtime = that.data.goingtime;
        const nowDateTime = that.data.nowDateTime + goingtime;
        var startime = Date.parse(vipinfo.vip_card_start_time) - nowDateTime;
        if (startime <= 0) {
          vipinfo.is_start = 1;
          vipinfo.show_start = '活动已经开始';
        } else {
          vipinfo.is_start = 0;
          vipinfo.startarr = App.format_time1(startime);
        }
        var endtime = Date.parse(vipinfo.vip_card_end_time) - nowDateTime;
        if (endtime <= 0) {
          vipinfo.is_end = 1;
          vipinfo.show_end = '活动已经结束';
        } else {
          vipinfo.is_end = 0;
          vipinfo.endtimarr = App.format_time1(endtime);
        }
        that.setData({ vipinfo: vipinfo });
        goingtime += 1;
        that.setData({ vipinfo: vipinfo, goingtime: goingtime });
      }, 1000);
  },
  userCar1(e) {
    const index = parseInt(e.currentTarget.dataset.id);
    const thisCar = this.data.vipgifts[index];
    this.setData({
      surplus: thisCar.surplus,
    }, () => {
      this.userCar(thisCar);
    })
  },
  userCar2(e) {
    const index = parseInt(e.currentTarget.dataset.id);
    const thisCar = this.data.vipuniongifts[index];
    console.log(thisCar);
    this.setData({
      surplus: thisCar.surplus,
    }, () => {
      this.userCar(thisCar);
    })
  },
  userCar(thisCar) {
    const nowtime = parseInt(new Date().getTime() / 1000);
    if (thisCar.aftercanuse > nowtime) {
      var note1 = '';
      if (thisCar.voucher_checkonce == '2') {
        note1 = '每天只能用一次';
      } else if (thisCar.voucher_checkonce == '3') {
        note1 = '每周只能用一次';
      } else if (thisCar.voucher_checkonce == '4') {
        note1 = '每月只能用一次';
      }
      this.setData({
        postpw: { 'showbox': 1, 'nouse': 1, 'name': '当前卡券还不能使用', 'note1': note1, 'time': App.get_date_time(thisCar.aftercanuse) }
      })
      return;
    }
    const id = parseInt(thisCar.id);
    this.setData({
      postpw: { 'orderid': id, 'showbox': 1, 'pw': '', 'num': 1, 'name': '使用当前卡券' }
    })
  },
  uservoucherover() {
    const that = this;
    clearInterval(that.data.setInter1);
    var limittime = 0;
    that.data.setInter1 = setInterval(
      function () {
        limittime += 2;
        if (limittime > 120) {
          that.HidePostpw();
        }
        const erkey = that.data.postpw.erkey;
        const url = App.__config.basePath + '/smallprogramapi/voucher/uservoucherstatus';
        wx.request({
          url: url,
          data: { 'erkey': erkey },
          method: "POST",
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            if (res.data.meta.code == 0) {
              that.HidePostpw();
              App.WxService.showModal({
                title: '提示！',
                content: '核销成功',
                showCancel: !1,
              })
                .then(data => {
                  that.getVipInfo();
                })
            }
          }
        })
      }, 2000);
  },
  HidePostpw() {
    clearInterval(this.data.setInter1);
    this.setData({
      postpw: {}
    })
  },
  passChange(e) {
    let givepwd = e.detail.value;
    this.setData({ 'postpw.pw': givepwd })
  },
  MoveUseNum() {
    let num = this.data.postpw.num;
    if (num < 2) {
      this.show_return('使用数量必须是大于1！');
    } else {
      num--;
    }
    this.setData({ 'postpw.num': num })
  },
  AddUseNum() {
    this.setData({ 'postpw.num': this.data.postpw.num + 1 })
  },
  numChange(e) {
    let num = e.detail.value;
    if (!this.checkInt(num)) {
      this.show_return('使用数量必须是大于1的整数！');
      num = 1;
    }
    this.setData({ 'postpw.num': num })
  },
  checkInt(num) {
    let pat = new RegExp('^[0-9]+$');
    return pat.test(num)
  },
  CheckPostpw() {
    const pwinfo = this.data.postpw;
    if (!pwinfo.orderid) {
      this.show_return('没有指定使用的卡券');
      return;
    }
    if (pwinfo.pw == '') {
      this.show_return('没有输入使用密码');
      return;
    }
    if (pwinfo.num > this.data.surplus) {
      this.show_return('次数不足');
      return;
    }
    let t = this;
    let apiObj = vipCardAPI.checkone;
    apiObj.data.openid = App.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.vip_id = this.data.vipinfo.myorder.id;
    apiObj.data.voucherorderid = pwinfo.orderid;
    apiObj.data.checkpwd = pwinfo.pw;
    apiObj.data.vouchernum = pwinfo.num;
    apiObj.success = function (resp) {
      const meta = resp.data.meta;
      if (meta.code == 1) {
        t.show_return(meta.message);
        return;
      } else {
        wx.showModal({
          title: '友情提示',
          content: meta.message,
          success: function (res) {
            if (res.confirm) {
              t.getVipInfo();
              t.HidePostpw();
            } else if (res.cancel) {
              t.getVipInfo();
              t.HidePostpw();
            }
          }
        })
      }
    }
    wx.request(apiObj);
  },
  show_return(msg) {
    wx.showModal({
      title: '友情提示',
      content: msg,
    })
  },
  buyvip() {
    let t = this;
    let apiObj = vipCardAPI.buyvip;
    apiObj.data.openid = App.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.share_openid = t.data.OpenId;
    apiObj.data.vipsetid = this.data.vipsetid;
    apiObj.success = function (resp) {
      const datas = resp.data;
      if (datas.meta.code == 0) {
        const orders = datas.data;
        t.gotopay(orders);
      } else {
        wx.showModal({
          title: '提示！',
          content: datas.meta.message,
        })
      }
    }
    wx.request(apiObj);
  },
  //进入支付
  gotopay(orders) {
    let paymoney = parseFloat(orders.pay_money);
    if (paymoney > 0 && orders.id != '') {
      let t = this;
      let apiObj = vipCardAPI.pay;
      apiObj.data.oid = App.globalData.UserInfo.WeiXinOpenId;
      apiObj.data.vipsetid = orders.vipid;
      apiObj.data.title = orders.vip_card_name
      apiObj.data.pricetotal = paymoney;
      apiObj.data.table = 'viporder';
      apiObj.data.tableid = orders.id;
      apiObj.success = function (resp) {
        const datas = resp.data;
        if (datas.meta.code == 0) {
          const paydata = datas.data;
          t.pay(paydata);
        } else {
          wx.showModal({
            title: '出错了!',
            content: datas.meta.message,
          })
        }
      }
      wx.request(apiObj);
    }
  },
  pay(result) {
    let that = this;
    wx.requestPayment({
      'timeStamp': result.timeStamp,
      'nonceStr': result.nonceStr,
      'package': result.package,
      'signType': result.signType,
      'paySign': result.paySign,
      success: function (res) {
        wx.showLoading({
          title: '支付成功',
        })
        that.getVipInfo();
        // that.paystatus(result.ordersn);
      },
      fail: function (res) {
      }
    })
  },
  paystatus(ordersn) {
    const that = this;
    const url = App.HttpResource('/smallprogramapi/weixin/paystatus')
    url.queryAsync({
      'ordersn': ordersn,
      'openid': that.data.userinfo.wx_openid
    })
      .then(res => {
        if (res.data.meta.code == 0) {
          wx.hideLoading();
          that.getVipInfo();
        } else {
          setTimeout(function () {
            that.paystatus(ordersn);
          }, 500)
        }
      })
  },
  onShareAppMessage: function (ops) {
    let title = App.globalData.UserInfo.NickName + "邀请您加入《" + this.data.vipinfo.vip_card_name + "》";
    let path = '/subPackages/Vip/pages/detail/index?vipsetid=' + this.data.vipsetid + '&OpenId=' + App.globalData.UserInfo.WeiXinOpenId;
    console.log(path)
    return {
      title: title,
      path: path,
      success: function (res) {
        console.log("转发成功:");
      },
      fail: function (res) {
        console.log("转发失败:");
      }
    }
  },
  //下拉刷新
  onPullDownRefresh() {
    this.getVipInfo();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
  usertype(e) {
    this.setData({
      'postpw.usertype': e.currentTarget.dataset.id
    })
  }
})