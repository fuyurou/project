const App = getApp()
Page({
  data: {
    vipinfo: []
  },
  onLoad(options) {
    this.getVipInfo();
  },
  getVipInfo() {
    const url = App.HttpResource('/Smallprogramapi/Store/getgoodslist')
    url.queryAsync()
      .then(res => {
        const datas = res.data;
        const listdb = datas.listdb;
        this.setData({
          vipinfo: listdb,
        })
      })
  },
})