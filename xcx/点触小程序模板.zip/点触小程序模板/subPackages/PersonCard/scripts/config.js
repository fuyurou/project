module.exports = {
  pathPrefix:'/subPackages/PersonCard/'
};