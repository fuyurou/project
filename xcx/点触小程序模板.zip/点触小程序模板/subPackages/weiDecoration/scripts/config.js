module.exports = {
  pathPrefix: '/subPackages/weiDecoration'
};