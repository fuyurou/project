module.exports = {
  pathPrefix:'/subPackages/WeiTrain/'
};