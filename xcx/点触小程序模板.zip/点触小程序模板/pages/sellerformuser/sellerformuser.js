const app = getApp();
const templateMethods = require("../../utils/template_methods.js");
const cfAPI = require("../../api/customFormAPI");
const sellerAPI = require('../../api/sellerAPI');
Page(Object.assign({}, {
  data: {
    recordList: null,//填写过的表单列表
  },
  onLoad() {
    let t = this;
    app.globalData.getTop();
    this.setMenu(this);
    this.loadData();
  },
  loadData() {
    let t = this;
    const api = cfAPI.shopForm;
    wx.request({
      url: api.url,
      data: {
        wid: api.data.wid,
        openid: app.globalData.UserInfo.WeiXinOpenId,
      },
      method: 'POST',
      success(resp) {
        let rData = resp.data;
        let recordList = rData.data;
        console.log(rData);
        recordList.map((text)=>{
          text.formList.map((obj)=>{
            const date = new Date(parseInt(obj.ctime) * 1000).toLocaleString().replace(/:\d{1,2}$/, ' ');;
            obj.ctime2 = date.toLocaleString();
            return obj;
          });
          text.formList = JSON.stringify(text.formList);
          return text;
        });
        console.log(recordList);
        t.setData({
          recordList: recordList,
        });
      }
    });
  },
  reloadData() {
    let t = this;
    t.setData({recordList: null});
    this.loadData();
  },
  Return_H: function () {
    wx.reLaunch({
      url: '/pages/index/index',
    })
  },
}, templateMethods));