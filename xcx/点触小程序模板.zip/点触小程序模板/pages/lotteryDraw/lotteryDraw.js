//index.js
//获取应用实例
const app = getApp();
const dzpApi = require('../../api/dzpAPI');
var $ = require("../../utils/util.js");
var api = require("../../api/indexAPI.js");
var indexapi1 = require('../../api/zhctAPI');
var decodeDataApi = require('../../api/decodeDataAPI');
var templateMethods = require("../../utils/template_methods.js");
Page(Object.assign({}, templateMethods, {
  data: {
    animationData: {
      duration: 3000,
      timingFunction: 'linear',
      rotate: 0
    },
    luckyTop: 0,
    prize: null,
    start: false,
    is_end: -1,
    showFail: false,
    showWin: false,
    luckynumS: -2,
    getPhoneNumber_switch: '2'
  },
  onLoad: function () {
    let t = this;
    let getPhoneNumber_switch_h = wx.getStorageSync('getPhoneNumber_switch_storage');
    if (getPhoneNumber_switch_h) {
      t.setData({
        getPhoneNumber_switch: getPhoneNumber_switch_h
      })
    }
    let luckyTopnum = 0;
    let luckynum = -2;
    setInterval(function () {
      // if (luckyTopnum = -(10 * 54)){
      //   console.log(luckyTopnum)
      // }
      if (luckyTopnum <= -(t.data.dataLenght * 54)) {
        luckyTopnum = 0;
        luckynum =-2;
      } else {
        luckyTopnum-=54;
        luckynum+=1;
      }
      t.setData({
        luckyTop: luckyTopnum,
        luckynumS: luckynum,
      });
    }, 2000);
  },
  loadInfo() {
    let t = this;
    let apiObj = dzpApi.getDzpInfo;
    apiObj.data.openid = app.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.dzpId = t.data.dzpId;
    apiObj.success = function (resp) {
      let respData = resp.data;
      if (respData.status == 'error') {
        wx.showModal({
          title: '错误',
          content: respData.msg,
          showCancel: 0,
        });
        return false;
      }
      let data = respData.data;
      t.setData(data);
      t.setData({
        dataLenght: data.winList.length
      })
    };
    wx.request(apiObj);
  },
  onShow() {
    let pages = getCurrentPages();    //获取加载的页面
    let currentPage = pages[pages.length - 1];    //获取当前页面的对象
    let options = currentPage.options; //如果要获取url中所带的参数可以查看options
    let dzpId = options.dzpId || 0;
    console.log('dzpId', dzpId)
    this.setData({
      dzpId: dzpId,
      path: currentPage.route + '?dzpId=' + dzpId,
    }, () => {
      if (options.openId) {
        let apiObj = dzpApi.share;
        apiObj.data.openid = options.openId;
        apiObj.data.dzpId = dzpId;
        wx.request(apiObj);
      }
      let t = this;
      app.GetUserInfo(function () {
        $.xsr($.makeUrl(api.GetIndexData, null),
          function (res) {
            console.log('首页数据', res.dataList);
            //--------------------
            app.globalData.setTop(res.dataList.indexArray);
            app.globalData.getTop(t);
            t.setMenu(t);
            t.loadInfo();
          });
      });
    })
  },
  animation: function () {
    let t = this;
    let ani = {
      animationData: {
        duration: 0,
        timingFunction: 'linear',
        rotate: 0,
      },
      start: false,
    };
    let prize = t.data.prize;
    if (prize.is_empty == 1) {
      ani.showFail = true;
    } else {
      ani.showWin = true;
    }
    this.setData(ani);
  },
  /*开始转盘 */
  onStartTap: function (e) {
    if (!this.data.prizeList.length) {
      wx.showModal({
        title: '提示',
        content: `抱歉该大转盘没有设置奖品！！！`,
        showCancel: 0
      });
      return;
    }
    if (this.data.start) return;
    let t = this;
    if (t.data.frequency == 0) {
      if (t.data.is_vip == 1) {
        wx.showModal({
          title: '提示',
          content: `继续抽奖将会消耗${t.data.dzpSetting.point_lottery_consume}积分`,
          success(result) {
            if (result.confirm) {
              t.requestLottery();
            }
          }
        });
      } else {
        wx.showModal({
          title: '提示',
          content: `您的抽奖机会已经用完了`,
          showCancel: 0
        });
      }
    } else {
      t.requestLottery(e);
    }

  },
  // 向后台请求抽奖参数
  requestLottery(e) {
    if (this.data.start) return;
    let t = this;
    let apiObj = dzpApi.lottery;
    apiObj.data.openid = app.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.formId = e.detail.formId;
    apiObj.data.dzpId = t.data.dzpId;
    apiObj.data.phone_number = undefined;
    apiObj.data.dzp_generate_code = undefined;
    apiObj.complete = function () {
      wx.hideLoading();
    };
    apiObj.success = function (resp) {
      let respData = resp.data;
      if (respData.status != 'success') {
        if (respData.msg == "请输入大转盘码！"){
          t.setData({
            formId: e.detail.formId,
            postpw: {
              'showbox': 1,
              'name': respData.msg,
            }
          })
          return false;
        }
        wx.showModal({
          title: '提示',
          content: respData.msg,
          showCancel: 0,
        });
        return false;
      }
      let prize = respData.data;
      t.setData({ prize: prize });
      // 计算抽到的prize在页面数据数组中的下标
      let prizeList = t.data.prizeList;
      let idx = 0;
      for (let i = 0; i < prizeList.length; ++i) {
        if (prizeList[i].id == prize.id) {
          idx = i;
          break;
        }
      }
      // 计算要旋转的角度rotate
      let rotate = -(idx * 60 + 360 * 10);
      t.startSpin(rotate);
      t.loadInfo();
    };
    wx.showLoading({ title: '加载中', });
    wx.request(apiObj);
  },
  // 设置旋转参数
  startSpin(rotate) {
    if (this.data.start) return;
    this.setData({
      animationData: {
        duration: 3000,
        timingFunction: 'ease-out',
        rotate: rotate,
      },
      start: true
    });
    setTimeout(this.animation, 3000);
  },
  /*关闭中奖*/
  onSetValueTap: function (e) {
    let dataset = e.currentTarget.dataset;
    let name = dataset.name;
    let value = dataset.value;
    let o = {};
    o[name] = value;
    this.setData(o);
  },
  /*中奖纪录*/
  onNavigateTap: function (e) {
    const dataset = e.detail.target ? e.detail.target.dataset : e.currentTarget.dataset;
    const url = dataset.url;
    wx.navigateTo({
      url: url
    });
  },
  onShareAppMessage(e) {
    let t = this;
    console.log('幸运大转盘', t.data.path + "&openId=" + app.globalData.UserInfo.WeiXinOpenId);
    return {
      title: '幸运大转盘',
      path: t.data.path + "&openId=" + app.globalData.UserInfo.WeiXinOpenId,
      success: (res) => {
        console.log("转发成功", res);
      },
      fail: (res) => {
        console.log("转发失败", res);
      }
    };
  },
  getPhoneNumber_h: function () {
    let t = this;
    wx.setStorageSync('getPhoneNumber_switch_storage', '1');
    t.setData({
      getPhoneNumber_switch: '1'
    })
  },
  getPhoneNumber: function (e) {
    console.log(e);
    var apiPhone = indexapi1.AddUserPhone;
    let that = this;
    console.log(that.data);
    if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
      console.log('授权失败，请点击开始继续~')
      wx.showModal({
        title: '提示',
        showCancel: false,
        content: '授权失败，请点击开始继续~',
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          }
        }
      })
    } else {
      wx.request({
        url: decodeDataApi.decodeUserData.url,
        data: Object.assign({}, {
          encryptedData: e.detail.encryptedData,
          iv: e.detail.iv,
          openid: app.globalData.UserInfo.WeiXinOpenId,
        }, decodeDataApi.decodeUserData.data),
        method: 'POST',
        dataType: 'json',
        success(resp) {
          let data = resp.data;
          console.log('解密成功', resp.data);
          let phoneNumber = data.phoneNumber;
          console.log(phoneNumber);
          console.log(apiPhone.url);
          console.log(apiPhone.data.wid);
          console.log(app.globalData.UserInfo.WeiXinOpenId);
          console.log(phoneNumber);
          wx.request({
            url: apiPhone.url,
            data: {
              wid: apiPhone.data.wid,
              openid: app.globalData.UserInfo.WeiXinOpenId,
              phonenumber: phoneNumber
            },
            method: 'POST',
            dataType: 'json',
            success: function (res) {
              console.log(res)
              console.log('授权成功，请点击开始继续~')
              wx.showModal({
                title: '提示',
                showCancel: false,
                content: '授权成功，请点击开始继续~',
                success(res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                  }
                }
              })
            },
            fail: function (res) {
              console.log(res)
            }
          })
        },
        fail() {
          console.log('解密失败');
        }
      });
    }
  },
  divHeight: function (e) {
    console.log('e', e);
    var winWid = wx.getSystemInfoSync().windowWidth; //获取当前屏幕的宽度
    var imgh = e.detail.height;//图片高度
    var imgw = e.detail.width;//图片宽度
  },
  passChange(e) {
    let givepwd = e.detail.value;
    this.setData({ 'postpw.pw': givepwd })
  },
  phoneChange(e) {
    let givepwd = e.detail.value;
    this.setData({ 'postpw.phone': givepwd })
  },
  HidePostpw() {
    this.setData({
      postpw: {}
    })
  },
  CheckPostpw() {
    const pwinfo = this.data.postpw;
    if (pwinfo.pw == '') {
      this.show_return('没有输入大转盘码');
      return;
    }
    if (pwinfo.phone == '') {
      this.show_return('没有输入手机号');
      return;
    }
    if (this.data.start) return;
    let t = this;
    let apiObj = dzpApi.lottery;
    apiObj.data.openid = app.globalData.UserInfo.WeiXinOpenId;
    apiObj.data.formId = t.data.formId;
    apiObj.data.phone_number = pwinfo.phone;
    apiObj.data.dzp_generate_code = pwinfo.pw;
    apiObj.data.dzpId = t.data.dzpId;
    apiObj.complete = function () {
      wx.hideLoading();
    };
    apiObj.success = function (resp) {
      let respData = resp.data;
      if (respData.status != 'success') {
        wx.showModal({
          title: '提示',
          content: respData.msg,
          showCancel: 0,
        });
        return false;
      }
      t.HidePostpw();
      let prize = respData.data;
      t.setData({ prize: prize });
      // 计算抽到的prize在页面数据数组中的下标
      let prizeList = t.data.prizeList;
      let idx = 0;
      for (let i = 0; i < prizeList.length; ++i) {
        if (prizeList[i].id == prize.id) {
          idx = i;
          break;
        }
      }
      // 计算要旋转的角度rotate
      let rotate = -(idx * 60 + 360 * 10);
      t.startSpin(rotate);
      t.loadInfo();
    };
    wx.showLoading({ title: '加载中', });
    wx.request(apiObj);
  },
}));