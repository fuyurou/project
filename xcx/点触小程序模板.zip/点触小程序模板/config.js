let ext = wx.getExtConfigSync();
let wid=ext.wid;
let configUrl=ext.configUrl;
exports.config = {
  wid: wid,
  ASEkey: "lnlqwynwmolymxnp",
  ASEIv: "1234567812345678",
  configUrl: configUrl
};
// exports.config = {
//   // wid: "190",//wx06f342dd42d1b5e5
//   // wid: "203",//wx8028e88e12022504
//   // wid: "200",
//   wid: "94", //wxeb8924331c6e6f1a
//    ASEkey: "lnlqwynwmolymxnp", 
//    ASEIv: "1234567812345678",
//   // configUrl: "https://weidogs114.941.so/api/vshop/"
//   configUrl: "https://api.941.so/api/vshop/"
// };