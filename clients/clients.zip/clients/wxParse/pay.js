const App = getApp()
function gotopay(totalprice,sn,openid) {
  console.log(totalprice,sn,openid);
}