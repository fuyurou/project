const App = getApp()
Page({
  data: {
    url: null,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    isSetting: false
  },
  onLoad(options) {
    if ('url' in options) {
      let url = unescape(options.url)
      this.setData({
        url: url,
      })
    }
    const that = this;
    // 查看是否授权
    wx.getSetting({
      success: function (res) {
        if (res.authSetting['scope.userInfo']) { 
          that.wechatSignIn(that.goIndex);
        }else{
          that.setData({ isSetting: true })
        }
      }
    })
  },
  bindGetUserInfo: function (e) {
    this.wechatSignIn(this.goIndex);
  },
  goIndex() {
    let url = this.data.url;
    if (url) {
      if (url == '/pages/user/index' || url == '/pages/shop/index' || url == '/pages/pri/index' || url == '/pages/vip/index'){
        App.WxService.switchTab(url)
      }else{
        App.WxService.redirectTo(url);
      }      
    } else {
      App.WxService.switchTab('/pages/index/index')
    }
  },
  //执行微信登录
  wechatSignIn(cb) { 
    let token;
    let encrypteddata;
    let iv;
    App.WxService.login()
      .then(data => {
        token = data.code; 
        if(token){
          return App.WxService.getUserInfo();
        }else{
          this.showModal();
        }         
      }) 
      .then(res => {
        encrypteddata = res.encryptedData;
        iv = res.iv;
        let foruid = App.WxService.getStorageSync('foruid');
        if (encrypteddata && iv){
          const url = App.HttpResource('/smallprogramapi/index/weixinlogin')
          return url.queryAsync({ 'code': token, 'encrypteddata': encrypteddata, 'iv': iv, 'foruid': foruid })
        }else{
          this.showModal();
        }        
      })
      .then(res => {
        const res3 = res.data;
        //执行登录后对返回的数据进行处理
        if (res3.meta.code == 0) {
          App.WxService.setStorageSync('token', res3.data.token);
          App.WxService.setStorageSync('user', res3.data.myUserinfo);
          cb()
        } else if (res3.meta.code == 1) {
          App.WxService.showModal({
            title: res3.meta.message,
            content: res3.data.code,
            showCancel: !1,
          })
        }
      })
  },
  showModal() {
    App.WxService.showModal({
      title: '友情提示',
      content: '获取用户登录状态失败，请重新登录',
      showCancel: !1,
    })
  },
})