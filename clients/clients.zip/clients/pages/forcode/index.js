const App = getApp()
Page({
  data: {
  
  },
  onLoad(option) {
    // option 中的 scene 需要使用 decodeURIComponent 才能获取到生成二维码时传入的 scene
    var scene = decodeURIComponent(option.scene)
    console.log(option);
    if ('foruid' in option) {      
      App.WxService.setStorageSync('foruid', option.foruid);
    }
    if ('tabname' in option){
      App.WxService.switchTab('/pages/' + option.tabname+'/index')
    }else{
      App.WxService.switchTab('/pages/index/index')
    }
    
  }
})