Page({
  data: {
    latitude: 23.099994,
    longitude: 113.324520,
    markers: [{
      id: 1,
      latitude: 23.099994,
      longitude: 113.324520
    }]
  },
  onReady() {
    this.mapctx = wx.createMapContext('map')
  },
  onLoad(option) {
    if ('latitude' in option) {
      this.setData({
        latitude: option.latitude,
      })
    }
    if ('longitude' in option) {
      this.setData({
        longitude: option.longitude
      })
    }
    this.showMap();
  },
  showMap(){
    let markers = this.data.markers;
    for (var i = 0; i < markers.length;i++){
      markers[i]['latitude'] = this.data.latitude;
      markers[i]['longitude'] = this.data.longitude;
    }
    this.setData({
      markers: markers
    })
  },
  click(){
    wx.openLocation({
      latitude: 23.362490,
      longitude: 116.715790,
      scale: 18,
      name: '华乾大厦',
      address: '金平区长平路93号'
    })
  }
})