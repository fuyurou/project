const App = getApp()
Page({
  data: {
    listdb:[],
    nolistdb:1,
    userinfo: App.WxService.getStorageSync('user'),
    nowDateTime: parseInt(new Date().getTime() / 1000),
    goingtime: 0,
    setInter: ''
  },
  onLoad: function (options) {
    //this.get_vipinfo();
  },
  onShow: function () {
    this.get_vipinfo(); 
  },
  get_vipinfo(){
    const userinfo = App.WxService.getStorageSync('user');
    const url = App.HttpResource('/smallprogramapi/vip/getvipconfall')
    url.queryAsync({
      'uid': userinfo.uid
    })
      .then(res => { 
        const datas = res.data;
        let listdb = datas.vipsetdb;
        this.setData({ listdb: listdb }); 
        if (listdb.length>0){
          this.setData({ nolistdb: 0 }); 
        }
        this.format_showtime();
      })
  },
  format_showtime() {
    const that = this;
    clearInterval(that.data.setInter);
    that.setData({
      nowDateTime: parseInt(new Date().getTime() / 1000),
      goingtime: 0
    })
    that.data.setInter = setInterval(
      function () {
        let listdb = that.data.listdb;        
        let goingtime = that.data.goingtime;
        let nowDateTime = that.data.nowDateTime + goingtime;
        for (var i = 0; i < listdb.length; i++) {
          var startime = listdb[i]['time_start'] - nowDateTime;
          if (startime <= 0) {
            listdb[i]['is_start'] = 1; 
            listdb[i]['show_start'] = '活动已经开始';
          } else {
            listdb[i]['is_start'] = 0;
            listdb[i]['startarr'] = App.format_time1(startime);
          }
          var endtime = listdb[i]['time_end'] - nowDateTime;
          if (endtime <= 0) {
            listdb[i]['is_end'] = 1;
            listdb[i]['show_end'] = '活动已经结束';
          } else {
            listdb[i]['is_end'] = 0;
            listdb[i]['endtimarr'] = App.format_time1(endtime);
          }
        }
        goingtime++;
        that.setData({ listdb: listdb, goingtime: goingtime });
      }, 1000);
  },
  //下拉刷新
  onPullDownRefresh() {
    this.get_vipinfo();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
  onShareAppMessage(ops) {
    let title = '分享VIP卡';
    let path = 'pages/forcode/index?foruid=' + this.data.userinfo.uid + '&tabname=vip';
    //console.log(path);
    return {
      title: title,
      path: path,
    }
  },
})