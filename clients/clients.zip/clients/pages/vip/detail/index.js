const App = getApp()
Page({
  data: {
    userinfo:{},
    vipsetid:1,
    foruid: 0,
    vipinfo:{},
    vipgifts: [],
    vipuniongifts: [],
    union_num:0,
    showType:1,
    postpw: {},
    NoteWord:'',
    cksort:'0',
    nowDateTime: parseInt(new Date().getTime() / 1000),
    goingtime: 0,
    setInter: '',
    setInter1: '',
  },
  onLoad(options) {
    if ('vipsetid' in options) {
      this.setData({ vipsetid: options.vipsetid })
    }
    if ('foruid' in options) {
      App.WxService.setStorageSync('foruid', options.foruid);
      this.setData({ foruid: options.foruid });
    }
  },
  onShow() {
    const userinfo = App.WxService.getStorageSync('user');
    if (!userinfo.wx_openid) {
      App.WxService.redirectTo('/pages/login/index', { url: '/pages/vip/detail/index?vipsetid=' + this.data.vipsetid });
    }else{
      this.setData({
        userinfo: userinfo
      })
      this.getVipInfo();
    }
  },
  onHide() {
    //页面隐藏清除检测卡券核销状态
    clearInterval(this.data.setInter1);
  },
  onUnload(){
    //页面卸载清除检测卡券核销状态
    clearInterval(this.data.setInter1);
  },
  telCall(e){
    const tel = e.currentTarget.dataset.id;
    wx.makePhoneCall({
      phoneNumber: tel
    })
  },
  showunionsort(e){
    const id = e.currentTarget.dataset.id;
    const vipuniongifts = this.data.vipinfo._union_gift;
    if (id == '0'){
      this.setData({ cksort: id, vipuniongifts: vipuniongifts})
    }else{
      var newarray = new Array();
      var j = 0;
      for (var i = 0; i < vipuniongifts.length; i++){
        if (vipuniongifts[i]['union_sortid'] == id){
          newarray[j] = vipuniongifts[i];
          j++;
        }
      }
      this.setData({ cksort: id, vipuniongifts: newarray })
    }
  },
  showUnions(){
    this.setData({ showType: 2 })
  },
  showUnions1() {
    this.setData({ showType: 1 })
  },
  getVipInfo() {
    const url = App.HttpResource('/smallprogramapi/vip/getvipconf')
    url.queryAsync({
      'from': 'vippage',
      'openid': this.data.userinfo.wx_openid,
      'vipsetid': this.data.vipsetid
    })
      .then(res => { 
        const datas = res.data;
        if (datas.meta.code == 0){
          const thisvip = datas.data;
          if (thisvip._gifts) {
            this.setData({ vipgifts: thisvip._gifts })
          }
          if (thisvip._union_gift){
            let unions = thisvip._union_gift;
            this.setData({ 
              vipuniongifts: unions, 
              union_num: unions.length
            })
          }
          if (thisvip._give_share_gift) {
            this.setData({ vipsharegifts: thisvip._give_share_gift })
          }
          this.setData({ vipinfo: thisvip, })
          this.format_showtime();
          //console.log(thisvip);
          wx.setNavigationBarColor({
            frontColor: '#ffffff', // 必写项
            backgroundColor: thisvip.vipbgcolor, // 必写项           
          })
          
        }else{
          this.setData({ NoteWord: datas.meta.message, })
        }
      })
  },
  format_showtime() {
    const that = this;
    clearInterval(that.data.setInter);
    that.setData({
      nowDateTime: parseInt(new Date().getTime() / 1000),
      goingtime: 0
    })
    that.data.setInter = setInterval(
      function () {
        let vipinfo = that.data.vipinfo;
        var goingtime=that.data.goingtime;
        const nowDateTime = that.data.nowDateTime + goingtime;
        var startime = vipinfo.time_start - nowDateTime;
        if (startime <= 0) {
          vipinfo.is_start = 1;
          vipinfo.show_start = '活动已经开始';
        } else {
          vipinfo.is_start = 0;
          vipinfo.startarr = App.format_time1(startime);
        }
        var endtime = vipinfo.time_end - nowDateTime;
        if (endtime <= 0) {
          vipinfo.is_end = 1;
          vipinfo.show_end = '活动已经结束';
        } else {
          vipinfo.is_end = 0;
          vipinfo.endtimarr = App.format_time1(endtime);
        }
        that.setData({ vipinfo: vipinfo });
        goingtime += 1;
        that.setData({ vipinfo: vipinfo, goingtime: goingtime });
      }, 1000);
  },
 
  userCar1(e) {
    const index = parseInt(e.currentTarget.dataset.id);
    const thisCar = this.data.vipgifts[index];
    this.userCar(thisCar);
  },
  userCar2(e){
    const index = parseInt(e.currentTarget.dataset.id);
    const thisCar = this.data.vipuniongifts[index];
    this.userCar(thisCar);
  },
  userCar(thisCar){
    const nowtime = parseInt(new Date().getTime() / 1000);
    if (thisCar.aftercanuse > nowtime ) {  
      var note1 = '';
      if (thisCar.voucher_checkonce == '1'){
        note1 = '每天只能用一次';
      } else if (thisCar.voucher_checkonce == '2') {
        note1 = '每周只能用一次';
      } else if (thisCar.voucher_checkonce == '3') {
        note1 = '每月只能用一次';
      }
      this.setData({
        postpw: {'showbox': 1, 'nouse': 1, 'name': '当前卡券还不能使用', 'note1': note1, 'time': App.get_date_time(thisCar.aftercanuse) }
      })
      return;
    }
    const id = parseInt(thisCar.orderid);
    const url = App.HttpResource('/smallprogramapi/voucher/showvoucherqr')
    url.queryAsync({
      'openid': this.data.userinfo.wx_openid,
      'voucherorderid': id
    })
      .then(res => {
        const datas = res.data;
        if (datas.meta.code == 0) {
          //console.log(datas.data);
          this.setData({
            postpw: { 'orderid': id, 'showbox': 1, 'pw': '', 'num': 1, 'qrurl': datas.data.qrurl, 'erkey': datas.data.erkey }
          })
          this.uservoucherover();
        } else {
          this.setData({
            postpw: { 'orderid': id, 'showbox': 1, 'pw': '', 'num': 1, 'qrurl': 'error', 'usertype': '1' }
          })
        }
      })
  },
  uservoucherover() {
    const that = this;
    clearInterval(that.data.setInter1);
    var limittime = 0;
    that.data.setInter1 = setInterval(
      function () { 
        limittime += 2;
        if (limittime>120){
          that.HidePostpw();
        }
        const erkey = that.data.postpw.erkey;
        const url = App.__config.basePath + '/smallprogramapi/voucher/uservoucherstatus';
        wx.request({
          url: url,
          data: { 'erkey': erkey },
          method: "POST",
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            if (res.data.meta.code == 0) {
              that.HidePostpw();
              App.WxService.showModal({
                title: '提示！',
                content: '核销成功',
                showCancel: !1,
              })
                .then(data => {
                  that.getVipInfo();
                })
            }
          }
        })
      }, 2000);
  },
  HidePostpw(){
    clearInterval(this.data.setInter1);
    this.setData({
      postpw: {}
    })
  },
  passChange(e) {
    let givepwd = e.detail.value;
    this.setData({ 'postpw.pw': givepwd })
  },
  MoveUseNum(){
    let num = this.data.postpw.num;
    if (num<2){
      this.show_return('使用数量必须是大于1！');
    }else{
      num--;
    }
    this.setData({ 'postpw.num': num })
  },
  AddUseNum(){
    this.setData({ 'postpw.num': this.data.postpw.num + 1 })
  },
  numChange(e){
    let num = e.detail.value;
    if (!this.checkInt(num)){
      this.show_return('使用数量必须是大于1的整数！');
      num = 1;
    }
    this.setData({ 'postpw.num': num })
  },
  checkInt(num) {
    let pat = new RegExp('^[0-9]+$'); 
    return pat.test(num)
  },
  CheckPostpw(){
    const pwinfo = this.data.postpw;
    if (!pwinfo.orderid){
      this.show_return('没有指定使用的卡券');
      return;
    }
    if (pwinfo.pw=='') {
      this.show_return('没有输入使用密码');
      return;
    }
    const url = App.HttpResource('/smallprogramapi/voucher/checkone')
    url.queryAsync({
      'openid': this.data.userinfo.wx_openid,
      'voucherorderid': pwinfo.orderid,
      'checkpwd': pwinfo.pw,
      'vouchernum': pwinfo.num
    })
      .then(res => { 
        const meta = res.data.meta;
        if (meta.code == 1){
          this.show_return(meta.message);
          return;
        }else{
          App.WxService.showModal({
            title: '友情提示',
            content: meta.message,
            showCancel: !1,
          })
            .then(data => { 
              this.getVipInfo();
              this.HidePostpw();
            })
        }
      })
  },  
  show_return(msg) {
    App.WxService.showModal({
      title: '友情提示',
      content: msg,
      showCancel: !1,
    })
  },
  buyvip(){
    const url = App.HttpResource('/smallprogramapi/vip/buyvip')
    url.queryAsync({
      'openid': this.data.userinfo.wx_openid,
      'vipsetid': this.data.vipsetid
    })
      .then(res => {
        const datas = res.data;
        if (datas.meta.code==0){
          const orders = datas.data;
          this.gotopay(orders);
        }else{
          App.WxService.showModal({
            title: '提示！',
            content: datas.meta.message,
          })
        }
       })
  },
  //进入支付
  gotopay(orders) {
    let paymoney = parseFloat(orders.paymoney);
    if (paymoney > 0 && orders.id != ''){
      const url = App.HttpResource('/smallprogramapi/weixin/pay')
      url.queryAsync({
        'uid': orders.uid,
        'title': orders.vipname,
        'pricetotal': paymoney,
        'table':'viporder',
        'tableid': orders.id
      })
        .then(res => { 
          const datas = res.data;
          if (datas.meta.code==0){
            const paydata = datas.data;
            //console.log(paydata);
            this.pay(paydata);
          }else{
            App.WxService.showModal({
              title: '出错了!',
              content: datas.meta.message,
            })
          }
        })
    }
  },
  pay(result) {
    //console.log(result);
    let that = this;
    wx.requestPayment({
      'timeStamp': result.timeStamp,
      'nonceStr': result.nonceStr,
      'package': result.package,
      'signType': result.signType,
      'paySign': result.paySign,
      success: function (res) {
        wx.showLoading({
          title: '支付成功',
        })
        that.paystatus(result.ordersn);
      },
      fail: function (res) {
        console.log(res);
      }
    })
  },
  paystatus(ordersn) {
    const that = this;
    const url = App.HttpResource('/smallprogramapi/weixin/paystatus')
    url.queryAsync({
      'ordersn': ordersn,
      'openid': that.data.userinfo.wx_openid
    })
      .then(res => { 
        if(res.data.meta.code==0){
          wx.hideLoading();
          that.getVipInfo();
          App.RefreshUserinfo();//刷新用户信息
        }else{
          setTimeout(function () {
            that.paystatus(ordersn);
          }, 500)
        }
      })
  },
  onShareAppMessage: function (ops) {
    let title = this.data.userinfo.nikename+"邀请您加入《"+this.data.vipinfo.vipname+"》";
    let path = 'pages/vip/detail/index?vipsetid=' + this.data.vipsetid + '&foruid=' + this.data.userinfo.uid;
    console.log(path);  
    return {
      title: title,
      path: path,
      success: function (res) {
        //console.log(res);
        console.log("转发成功:");
      },
      fail: function (res) {
        console.log("转发失败:");
      }
    }
  },
  //下拉刷新
  onPullDownRefresh() {
    this.getVipInfo();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
  usertype(e) {
    this.setData({
      'postpw.usertype': e.currentTarget.dataset.id
    })
  }
})