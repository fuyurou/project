const App = getApp()
var WxParse = require('../../wxParse/wxParse.js');
Page({
  data: {
    baseinfo: {}
  },
  onLoad: function (options) {
    this.getbaseinfo();
  },
  getbaseinfo() {
    const url = App.HttpResource('/smallprogramapi/business/getinfo')
    url.queryAsync()
      .then(res => {
        const datas = res.data;
        if (datas.meta.code == 0) {
          let baseinfo = datas.data;
          this.setData({
            baseinfo: baseinfo
          })
          WxParse.wxParse('article', 'html', baseinfo.contents, this, 5);
          //console.log(baseinfo);
        }
      })
  },
  //打电话
  topPhoneCall() {
    wx.makePhoneCall({
      phoneNumber: this.data.baseinfo.mobile
    })
  },
  //打开地图
  topOpenMap() {
    const baseinfo = this.data.baseinfo;
    var maparr = baseinfo.contact_map.split(",");
    const latitude = parseFloat(maparr[0]);
    const longitude = parseFloat(maparr[1]);
    wx.openLocation({
      latitude: latitude,
      longitude: longitude,
      scale: 18,
      name: baseinfo.fullname,
      address: baseinfo.contact_address
    })
    // const mapstr = this.data.baseinfo.contact_map;
    // var maparr = mapstr.split(",");
    // App.WxService.navigateTo('/pages/map/index', {
    //   latitude: maparr[0],
    //   longitude: maparr[1]
    // })
  },
})