const App = getApp()
var WxParse = require('../../wxParse/wxParse.js');
var util = require('../../helpers/util.js')
Page({
  data: {
    userinfo: {},
    baseinfo: {},
    comments1: [],
    timelimit: [],
    kanjialistdb: [],
    nowDateTime: parseInt(new Date().getTime() / 1000),
    goingtime: 0,
    getVipinfo: {},
    getZmkInfo: [],
    autoplay: !0,
    interval: 3000,
    duration: 1000,
    current: 0,
    setInter: '',
  },
  onLoad() {
    //刷新用户数据
    App.RefreshUserinfo(this.getpagedata)
  },
  getpagedata() {
    const userInfo = App.WxService.getStorageSync('user');
    if (userInfo.wx_openid) {
      this.setData({ userinfo: userInfo })
    }
    this.getbaseinfo();
    this.getcomment();
    this.getkanjia();
    this.timelimit();
    this.formatlimittime();
  },
  getbaseinfo() {
    const url = App.HttpResource('/smallprogramapi/business/getinfo')
    url.queryAsync()
      .then(res => {
        const datas = res.data;
        if (datas.meta.code == 0) {
          const baseinfo = datas.data;
          this.setData({
            baseinfo: baseinfo
          })
          //console.log(baseinfo);
        }
      })
  },
  getVipinfo() {
    let frompage = "index";
    if (this.data.userinfo.wx_openid) {
      frompage = "vippage";
    }
    const url = App.HttpResource('/smallprogramapi/vip/getvipconf')
    url.queryAsync({ 'from': frompage, 'openid': this.data.userinfo.wx_openid })
      .then(res => {
        const datas = res.data;
        if (datas.meta.code == 0) {
          this.setData({
            getVipinfo: datas.data
          })
        }
      })
  },
  getZmkInfo() {
    const url = App.HttpResource('/smallprogramapi/zmk/getzmklistsimple')
    url.queryAsync()
      .then(res => {
        let zmklist = res.data.zmklist;
        for (var i = 0; i < zmklist.length; i++) {
          var childnum = parseInt(zmklist[i]['children_num']);
          if (childnum > 0) {
            zmklist[i]['starts'] = new Array(childnum);
            zmklist[i]['isstarts'] = 1;
          }
        }
        this.setData({
          getZmkInfo: zmklist
        })
      })
  },
  /****幻灯片滚动事件*****/
  swiperchange(e) {
    this.setData({
      current: e.detail.current,
    })
  },
  topPhoneCall() {
    wx.makePhoneCall({
      phoneNumber: this.data.baseinfo.contact_tel
    })
  },
  //打开地图
  topOpenMap() {
    const baseinfo = this.data.baseinfo;
    var maparr = baseinfo.contact_map.split(",");
    const latitude = parseFloat(maparr[0]);
    const longitude = parseFloat(maparr[1]);
    wx.openLocation({
      latitude: latitude,
      longitude: longitude,
      scale: 18,
      name: baseinfo.fullname,
      address: baseinfo.contact_address
    })
  },
  getcomment() {
    const url = App.HttpResource('/Smallprogramapi/Store/getcommentall')
    url.queryAsync()
      .then(res => {
        const comments = res.data.commlistdb;
        if (comments) {
          let listcomm = new Array();
          for (var i = 0; i < 4; i++) {
            if (comments[i]) {
              comments[i]['commtime'] = App.get_date_time(comments[i]['commtime']);
              listcomm[i] = comments[i];
            }
          }
          this.setData({
            comments1: listcomm,
          })
        }
      })
  },
  //评论图片
  previewImage1(e) {
    const commlist = this.data.comments1;
    const index1 = e.currentTarget.dataset.index;
    const index = e.currentTarget.dataset.id;
    let urls = commlist[index]['pics_lg'];
    for (var i = 0; i < urls.length; i++) {
      urls[i] = urls[i].replace('http://', "https://")
    }
    const current = urls[index1];
    App.WxService.previewImage({
      current: current,
      urls: urls,
    })
  },
  getkanjia() {
    const url = App.HttpResource('/smallprogramapi/store/kanjia')
    url.queryAsync({ 'limit': 4 })
      .then(res => {
        const listdbs = res.data.kanjialistdb;
        if (listdbs) {
          let arrays = new Array();
          for (var i = 0; i < listdbs.length; i++) {
            var min_price = listdbs[i]['goodsprice'] - listdbs[i]['maxnum'] * listdbs[i]['step_end'];
            min_price = min_price > 0 ? min_price : '0.00';
            listdbs[i]['min_price'] = Math.round(min_price * 100) / 100;
            arrays[i] = listdbs[i];
          }
          this.setData({ kanjialistdb: arrays });
        }
      })
  },
  timelimit() {
    const url = App.HttpResource('/smallprogramapi/store/timelimit')
    url.queryAsync({'limit':4})
      .then(res => {
        this.setData({ timelimit: res.data.timelimitdb });
      })
  },
  formatlimittime() {
    const that = this;
    that.data.setInter = setInterval(
      function () {
        const nowDateTime = that.data.nowDateTime;
        let goingtime = that.data.goingtime;
        const userinfo = that.data.userinfo;
        let thearray = that.data.timelimit;
        var spacTime = nowDateTime + goingtime;
        for (var i = 0; i < thearray.length; i++) {
          thearray[i]['this_price'] = (userinfo.isvip == '1') ? thearray[i]['price_vip'] : thearray[i]['price_normal'];
          var startime = thearray[i]['time_start'] - spacTime;
          if (startime > 0) {
            thearray[i]['is_start'] = 0;
            thearray[i]['startarr'] = App.format_time1(startime);
          } else {
            thearray[i]['startarr'] = '活动已经开始';
            thearray[i]['is_start'] = 1;
          }
          var endtime = thearray[i]['time_end'] - spacTime;
          if (endtime > 0) {
            thearray[i]['is_end'] = 0;
            thearray[i]['endtimarr'] = App.format_time1(endtime);
          } else {
            thearray[i]['is_end'] = 1;
            thearray[i]['endtimarr'] = '活动已经结束';
          }
        }
        let thearray1 = that.data.kanjialistdb;
        for (var i = 0; i < thearray1.length; i++) {
          var startime = thearray1[i]['time_start'] - spacTime;
          if (startime > 0) {
            thearray1[i]['is_start'] = 0;
            thearray1[i]['startarr'] = App.format_time1(startime);
          } else {
            thearray1[i]['startarr'] = '活动已经开始';
            thearray1[i]['is_start'] = 1;
          }
          var endtime = thearray1[i]['time_end'] - spacTime;
          if (endtime > 0) {
            thearray1[i]['is_end'] = 0;
            thearray1[i]['endtimarr'] = App.format_time1(endtime);
          } else {
            thearray1[i]['is_end'] = 1;
            thearray1[i]['endtimarr'] = '活动已经结束';
          }
        }
        goingtime += 1;
        that.setData({ timelimit: thearray, goingtime: goingtime, kanjialistdb: thearray1 });
      }, 1000);
  },
  onShareAppMessage(ops) {
    let title = this.data.baseinfo.fullname;
    let path = 'pages/forcode/index?foruid=' + this.data.userinfo.uid;
    return {
      title: title,
      path: path,
    }
  },
  previewqrImage: function (e) {
    //console.log(e.currentTarget.dataset);
    wx.previewImage({
      current: [e.currentTarget.dataset.src], // 当前显示图片的http链接   
      urls: [e.currentTarget.dataset.src] // 需要预览的图片http链接列表   
    })
  },
  //下拉刷新
  onPullDownRefresh() {
    clearInterval(this.data.setInter);
    this.setData({
      nowDateTime: parseInt(new Date().getTime() / 1000),
      goingtime: 0
    })
    this.setData({ userinfo: App.WxService.getStorageSync('user') })
    this.getbaseinfo();
    this.getcomment();
    this.getkanjia();
    this.timelimit();
    this.formatlimittime();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
})