const App = getApp()
import config from '../../../etc/config'
var util = require('../../../helpers/util.js')
Page({
  data: {
    orderinfo: {},
    goodsininorder: [],
    userinfo: null,
    id:6,
    postimgs: ["", "", ""],
    postimgs1: ['','',''],
    postimgsnum:0,
    postFileUrl: config.basePath + '/smallprogramapi/store/uploadfile?openid=',
    fens:'',
    content:'',
    forurl:''
  },
  onLoad: function (options) {
    if ('id' in options) { this.setData({ id: options.id }) }
    if ('url' in options) {
      let url = unescape(options.url)
      this.setData({
        forurl: url,
      })
    }
    //检查是否登录
    let url = "/pages/shop/order/comment?id=" + this.data.id;
    const userinfo = App.checkIsLogin(url);
    this.setData({
      userinfo: userinfo
    })
    this.getorderdetail(); 
  },
  onShow: function () {
  },
  getorderdetail() {
    const url = App.HttpResource('/smallprogramapi/store/getorder')
    url.queryAsync({
      'openid': this.data.userinfo.wx_openid,
      'orderid': this.data.id,
    })
      .then(res => {
        const datas = res.data;
        if (datas.orderinfo.comm_status==1){
          App.WxService.showModal({
            title: '友情提示',
            content: '该订单您已经评价过！不能重复评论',
            showCancel: !1,
          })
            .then(data => {
              if (this.data.forurl) {
                App.WxService.redirectTo(this.data.forurl)
              } else {
                wx.navigateBack();
              }
            })
          return;
        }
        var goodsininorder = datas.goodsininorder;
        let listfens = new Array();
        let listfens1 = '';
        if (datas.orderinfo) {
          for (var i = 0; i < goodsininorder.length; i++) {
            goodsininorder[i]['fen']=5;
            listfens[i] = parseInt(goodsininorder[i]['id']) + '-' + parseInt(goodsininorder[i]['fen']);
          }
          listfens1 = listfens.join('|');
          this.setData({
            orderinfo: datas.orderinfo,
            goodsininorder: goodsininorder,
            fens: listfens1
          })
          //console.log(datas);
        } else {
          App.WxService.showModal({
            title: '友情提示',
            content: datas.meta.message,
            showCancel: !1,
          })
        }
      })
  },
  setfen(e){
    const goodsid = e.currentTarget.dataset.id;
    const fen = e.currentTarget.dataset.set;
    var goodsininorder = this.data.goodsininorder;
    let listfens = new Array();
    let listfens1 = '';
    for (var i = 0; i < goodsininorder.length; i++) {
      if (goodsininorder[i]['id'] == goodsid){
        goodsininorder[i]['fen'] = fen;
      }
      listfens[i] = parseInt(goodsininorder[i]['id']) + '-' + parseInt(goodsininorder[i]['fen']);
    }
    listfens1 = listfens.join('|');
    this.setData({
      goodsininorder: goodsininorder,
      fens: listfens1
    })
  },
  gotoshop(e) {
    const id = parseInt(e.currentTarget.dataset.id);
    App.WxService.navigateTo('/pages/shop/detail/index', { id: id })
  },
  chooseImage(e){
    let that=this;
    const index = parseInt(e.currentTarget.dataset.id);
    //console.log(index);
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        wx.showLoading({
          title: '正在上传',
        })
        let files = res.tempFilePaths;
        for (let i = 0; i < files.length; i++) {
          //that.postimgs(files[i],index);
          that.postPic(files[i],index);
        }
      },
      fail: function (e) {
        console.error(e)
      }
    })
  },
  postimgs(imgurl,index){
    const postimgs = this.data.postimgs;
    let postimgs1 = this.data.postimgs1;
    //let imgs = new Array();
    for (let i = 0; i < postimgs.length; i++) {
      if (i == index){
        postimgs[i] = config.basePath + imgurl;
        postimgs1[i] = imgurl;
      }
    }
    this.setData({
      postimgs: postimgs,
      postimgs1: postimgs1
    })
  },
  delimgs(e){
    const index = parseInt(e.currentTarget.dataset.id);
    const postimgs = this.data.postimgs;
    let postimgs1 = this.data.postimgs1;
    for (let i = 0; i < postimgs.length; i++) {
      if (i == index) {
        postimgs[i] = '';
        postimgs1[i]='';
      }
    }
    this.setData({
      postimgs: postimgs,
      postimgs1: postimgs1
    })
  },
  /*** 上传图片 
     * 注意,每次上传图片都会执行一次onShow事件,尽量不要把事件写在onShow那里,
     * 并且上传事件,调试器的Network是看不到的.
     * ***********/
  postPic(filePath,index) {
    const that = this;
    wx.uploadFile({
      url: that.data.postFileUrl + this.data.userinfo.wx_openid,
      filePath: filePath,
      name: 'photo',
      success: function (res) {
        wx.hideLoading();
        let datas = JSON.parse(res.data);        
        if (datas.data.picurl){
          that.postimgs( datas.data.picurl, index);
        }
      },
      fail: function (e) {
        //util.showModel('上传图片失败', '')
        return ;
      }
    })
  },
  inputcontent(e) {
    let content = e.detail.value;
    var num = this.strlen(content);
    if (num<=160){
      this.setData({ content: content})
    }else{
      util.showModel('提示', '评论内容过长，只能输入80个字')
      this.setData({ content: this.data.content })
    }
  },
  strlen(str) {
    var len = 0;
    for (var i = 0; i < str.length; i++) {
      var c = str.charCodeAt(i);
      //单字节加1 
      if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
        len++;
      }
      else {
        len += 2;
      }
    }
    return len;
  },
  formSubmit: function (e) {
    const that = this;
    const forms = e.detail.value;
    if (forms.content==''){
      util.showModel('提示', '请填写商品评价内容')
      return;
    }
    const postimgs = this.data.postimgs1;
    let lisimgs = new Array();
    var j=0;
    for (let i = 0; i < postimgs.length; i++) {
      if (postimgs[i]) {
        lisimgs[j] = postimgs[i];
        j++;
      }     
    }
    const url = App.HttpResource('/smallprogramapi/store/postcomment')
    url.queryAsync({
      'openid': this.data.userinfo.wx_openid,
      'ordergoodsinfoidandstar': forms.fens,
      'pics': lisimgs.join('|'),
      'remarks': forms.content
    })
      .then(res => {
        if(res.data.meta.code==0){
          util.showSuccess('评论成功');
          if (that.data.forurl){
            App.WxService.redirectTo(that.data.forurl)
          }else{
            wx.navigateBack();
          }
        }else{
          util.showModel('评论失败', res.data.meta.message)
          return
        }
      })
  },
})