const App = getApp()
var WxParse = require('../../../wxParse/wxParse.js');
Page({
  data:{
    userinfo:{},
    goods: {},
    commlistdb:[],
    orderlist:[],
    autoplay: !0,
    interval: 3000,
    duration: 1000,
    current: 0,
    ShowTypes:1,
    goodsid:8,
    shopcar:{'num':0,'array':[],'incar':0}
  },
  onLoad(option) {
    if ('id' in option) {
      this.setData({
        goodsid: option.id
      })
    }
    //如果是朋友分享过来的记录foruid缓存
    if ('foruid' in option) {
      App.WxService.setStorageSync('foruid', option.foruid);
    }
    this.getDetail(this.data.goodsid);
    this.goodscars();
  },
  onShow() {
    //this.getDetail(this.data.goodsid);
    //this.goodscars();
  },
  getDetail(id) {
    const url = App.HttpResource('/Smallprogramapi/Store/getgoodsone');
    url.getAsync({ goodsid: id })
      .then(res => {
        const datas = res.data;
        const goodsinfo = datas.goodsinfo;
        let commlistdb = datas.comment.commlistdb;
        if (commlistdb){
          for (var i = 0; i < commlistdb.length; i++) {
            commlistdb[i]['commtime'] = App.get_date_time(commlistdb[i]['commtime']);
          }
        }
        //console.log(commlistdb);
        const orderlist = datas.orderlist.orderlist;
        if (goodsinfo.id) {
          //console.log(goodsinfo);
          WxParse.wxParse('article', 'html', goodsinfo.content, this, 5);
          this.setData({
            goods: goodsinfo,
            commlistdb: commlistdb,
            orderlist: orderlist
          })
        }else{
          App.WxService.showModal({
            title: '提示',
            content: '没有相应的商品！',
          })
            .then(data => data.confirm == 1 && wx.navigateBack({ changed: true }))
        }
      })
  },
  /****幻灯片滚动事件*****/
  swiperchange(e) {
    this.setData({
      current: e.detail.current,
    })
  },
  previewImage(e) {  
    const index = e.currentTarget.dataset.index;
    let urls = this.data.goods.pics_lg;
	for (var i = 0; i < urls.length; i++){
      urls[i] = urls[i].replace('http://', "https://")
    }
    const current = urls[Number(index)];
    App.WxService.previewImage({
      current: current,
      urls: urls,
    })
  },
  ShowTypes(e){
    const index = Number(e.currentTarget.dataset.id);
    this.setData({
      ShowTypes: index
    })
  },
  gototimelimitDetail(e){
    App.WxService.navigateTo('/pages/shop/seckill/detail/index', {
      id: e.currentTarget.dataset.id
    })
  },
  gotokanjiaDetail(e) {
    App.WxService.navigateTo('/pages/shop/dao/detail/index', {
      kanjiaid: e.currentTarget.dataset.id
    })
  },
  onShareAppMessage(options) {
    const goodinfo = this.data.goods;
    var that = this;
    // 设置菜单中的转发按钮触发转发事件时的转发内容
    var shareObj = {
      title: goodinfo.title,
      path: '/pages/shop/detail/index?id=' + goodinfo.id + '&foruid='+ this.data.userinfo.uid,   // 默认是当前页面，必须是以‘/’开头的完整路径
      imgUrl: goodinfo.face,     //自定义图片路径，可以是本地文件路径、代码包文件路径或者网络图片路径，支持PNG及JPG，不传入 imageUrl 则使用默认截图。显示图片长宽比是 5:4
      success: function (res) {
        // 转发成功之后的回调
        if (res.errMsg == 'shareAppMessage:ok') {
        }
      },
      fail: function (res) {
        // 转发失败之后的回调
        if (res.errMsg == 'shareAppMessage:fail cancel') {
          // 用户取消转发
        } else if (res.errMsg == 'shareAppMessage:fail') {
          // 转发失败，其中 detail message 为详细失败信息
        }
      },
      complete: function () {
        // 转发结束之后的回调（转发成不成功都会执行）
      }
    };
    // 返回shareObj
    return shareObj;
  },
  //评论图片
  previewImage1(e){
    const commlist = this.data.commlistdb;
    const index = e.currentTarget.dataset.index;
    const index1 = e.currentTarget.dataset.id;
    let urls = commlist[index]['pics_lg'];
	for (var i = 0; i < urls.length; i++){
      urls[i] = urls[i].replace('http://', "https://")
    }
    const current = urls[index1];
    App.WxService.previewImage({
      current: current,
      urls: urls,
    })
  },
  //购物车商品数组
  goodscars() {
    const userInfo = App.WxService.getStorageSync('user');
    if (userInfo.wx_openid) {
      const url = App.HttpResource('/Smallprogramapi/Store/getgoodslistincar')
      url.queryAsync({
        'openid': userInfo.wx_openid,
        'onlygoodsid': 1,
      }).then(res => {
        const goodcar = res.data.goodslist;
        if (goodcar[0]){
          var incar = 0;
          if (this.isInArray(goodcar, String(this.data.goodsid))){
            incar = 1;
          }
          this.setData({
            shopcar: { 'num': goodcar.length, 'array': goodcar, 'incar': incar }
          })
        }
        //console.log(goodcar);
      })
    } else {
      this.setData({
        shopcar: { 'num': 0, 'array': [], 'incar': 0 }
      })
    }
  },
  isInArray(arr, value) {
    for (var i = 0; i < arr.length; i++) {
      if (value === arr[i]) {
        return 1;
      }
    }
    return 0;
  },
  toshopcar(e) {
    const goodsid = this.data.goodsid;
    const totype = e.currentTarget.dataset.id;
    if (this.data.shopcar.incar == 1){
      if (totype == 2) {
        App.WxService.navigateTo('/pages/shop/mycar/index')
      } else {
        App.WxService.showModal({
          title: '提示',
          content: '当前商品已在购物车！',
        })
        return;
      }
    }
    const userInfo = App.WxService.getStorageSync('user');
    if (!userInfo.wx_openid) {
      App.WxService.showModal({
        title: '您还没有登录，不能把商品加入购物车',
        content: '确定要登录吗？',
      })
        .then(data => {
          if (data.confirm == 1){
            App.WxService.redirectTo('/pages/login/index', { url: '/pages/shop/detail/index?id=' + this.data.goodsid })
          }else{
            return;
          }
        })
    }else{
      const url = App.HttpResource('/Smallprogramapi/Store/addcar')
      url.queryAsync({
        'openid': userInfo.wx_openid,
        'goodsid': goodsid,
      })
        .then(res => { 
          const datas = res.data; //console.log(datas);
          if (datas.meta.code == 0) {
            if (totype == 2) {
              App.WxService.navigateTo('/pages/shop/mycar/index')
            } else {
              App.WxService.showModal({
                title: '提示',
                content: datas.meta.message,
              })
              this.goodscars();
            }
          }
        })
    }
  },
  //下拉刷新
  onPullDownRefresh() {
    this.getDetail(this.data.goodsid);
    this.goodscars();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  }
})