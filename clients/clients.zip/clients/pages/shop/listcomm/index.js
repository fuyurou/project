import config from '../../../etc/config'
const App = getApp()
Page({
  data: {
    comments1: [],
    p:1,
    showmore: 1,
    total_page:1,
    baseinfo:{},
    pageinfo:{'p':1,'maxp':1,'totals':0}
  },
  onLoad() {
    this.getcomment();
    this.getbaseinfo();
  },
  onShow() {
  
  },  
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    this.getcomment();
    // if (this.data.showmore == 1) {
    //   this.getcomment();
    // } 
  },
  getbaseinfo() {
    const url = App.HttpResource('/smallprogramapi/business/getinfo')
    url.queryAsync()
      .then(res => {
        const datas = res.data;
        if (datas.meta.code == 0) {
          const baseinfo = datas.data;
          this.setData({
            baseinfo: baseinfo
          })
        }
      })
  },
  getcomment() {
    const pageinfo = this.data.pageinfo;
    if (pageinfo.p <= pageinfo.maxp){
      const comments1 = this.data.comments1;
      const url = App.HttpResource('/Smallprogramapi/Store/getcommentall')
      url.queryAsync({ 'p': pageinfo.p })
        .then(res => { 
          const datas = res.data; console.log(datas);
          const pagearray = datas.pagearray;
          let comments = datas.commlistdb;
          if (comments != null){
            for (var i = 0; i < comments.length; i++) {
              comments[i]['commtime'] = App.get_date_time(comments[i]['commtime']);
            }
            const comments2 = [...comments1, ...comments];
            this.setData({
              comments1: comments2,
              "pageinfo.p": pageinfo.p + 1,
              "pageinfo.maxp": pagearray.total_page,
              "pageinfo.totals": pagearray.total
            })
          }
        })
    }

    // const comments1 = this.data.comments1;
    // const url = App.HttpResource('/Smallprogramapi/Store/getcommentall')
    // url.queryAsync({ 'p': this.data.p })
    //   .then(res => {
    //     const datas = res.data;
    //     const pagearray = datas.pagearray; console.log(pagearray);
    //     //如果当前页小于总页数可以显示更多否则不能显示更多
    //     if (this.data.p < pagearray.total_page) {
    //       this.setData({showmore: 1})
    //     } else {
    //       this.setData({showmore: 0})
    //     }
    //     let comments = datas.commlistdb;
    //     if (comments.length>0){
    //       for (var i = 0; i < comments.length; i++){
    //         comments[i]['commtime'] = App.get_date_time(comments[i]['commtime']);
    //       }
    //       const comments2 = [...comments1, ...comments];
    //       this.setData({
    //         comments1: comments2,
    //         p: this.data.p + 1,
    //       })
    //       console.log(comments2);
    //     }
    //   })
  },
  //评论图片
  previewImage1(e) {
    const commlist = this.data.comments1;
    const index1 = e.currentTarget.dataset.index;
    const index = e.currentTarget.dataset.id;
    let urls = commlist[index]['pics_lg'];
    for (var i = 0; i < urls.length; i++) {
      urls[i] = urls[i].replace('http://', "https://")
    }
    const current = urls[index1];
    App.WxService.previewImage({
      current: current,
      urls: urls,
    })
  },
  topPhoneCall() {
    wx.makePhoneCall({
      phoneNumber: this.data.baseinfo.mobile
    })
  },
  //打开地图
  topOpenMap() {
    const mapstr = this.data.baseinfo.contact_map;
    var maparr = mapstr.split(",");
    App.WxService.navigateTo('/pages/map/index', {
      latitude: maparr[0],
      longitude: maparr[1]
    })
  },
})