const App = getApp()
Page({
  data: {
    kanjiaorderid:1,
    kanjiadb:{},
    kanjiaorder:{},
    nowDateTime: parseInt(new Date().getTime() / 1000),
    goingtime:0,
    userinfo: {},
    kanjiaordercuthislist:[],
    p:1,
    showmore:1,
    myiscut:0,
    showaddress: 0,
    myaddress: [],
    addressid: '0',
    newaddress: { user: '', sex: 1, telphone: '', address: '' },
    remarks: '',
    ShowTypes:2,
    helperinfo:[],
    kanjiaoOver: { 'note': '成功帮朋友砍掉1元', 'show': 0, 'note1': '获得帮砍有礼中的所有礼品', 'note2': '是否也参与本商品的砍价活动？'},
    setInter:''
  },
  onLoad(options) {
    if ('foruid' in options) {
      App.WxService.setStorageSync('foruid', options.foruid);
    }
    if ('id' in options) {
      this.setData({
        kanjiaorderid: options.id
      })
    }
    this.getKanJiaOrder(this.data.kanjiaorderid);
  },
  onShow() {
    const userinfo = App.WxService.getStorageSync('user');
    if (userinfo.uid){
      this.setData({userinfo: userinfo})
    }
    this.kanjiafindcuthis();
  },
  telCall(e) {
    const tel = e.currentTarget.dataset.id;
    wx.makePhoneCall({
      phoneNumber: tel
    })
  },
  ShowTypes(e){
    const id = parseInt(e.currentTarget.dataset.id);
    this.setData({ ShowTypes: id })
  },
  getKanJiaOrder(id){
    const that=this;
    const url = App.HttpResource('/Smallprogramapi/Store/kanjiafindorder');
    url.getAsync({ kanjiaorderid: id })
      .then(res => { 
        const datas=res.data;
        if (datas.meta.code==0){
          let kanjiaorder = datas.data.kanjiaorder;
          kanjiaorder.percent = 100 - parseInt((kanjiaorder.price_last / kanjiaorder.price_begin)*100);
          kanjiaorder.cut_money = kanjiaorder.price_begin - kanjiaorder.price_last;
          kanjiaorder.cut_money = Math.round(kanjiaorder.cut_money * 100) / 100;
          if (kanjiaorder.kanjiaid){
            this.getKanJiaInfo(kanjiaorder.kanjiaid);
            this.kanjiaordercuthislist(id);
            this.setData({
              kanjiaorder: kanjiaorder
            })
            //console.log(kanjiaorder);
            this.kanjiainfo(kanjiaorder.kanjiaid);
          }
        }else{
          App.WxService.showModal({
            title: '提示',
            content: '没有相应的订单！',
          })
            .then(data => data.confirm == 1 && wx.navigateBack({ changed: true }))
        }
      })
  },
  kanjiainfo(id){
    const url = App.HttpResource('/smallprogramapi/store/kanjiagetone');
    url.getAsync({ kanjiaid: id })
      .then(res => { 
        if(res.data.meta.code==0){
          const helperinfo = res.data.data.helper_gifts;
          this.setData({ helperinfo: helperinfo })
          //console.log(helperinfo);
        }
      })
  },
  kanjiaordercuthislist(id) {
    const url = App.HttpResource('/smallprogramapi/store/kanjiaordercuthislist');
    url.getAsync({ kanjiaorderid: id, p:this.data.p})
      .then(res => {
        const datas = res.data;
        const pagearray = datas.pagearray;
        //如果当前页小于总页数可以显示更多否则不能显示更多
        if (this.data.p < pagearray.total_page) {
          this.setData({showmore: 1})
        } else {
          this.setData({showmore: 0 })
        }
        let kanjiaordercuthislist = datas.kanjiaordercuthislist;
        for (var i = 0; i < kanjiaordercuthislist.length; i++) {
          kanjiaordercuthislist[i]['post_time'] = App.get_date_time(kanjiaordercuthislist[i]['posttime']);
        }
        const kanjiaordercuthislist0 = this.data.kanjiaordercuthislist;
        const kanjiaordercuthislist1 = [...kanjiaordercuthislist0, ...kanjiaordercuthislist]
        this.setData({
          kanjiaordercuthislist: kanjiaordercuthislist1,
          p: this.data.p + 1
        })
        //console.log(kanjiaordercuthislist);
       })
  },
  getMorekanjiaordercuthislist(){
    if (this.data.showmore == 1) {
      this.kanjiaordercuthislist(this.data.kanjiaorderid);
    }
  },
  getKanJiaInfo(id) {
    const that = this;
    const url = App.HttpResource('/smallprogramapi/store/kanjiagetone');
    url.getAsync({ kanjiaid: id })
      .then(res => {
        const datas = res.data;
        if (datas.meta.code == 0) {
          let kanjiadb = datas.data.kanjiadb;
          kanjiadb.minpric = kanjiadb.goodsprice - kanjiadb.step_end * kanjiadb.maxnum;
          kanjiadb.minpric = kanjiadb.minpric > 0 ? kanjiadb.minpric : '0.00';
          kanjiadb.minpric = Math.round(kanjiadb.minpric * 100) / 100;
          that.setData({
            kanjiadb: kanjiadb
          })
          that.format_showtime();
        } else {
          App.WxService.showModal({
            title: '提示',
            content: datas.meta.message,
          })
        }
      })
  },
  format_showtime(){
    const that = this;
    //重置计时器时间
    clearInterval(that.data.setInter);
    that.setData({
      nowDateTime: parseInt(new Date().getTime() / 1000),
      goingtime: 0
    })
    that.data.setInter = setInterval(
      function () {
        let kanjiadb = that.data.kanjiadb;
        const nowDateTime = that.data.nowDateTime;
        let goingtime = that.data.goingtime;
        var startime = kanjiadb.time_start - nowDateTime - goingtime;
        if (startime <= 0) {
          that.setData({ 'kanjiadb.is_start': 1, 'kanjiadb.show_start': '活动已经开始' });
        } else {
          that.setData({ 'kanjiadb.is_start': 0, 'kanjiadb.show_start': App.format_time(startime) });
        }
        var endtime = kanjiadb.time_end - nowDateTime - goingtime;
        if (endtime <= 0) {
          that.setData({ 'kanjiadb.is_end': 1, 'kanjiadb.show_end': '活动已经结束' });
        } else {
          that.setData({ 'kanjiadb.is_end': 0, 'kanjiadb.show_end': App.format_time(endtime) });
        }
        goingtime += 1;
        that.setData({ goingtime: goingtime });
      }, 1000
    );
  },
  JoinKanjia(){
    if (this.data.userinfo.wx_openid) {
      const kanjiaorder = this.data.kanjiaorder;
      if (kanjiaorder.uid == this.data.userinfo.uid){
        App.WxService.showModal({
          title: '提示！',
          content: '请不要重复参加砍价！',
        })
      }else{
        const url = App.HttpResource('/smallprogramapi/store/kanjiaorder');
        url.getAsync({ kanjiaid: kanjiaorder.kanjiaid, openid: this.data.userinfo.wx_openid })
          .then(res => {
            const datas = res.data;
            //console.log(datas);
            if (datas.meta.code == 0) {
              App.WxService.navigateTo('/pages/shop/dao/order/index', { id: datas.data.kanjiaorder.id });
            } else {
              App.WxService.showModal({
                title: '提示！',
                content: datas.meta.message,
              })
            }
          })
      }
    } else {
      this.unUserInfoAction();
    }
  },
  //是否砍过
  kanjiafindcuthis(){
    const url = App.HttpResource('/smallprogramapi/store/kanjiafindcuthis');
    url.getAsync({ kanjiaorderid: this.data.kanjiaorderid, openid: this.data.userinfo.wx_openid })
      .then(res => { 
        const datas = res.data;
        if (datas.data.kanjiacuthis) {
          this.setData({
            myiscut: 1
          })
        }
      })
  },
  //帮砍一刀
  kanjiaorderdocut(){
    if (this.data.userinfo.wx_openid) {
      if (this.data.myiscut==1){
        App.WxService.showModal({
          title: '提示！',
          content: '不能重复帮砍！',
        })
      }else{
        const url = App.HttpResource('/smallprogramapi/store/kanjiaorderdocut');
        url.getAsync({ kanjiaorderid: this.data.kanjiaorderid, openid: this.data.userinfo.wx_openid })
          .then(res => {
            const datas = res.data;
            if (datas.meta.code==0){
              this.setData({
                'kanjiaoOver.note': datas.meta.message,
                'kanjiaoOver.show': 1
              })
              //console.log(datas);
              // App.WxService.showModal({
              //   title: '提示',
              //   content: datas.meta.message,
              // })
              //   .then(data => {
              //     App.WxService.redirectTo('/pages/shop/dao/order/index?id=' + this.data.kanjiaorderid);
              //   })
              
            }else{
              App.WxService.showModal({
                title: '提示！',
                content: datas.meta.message,
              })
            }
          })
      }
    }else{
      this.unUserInfoAction();
    }
  },
  //没有登录的操作
  unUserInfoAction(){
    App.WxService.showModal({
      title: '您还没有登录，不能参加活动',
      content: '确定要登录吗？',
    })
      .then(data => data.confirm == 1 && App.WxService.redirectTo('/pages/login/index', { url: '/pages/shop/dao/order/index?id=' + this.data.kanjiaorderid }))
  },
  //现在购买
  BuyNow(){
    App.WxService.showModal({
      title: '提示',
      content: '是否以当前价格购买？购买后不能再继续砍价',
    })
      .then(data => { 
        if (data.confirm == 1){
          this.showSelAddress();
          this.setData({
            showaddress: 1
          });
        }
      })
  },
  showSelAddress() {
    const userinfo = App.WxService.getStorageSync('user');
    const url = App.HttpResource('/smallprogramapi/store/getmyaddress')
    url.queryAsync({ 'openid': userinfo.wx_openid })
      .then(res => {
        const datas = res.data.addresslist;
        var checkid=0;
        for (var i = 0; i < datas.length; i++) {
          if (datas[i]['often'] == '1') {
            checkid = datas[i]['id'];
            // this.setData({
            //   addressid: datas[i]['id']
            // })
          }
        }
        //console.log(datas);
        if (datas.length > 0) {
          if (checkid==0){
            checkid = datas[0]['id'];
          }
          this.setData({
            myaddress: datas,
            addressid: checkid
          })
        }
        if (this.data.kanjiadb.gettype == 0) {
          this.setData({
            addressid: -1
          })
        }
      })
  },
  Hideshowaddress() {
    this.setData({
      buyid: 0,
      showaddress: 0,
      newaddress: { user: '', sex: 1, telphone: '', address: '' },
      remarks: ''
    });
  },
  radioChange(e) {
    //const addressid = parseInt(e.detail.value);
    const addressid = e.detail.value;
    this.setData({
      addressid: addressid
    })
  },
  changessex(e) {
    const sex = parseInt(e.currentTarget.dataset.id);
    this.setData({
      'newaddress.sex': sex
    })
  },
  newaddressName(e) {
    this.setData({
      'newaddress.user': e.detail.value
    })
  },
  newaddressTel(e) {
    this.setData({
      'newaddress.telphone': e.detail.value
    })
  },
  newaddressAdr(e) {
    this.setData({
      'newaddress.address': e.detail.value
    })
  },
  changeremarks(e) {
    this.setData({
      remarks: e.detail.value
    })
  },
  show_return(msg) {
    App.WxService.showModal({
      title: '友情提示',
      content: msg,
      showCancel: !1,
    })
  },
  BuyNow1() {
    let addressid = parseInt(this.data.addressid);
    //如果是使用新地址
    if (addressid == 0 && this.data.kanjiadb.gettype != 0) {
      let newaddress = this.data.newaddress;
      if (newaddress.user == '') {
        this.show_return('请填写联系人姓名');
        return;
      }
      if (newaddress.telphone == '') {
        this.show_return('请填写联系人电话');
        return;
      }
      if (newaddress.address == '') {
        this.show_return('请填写联系人地址');
        return;
      }
      newaddress.openid = this.data.userinfo.wx_openid;
      newaddress.often = 1;
      const url = App.HttpResource('/smallprogramapi/store/addaddress')
      url.queryAsync(newaddress)
        .then(res => {
          if (res.data.meta.code == 0) {
            this.newadd_order(parseInt(res.data.data.id));
          } else {
            this.show_return('新地址插入失败！');
          }
        })
    } else {
      this.newadd_order(addressid);
    }
  },
  newadd_order(addressid) {
    //console.log(addressid);
    const tlid = parseInt(this.data.kanjiaorderid);
    if (tlid > 0 && (addressid > 0 || this.data.kanjiadb.gettype == 0)) {
      const url = App.HttpResource('/smallprogramapi/store/kanjiaorderbuy')
      url.queryAsync({ kanjiaorderid: tlid, addrid: addressid, openid: this.data.userinfo.wx_openid})
        .then(res => {
          //this.Hideshowaddress();
          const datas = res.data;
          if (datas.meta.code == 0) {
            const orderinfo = datas.data;
            //this.gotopay(orderinfo);
            //进入发起支付
            App.gotopay(
              {
                'uid': orderinfo.uid,
                'title': orderinfo.cut_remarks,
                'paymoney': orderinfo.price_last,
                'table': 'kanjiaorder',
                'id': orderinfo.id
              },
              this.payover,
			  this.payerror
            );
          } else {
            App.WxService.showModal({
              title: '提示！',
              content: datas.meta.message,
            })
              .then(data => {
                this.Hideshowaddress();
              })
          }
        })
    } else {
      this.show_return('参数有误！');
    }
  },
  payover() {
    App.WxService.navigateTo('/pages/user/dao/index');
  },
  payerror(){
    App.WxService.navigateTo('/pages/user/dao/index');
  },
  onShareAppMessage: function (ops) {
    let title = this.data.kanjiaorder.cut_remarks;
    let path = 'pages/shop/dao/order/index?id=' + this.data.kanjiaorderid + '&foruid=' + this.data.userinfo.uid;
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      //console.log(ops.target)
    }
    return {
      title: title,
      path: path,
      success: function (res) {
        console.log(res);
        console.log("转发成功:");
      },
      fail: function (res) {
        console.log("转发失败:");
      }
    }
  },
  //下拉刷新
  onPullDownRefresh() {
    this.getKanJiaOrder(this.data.kanjiaorderid);
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
})