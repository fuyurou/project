const App = getApp()
Page({
  data: {
    nowDateTime: parseInt(new Date().getTime() / 1000),
    goingtime:0,
    kanjiadb: {},
    images: [],
    images1: [],
    total: 0,
    userinfo: {},
    kanjiaid:1,
    ShowType:2,
    gifts:[],
    helper_gifts:[],
    kanjiaorders:[],
    setInter: ''
  },
  onLoad(options) {
    if ('kanjiaid' in options) {
      this.setData({
        kanjiaid: options.kanjiaid
      })
    }
    //如果是朋友分享过来的记录foruid缓存
    if ('foruid' in options) {
      App.WxService.setStorageSync('foruid', options.foruid);
    }
    this.getDetail(this.data.kanjiaid);
  },
  onShow() {
    const userinfo = App.WxService.getStorageSync('user');
    if (userinfo.uid) {
      this.setData({
        userinfo: userinfo
      })
    }
  },
  telCall(e) {
    const tel = e.currentTarget.dataset.id;
    wx.makePhoneCall({
      phoneNumber: tel
    })
  },
  getDetail(id) {
    const that = this;
    const url = App.HttpResource('/smallprogramapi/store/kanjiagetone');
    url.getAsync({ kanjiaid: id })
      .then(res => {
        const datas = res.data;
        if (datas.meta.code==0){
          let kanjiadb = datas.data.kanjiadb;
          kanjiadb.minpric = kanjiadb.goodsprice - kanjiadb.step_end * kanjiadb.maxnum;
          kanjiadb.minpric = kanjiadb.minpric > 0 ? kanjiadb.minpric : '0.00';
          kanjiadb.minpric = Math.round(kanjiadb.minpric * 100) / 100 ;
          let kanjiaorders = datas.data.kanjiaorders;
          for (var i = 0; i < kanjiaorders.length; i++){
            kanjiaorders[i]['post_time'] = App.get_date_time(kanjiaorders[i]['posttime']);
          }
          that.setData({
            kanjiadb: kanjiadb,
            gifts: datas.data.gifts,
            helper_gifts: datas.data.helper_gifts,
            kanjiaorders: kanjiaorders
          })
          that.format_showtime();
        } else {
          App.WxService.showModal({
            title: '提示',
            content: '没有相应的商品！',
          })
            .then(data => data.confirm == 1 && wx.navigateBack({ changed: true }))
        }
      })
  }, 
  format_showtime(){
    const that = this;
    clearInterval(this.data.setInter);
    //重置计时器时间
    this.setData({
      nowDateTime: parseInt(new Date().getTime() / 1000),
      goingtime: 0
    })
    that.data.setInter = setInterval(
      function () {
        let kanjiadb = that.data.kanjiadb;
        const nowDateTime = that.data.nowDateTime;
        let goingtime = that.data.goingtime;
        var startime = kanjiadb.time_start - nowDateTime - goingtime;
        if (startime <= 0) {
          that.setData({ 'kanjiadb.is_start': 1, 'kanjiadb.show_start': '活动已经开始' });
        } else {
          that.setData({ 'kanjiadb.is_start': 0, 'kanjiadb.show_start': App.format_time(startime) });
        }
        var endtime = kanjiadb.time_end - nowDateTime - goingtime;
        if (endtime <= 0) {
          that.setData({ 'kanjiadb.is_end': 1, 'kanjiadb.show_end': '活动已经结束' });
        } else {
          that.setData({ 'kanjiadb.is_end': 0, 'kanjiadb.show_end': App.format_time(endtime) });
        }
        goingtime += 1;
        that.setData({ goingtime: goingtime });
      }, 1000
    );
  }, 
  JoinKanji() {
    const kanjiaid = this.data.kanjiadb.id;
    if (this.data.userinfo.wx_openid){
      const url = App.HttpResource('/smallprogramapi/store/kanjiaorder');
      url.getAsync({ kanjiaid: kanjiaid, openid: this.data.userinfo.wx_openid })
        .then(res => {           
          const datas = res.data; //console.log(datas);
          if (datas.meta.code==0){
            App.WxService.navigateTo('/pages/shop/dao/order/index', { id: datas.data.kanjiaorder.id});
          }else{
            App.WxService.showModal({
              title: '提示！',
              content: '参加砍价失败！' + datas.meta.message,
            })
          }
        })
    }else{
      App.WxService.showModal({
        title: '您还没有登录，不能参加活动',
        content: '确定要登录吗？',
      })
        .then(data => data.confirm == 1 && App.WxService.redirectTo('/pages/login/index', { url: '/pages/shop/dao/detail/index?kanjiaid=' + kanjiaid }))
    }
  },
  ChangeShowType(e){
    this.setData({ ShowType: parseInt(e.currentTarget.dataset.id) });
  },
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      //console.log(ops.target)
    }
    return {
      title: this.data.kanjiadb.title,
      path: 'pages/shop/dao/detail/index?kanjiaid=' + this.data.kanjiadb.id + '&foruid=' + this.data.userinfo.uid,
      success: function (res) {
        console.log(res);
        console.log("转发成功:");
      },
      fail: function (res) {
        console.log("转发失败:");
      }
    }
  },
  //下拉刷新
  onPullDownRefresh() {
    this.getDetail(this.data.kanjiaid);
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
})