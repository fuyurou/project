const App = getApp()
Page({
  data: {
    goods: [],
    userinfo:{},
    p:1,
    showmore:1,
    nowDateTime: parseInt(new Date().getTime()/1000),
    goingtime:0,
    setInter: '',
  },
  onLoad(options) {
    this.getGoods();
    //如果是朋友分享过来的记录foruid缓存
    if ('foruid' in options) {
      App.WxService.setStorageSync('foruid', options.foruid);
    }
  },
  onShow() {
    const userInfo = App.WxService.getStorageSync('user');  
    if (userInfo.wx_openid) {
      this.setData({
        userinfo: userInfo
      })
    }
  },
  getGoods() {
    const that = this;
    const goods = that.data.goods;
    const url = App.HttpResource('/smallprogramapi/store/kanjia')
    url.queryAsync({
      'p': that.data.p,
    })
      .then(res => {
        const datas = res.data;
        let kanjialistdb = datas.kanjialistdb;
        for (var i = 0; i < kanjialistdb.length; i++) {
          var min_price = kanjialistdb[i]['goodsprice'] - kanjialistdb[i]['maxnum'] * kanjialistdb[i]['step_end'];
          min_price = min_price > 0 ? min_price : '0.00';
          kanjialistdb[i]['min_price'] = Math.round(min_price * 100) / 100 ;
        }
        if (datas.kanjialistdb) {
          that.setData({
            goods: kanjialistdb
          })
          that.format_showtime();
        }      
      })
  },
  format_showtime(){
    const that = this;
    //清空计时器
    clearInterval(that.data.setInter);
    that.setData({
      nowDateTime: parseInt(new Date().getTime() / 1000),
      goingtime: 0
    })
    that.data.setInter = setInterval(
      function () {
        let goods = that.data.goods;
        const nowDateTime = that.data.nowDateTime;
        let goingtime = that.data.goingtime;
        for (var i = 0; i < goods.length; i++) {
          var startime = goods[i]['time_start'] - nowDateTime - goingtime;
          if (startime <= 0) {
            goods[i]['is_start'] = 1;
            goods[i]['show_start'] = '活动已经开始';
          } else {
            goods[i]['is_start'] = 0;
            goods[i]['show_start'] = App.format_time(startime);
          }
          var endtime = goods[i]['time_end'] - nowDateTime - goingtime;
          if (endtime <= 0) {
            goods[i]['is_end'] = 1;
            goods[i]['show_end'] = '活动已经结束';
          } else {
            goods[i]['is_end'] = 0;
            goods[i]['show_end'] = App.format_time(endtime);
          }
        }
        goingtime += 1;
        that.setData({ goods: goods, goingtime: goingtime });
      }, 1000
    );
  },
  getMore() {
    // if (this.data.showmore == 1) {
    //   this.getGoods();
    // }
  },
  gotoDetail(e) {
    App.WxService.navigateTo('/pages/shop/dao/detail/index', {
      kanjiaid: e.currentTarget.dataset.id
    })
  },
  gotoJoin(e) {
    if (this.data.userinfo.wx_openid) {
      const url = App.HttpResource('/smallprogramapi/store/kanjiaorder');
      url.getAsync({ kanjiaid: e.currentTarget.dataset.id, openid: this.data.userinfo.wx_openid })
        .then(res => {
          const datas = res.data;
          if (datas.meta.code == 0) {
            App.WxService.navigateTo('/pages/shop/dao/order/index', { id: datas.data.kanjiaorder.id });
          } else {
            App.WxService.showModal({
              title: '提示！',
              content: '参加砍价失败！' + datas.meta.message,
            })
          }
        })
    } else {
      App.WxService.showModal({
        title: '您还没有登录，不能参加活动',
        content: '确定要登录吗？',
      })
        .then(data => data.confirm == 1 && App.WxService.redirectTo('/pages/login/index', { url: '/pages/shop/dao/index'}))
    }
  },
  onShareAppMessage: function (ops) {
    let title = '邀您参加[商品砍价]';
    let path = 'pages/shop/dao/index?foruid=' + this.data.userinfo.uid;
    console.log(path);
    return {
      title: title,
      path: path,
    }
  },
  //下拉刷新
  onPullDownRefresh() {
    this.getGoods();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
})