const App = getApp()
Page({
  data: {
    userInfo: {},
    carnum: 0,
    goods: [],
    sorts: [],
    carsarr: {},
    pageinfo:{'p':1,'maxp':1,'fid':0,'totalnum':0}
  },
  onLoad(options) {
    this.setData({
      userInfo: App.WxService.getStorageSync('user')      
    })
    this.goodscars(this.noAction);
    this.getGoods();    
  },
  onShow() { 
    this.goodscars(this.changeShopCar);
    //this.changeShopCar()
  },
  noAction(){

  },
  changeShopCar(){
    let goods = this.data.goods;
    const shopCarArray = App.WxService.getStorageSync('shopCarArray');
    for (var i = 0; i < goods.length; i++){
      if (this.isInArray(shopCarArray, goods[i]['id'])) {
        goods[i]['incar'] = 1;
      }else{
        goods[i]['incar'] = 0;
      }
    }
    this.setData({
      goods: goods,
      carnum: shopCarArray.length
    })
  },
  //购物车商品数组
  goodscars(cb) {
    const userInfo = App.WxService.getStorageSync('user');
    if (userInfo.wx_openid) {
      const url = App.HttpResource('/Smallprogramapi/Store/getgoodslistincar')
      url.queryAsync({
        'openid': userInfo.wx_openid,
        'onlygoodsid': 1,
      }).then(res => {
        const goodcar = res.data.goodslist;
        if (goodcar.length > 0){
          App.WxService.setStorageSync('shopCarArray', goodcar);
          cb();
        }else{
          App.WxService.removeStorageSync('shopCarArray');
          cb();
        }
      })
    } else {
      App.WxService.removeStorageSync('shopCarArray');
      cb();
    }
  },
  isInArray(arr, value) {
    for (var i = 0; i < arr.length; i++) {
      if (value === arr[i]) {
        return 1;
      }
    }
    return 0;
  },
  getGoods() {
    const pageinfo = this.data.pageinfo
    if (pageinfo.p <= pageinfo.maxp){
      const goods = this.data.goods
      const url = App.HttpResource('/Smallprogramapi/Store/getgoodslist')
      url.queryAsync({
        'fid': pageinfo.fid,
        'p': pageinfo.p,
      })
        .then(res => { 
          const datas = res.data;
          const pagearray = datas.pagearray;
          const goodssort = datas.goodssort;
          let listdb = datas.listdb;
          if (listdb){
            const goods1 = [...goods, ...listdb]
            this.setData({
              goods: goods1,
              'pageinfo.p': pageinfo.p + 1,
              'pageinfo.maxp': pagearray.total_page,
              'pageinfo.totalnum': pagearray.total,
              sorts: goodssort,
            })
            this.changeShopCar();
          }
        })
    }
  },
  changeFid(e) {
    const fid = e.currentTarget.dataset.id;
    this.setData({
      goods: [],
      pageinfo: { 'p': 1, 'maxp': 1, 'fid': fid,'totalnum': 0 }
    })
    this.getGoods();
  },
  //下拉刷新
  onPullDownRefresh() {
    this.setData({
      goods: [],
      pageinfo: { 'p': 1, 'maxp': 1, 'fid': 0, 'totalnum': 0 }
    })
    this.getGoods(); 
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
  //页面上拉触底事件的处理函数
  onReachBottom() {
    this.getGoods();
  },
  onReady() {
    this.animation = wx.createAnimation();    
  },
  scale() {
    this.scale2();
    setTimeout(function () {
      this.scale1();
    }.bind(this), 500)
  },
  scale1() {
    this.animation.scale(1).step()
    this.setData({ animation: this.animation.export() })
  },
  scale2() {
    this.animation.scale(3).step()
    this.setData({ animation: this.animation.export() })
  },
  toshopcar(e) {
    const id = e.currentTarget.dataset.id;
    const userInfo = App.WxService.getStorageSync('user');
    if (!userInfo.uid) {
      App.WxService.showModal({
        title: '您还没有登录，不能把商品加入购物车',
        content: '确定要登录吗？'
      })
        .then(data => {
          if (data.confirm == 1) {
            App.WxService.redirectTo('/pages/login/index', { url: '/pages/shop/index' })
          } else {
            return;
          }
        })
    }else{
      const url = App.HttpResource('/Smallprogramapi/Store/addcar')
      url.queryAsync({
        'openid': userInfo.wx_openid,
        'goodsid': id,
      })
        .then(res => {
          const datas = res.data;
          if (datas.meta.code == 0) {
            this.goodscars(this.changeShopCar)
            this.scale();
          } else {
            App.WxService.showModal({
              title: '提示',
              content: datas.meta.message,
              showCancel: !1,
            })
              .then(data => {
                App.WxService.redirectTo('/pages/login/index', { url: '/pages/shop/index' })
              })
          }
        })
    }
  },
  moveshopcar(e) {
    const id = e.currentTarget.dataset.id;
    if (this.data.userInfo.wx_openid) {
      const url = App.HttpResource('/Smallprogramapi/Store/removegoodsformcar')
      url.queryAsync({
        'openid': this.data.userInfo.wx_openid,
        'goodsid': id,
      })
        .then(res => {
          this.goodscars(this.changeShopCar)
          this.scale();
        })
    }
  },
  navigateTomycar() {
    App.WxService.navigateTo('/pages/shop/mycar/index')
  },
  onShareAppMessage(ops) {
    let title = '分享商品';
    let path = 'pages/forcode/index?foruid=' + this.data.userInfo.uid +'&tabname=shop';
    console.log(path);
    return {
      title: title,
      path: path,
    }
  },
})