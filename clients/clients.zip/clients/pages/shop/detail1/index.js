const App = getApp()
var WxParse = require('../../../wxParse/wxParse.js');
Page({
  data: {
    indicatorDots: !0,
    vertical: !1,
    autoplay: !0,
    interval: 3000,
    duration: 1000,
    current: 0,
    id: 1,
    goods: {},
    images: [],
    images1: [],
    total:0,
    hideContent: false,
    hideOrder: true,
    hideComment: true,
    carnum:0,
    userinfo:'',
    commlistdb:{},
    commpages:0,
    comm_num:0,
    orderlist:{},
    order_num:0,
    orderpages:0
  },
  /******页面第一次载入*********/
  onLoad(option) {
    if ('id' in option) {
      this.setData({
        id: option.id
      })
      //console.log(option.id);
    }
    this.getDetail(this.data.id);
  },
  onShow() {
    this.setData({
      userinfo: App.WxService.getStorageSync('user')
    })
    this.goodscars();
  },
  ShowContent(){
    this.setData({
      hideContent: false,
      hideOrder: true,
      hideComment: true
    })
  },
  ShowOrder() {
    this.setData({
      hideContent: true ,
      hideOrder: false,
      hideComment: true
    })
  },
  ShowComment() {
    this.setData({
      hideContent: true,
      hideOrder: true,
      hideComment: false
    })
  },
  //购物车商品数量
  goodscars() {
    const userInfo = this.data.userinfo;
    if (userInfo.wx_openid) {
      const url = App.HttpResource('/Smallprogramapi/Store/getgoodslistincar')
      url.queryAsync({
        'openid': userInfo.wx_openid,
        'onlygoodsid': 1,
      }).then(res => {
        const goodcar = res.data.goodslist;
        if (goodcar.length > 0) {
          this.setData({
            carnum: goodcar.length
          })
        }
      })
    }
  },
  toshopcar(e) {
    const totype = e.currentTarget.dataset.id;
    const userInfo = this.data.userinfo;
    if (!userInfo.wx_openid) {
      App.WxService.showModal({
        title: '您还没有登录，不能把商品加入购物车',
        content: '确定要登录吗？',
      })
        .then(data => data.confirm == 1 && App.WxService.redirectTo('/pages/login/index', { url: '/pages/shop/detail/index?id='+this.data.id }))
    }
    const url = App.HttpResource('/Smallprogramapi/Store/addcar')
    url.queryAsync({
      'openid': userInfo.wx_openid,
      'goodsid': this.data.id,
    })
      .then(res => {
        const datas = res.data;
        if (datas.meta.code == 0) {
          if (totype==2){
            App.WxService.navigateTo('/pages/shop/mycar/index')
          }else{
            this.setData({ carnum: datas.data.quantity_goods})
          }
        }
      })
  },
  getDetail(id) {
    const url = App.HttpResource('/Smallprogramapi/Store/getgoodsone');
    url.getAsync({ goodsid: id })
      .then(res => {
        const datas = res.data;
        //console.log(datas.comment);
        //console.log(datas.orderlist);
        const goodsinfo = datas.goodsinfo;
        if (datas.comment.commlistdb!=null){
          let commlistdb = datas.comment.commlistdb;
          for (var i = 0; i < commlistdb.length; i++) {
            commlistdb[i]['list'] = i;
            commlistdb[i]['commtime'] = this.get_date_time(commlistdb[i]['commtime']);
          }
          this.setData({
            commlistdb: datas.comment.commlistdb,
            commpages: datas.comment.pagearray.total_page,
            comm_num: datas.comment.pagearray.total,
          })
        }
        if (datas.orderlist.orderlist != null) {
          this.setData({
            orderlist: datas.orderlist.orderlist,
            order_num: datas.orderlist.pagearray.total,
            orderpages: datas.orderlist.pagearray.total_page
          })
        }
        if (goodsinfo.id){
          this.setData({
            images: goodsinfo.pics,
            images1: goodsinfo.pics_lg,
            total: goodsinfo.pics.length,
            goods: goodsinfo
          })
          WxParse.wxParse('article', 'html', goodsinfo.content, this, 5);
        }else{
          App.WxService.showModal({
            title: '提示',
            content: '没有相应的商品！',
          })
            .then(data => data.confirm == 1 && wx.navigateBack({ changed: true }))
        }
      })
  },
  /****幻灯片滚动事件*****/
  swiperchange(e) {
    this.setData({
      current: e.detail.current,
    })
  },
  /*******预览幻灯片的图片**********/
  previewImage(e) {    
    // const urls = this.data.images && this.data.images.map(n => n.picurl);
    const index = e.currentTarget.dataset.index;
    let urls = this.data.images;
	for (var i = 0; i < urls.length; i++){
      urls[i] = urls[i].replace('http://', "https://")
    }
    const current = urls[Number(index)];
    App.WxService.previewImage({
      current: current,
      urls: urls,
    })
  },
  onShareAppMessage(options) {
    var that = this;
    // 设置菜单中的转发按钮触发转发事件时的转发内容
    var shareObj = {
      title: that.data.goods.title,
      path: '/pages/shop/detail/index?id=' + that.data.goods.id,   // 默认是当前页面，必须是以‘/’开头的完整路径
      imgUrl: that.data.goods.face,     //自定义图片路径，可以是本地文件路径、代码包文件路径或者网络图片路径，支持PNG及JPG，不传入 imageUrl 则使用默认截图。显示图片长宽比是 5:4
      success: function (res) {
        // 转发成功之后的回调
        if (res.errMsg == 'shareAppMessage:ok') {
        }
      },
      fail: function (res) {
        // 转发失败之后的回调
        if (res.errMsg == 'shareAppMessage:fail cancel') {
          // 用户取消转发
        } else if (res.errMsg == 'shareAppMessage:fail') {
          // 转发失败，其中 detail message 为详细失败信息
        }
      },
      complete: function () {
        // 转发结束之后的回调（转发成不成功都会执行）
      }
    };
    // 返回shareObj
    return shareObj;
  },
  get_date_time(time) {
    time = parseInt(time);
    var date = new Date(time * 1000);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
    var Y = date.getFullYear() + '-';
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
    var D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate()) + ' ';
    var h = date.getHours() + ':';
    var m = date.getMinutes() + ':';
    var s = date.getSeconds();
    return Y + M + D + h + m + s;
  },
  //评论图片
  previewImage1(e){
    const commlist = this.data.commlistdb;
    const index1 = e.currentTarget.dataset.index;
    const index = e.currentTarget.dataset.id;
    let urls = commlist[index]['pics_lg'];
	for (var i = 0; i < urls.length; i++){
      urls[i] = urls[i].replace('http://', "https://")
    }
    const current = urls[index1];
    App.WxService.previewImage({
      current: current,
      urls: urls,
    })
  },
  //更多订单
  getMoreOrder(){

  },
  //更多评价
  getMoreComm() {

  }
})