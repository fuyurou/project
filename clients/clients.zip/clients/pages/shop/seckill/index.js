const App = getApp()
Page({
  data: {
    goods: [],
    userinfo: {},
    showmore: 1,
    nowDateTime: parseInt(new Date().getTime() / 1000),
    goingtime: 0,
    buyid:0,
    showaddress:0,
    myaddress:[],
    addressid:'0',
    newaddress: { user: '', sex: 1, telphone: '', address:''},
    remarks:'',
    setInter: ''
  },
  onLoad(options) {
    if ('foruid' in options) {
      App.WxService.setStorageSync('foruid', options.foruid);
    }
  },
  onShow() {
    //刷新用户数据
    App.RefreshUserinfo(this.checkLogin);
  },
  checkLogin(){
    const userInfo = App.WxService.getStorageSync('user'); 
    this.setData({ userinfo: userInfo })
    this.getGoods();
  },
  getGoods() {
    const that = this;
    const goods = that.data.goods
    const url = App.HttpResource('/smallprogramapi/store/timelimit')
    url.queryAsync()
      .then(res => {
        const datas = res.data;
        let timelimit = datas.timelimitdb;
        if (timelimit.length>0){
          for (var i = 0; i < timelimit.length; i++){
            timelimit[i]['this_price'] = (that.data.userinfo.isvip=='1') ? timelimit[i]['price_vip'] : timelimit[i]['price_normal'];
          }
          that.setData({ goods: timelimit});
          that.formatshowtime();
        }
      })
  },
  formatshowtime(){
    const that = this;
    //清空计时器
    clearInterval(that.data.setInter);
    that.setData({
      nowDateTime: parseInt(new Date().getTime() / 1000),
      goingtime: 0
    })
    that.data.setInter = setInterval(
      function () {
        let goods = that.data.goods;
        const nowDateTime = that.data.nowDateTime;
        let goingtime = that.data.goingtime;
        for (var i = 0; i < goods.length; i++) {
          var startime = goods[i]['time_start'] - nowDateTime - goingtime;
          if (startime <= 0) {
            goods[i]['is_start'] = 1;
            goods[i]['show_start'] = '活动已经开始';
          } else {
            goods[i]['is_start'] = 0;
            goods[i]['startarr'] = App.format_time1(startime);
          }
          var endtime = goods[i]['time_end'] - nowDateTime - goingtime;
          if (endtime <= 0) {
            goods[i]['is_end'] = 1;
            goods[i]['show_end'] = '活动已经结束';
          } else {
            goods[i]['is_end'] = 0;
            goods[i]['endtimarr'] = App.format_time1(endtime);
          }
        }
        goingtime += 1;
        that.setData({ goods: goods, goingtime: goingtime });
      }, 1000
    );
  },
  gotoDetail(e) {
    App.WxService.navigateTo('/pages/shop/seckill/detail/index', {
      id: e.currentTarget.dataset.id
    })
  } ,
  show_return(msg){
    App.WxService.showModal({
      title: '友情提示',
      content: msg,
      showCancel: !1,
    })    
  },
   onShareAppMessage: function (ops) {
    let title = '邀您参加[限时抢购]';
     let path = 'pages/shop/seckill/index?foruid=' + this.data.userinfo.uid;
    //console.log(path);
    return {
      title: title,
      path: path,
    }
  },
  //下拉刷新
  onPullDownRefresh() {
    App.RefreshUserinfo(this.checkLogin);
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  }
})