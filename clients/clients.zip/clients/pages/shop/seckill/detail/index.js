const App = getApp()
var WxParse = require('../../../../wxParse/wxParse.js');
Page({
  data: {
    userinfo:{},
    nowDateTime: parseInt(new Date().getTime() / 1000),
    goingtime:0,
    tlid:4,
    timelimitdb: {},
    gifts:[],
    showTypes:1,
    timelimitorderslist:[],
    showaddress: 0,
    myaddress: [],
    addressid: '0',
    newaddress: { user: '', sex: 1, telphone: '', address: '' },
    remarks: '',
    setInter:''
  },
  onLoad(options) {
    if ('id' in options) {
      this.setData({tlid: options.id })
    }
    //如果是朋友分享过来的记录foruid缓存
    if ('foruid' in options) {
      App.WxService.setStorageSync('foruid', options.foruid);
    }
    this.getDetail(this.data.tlid);
    this.getThisOrder();
  },
  onShow() {    
    const userinfo = App.WxService.getStorageSync('user');
    if (userinfo.uid) {
      this.setData({userinfo: userinfo})
    }
  },
  telCall(e) {
    const tel = e.currentTarget.dataset.id;
    wx.makePhoneCall({
      phoneNumber: tel
    })
  },
  getDetail(id) {
    const that = this;
    const url = App.HttpResource('/smallprogramapi/store/timelimitgetone');
    url.getAsync({ tlid: id })
      .then(res => {        
        const datas = res.data;
        if (datas.meta.code==0){
          const infodata = datas.data;
          //console.log(infodata);
          infodata.timelimitdb.this_price = (that.data.userinfo.isvip == '1') ? infodata.timelimitdb.price_vip : infodata.timelimitdb.price_normal;
          if (infodata.timelimitdb) {
            WxParse.wxParse('article', 'html', infodata.timelimitdb.content, that, 5);
            that.setData({ timelimitdb: infodata.timelimitdb });
            this.format_showtime();
          }
          if (infodata.gifts.length>0){
            that.setData({ gifts: infodata.gifts });
          }
        }else{
          App.WxService.showModal({
            title: '提示',
            content: '没有相应的抢购商品！',
          })
            .then(data => data.confirm == 1 && wx.navigateBack({ changed: true }))
        }
      })
  },
  format_showtime() {
    const that = this;
    //清空计时器
    clearInterval(that.data.setInter);
    that.setData({
      nowDateTime: parseInt(new Date().getTime() / 1000),
      goingtime: 0
    })
    that.data.setInter = setInterval(
      function () {
        let timelimitdb = that.data.timelimitdb;
        const nowDateTime = that.data.nowDateTime;
        let goingtime = that.data.goingtime;
        var startime = timelimitdb.time_start - nowDateTime - goingtime;
        if (startime <= 0) {
          timelimitdb.is_start = 1;
          timelimitdb.show_start = '抢购已经开始';
        } else {
          timelimitdb.is_start = 0;
          timelimitdb.show_start = App.format_time1(startime);
        }
        var endtime = timelimitdb.time_end - nowDateTime - goingtime;
        if (endtime <= 0) {
          timelimitdb.is_end = 1;
          timelimitdb.show_end = '抢购已经结束';
        } else {
          timelimitdb.is_end = 0;
          timelimitdb.show_end = App.format_time1(endtime);
        }
        goingtime += 1;
        that.setData({ goingtime: goingtime, timelimitdb: timelimitdb });
      }, 1000
    );
  },
  ChangeShowType(e) {
    const showTypes = parseInt(e.currentTarget.dataset.id);
    if (showTypes==2){
      //this.getThisOrder();
    }
    this.setData({ showTypes: showTypes });
  },
  getThisOrder(){
    const url = App.HttpResource('/smallprogramapi/store/timelimitorderslist');
    url.getAsync({ tlid: this.data.tlid })
      .then(res => { 
        const timelimitorderslist = res.data.timelimitorderslist;
        for (var i = 0; i < timelimitorderslist.length; i++) {
          timelimitorderslist[i]['post_time'] = App.get_date_time(timelimitorderslist[i]['posttime']);
        }
        if (timelimitorderslist.length>0){
          this.setData({ timelimitorderslist: timelimitorderslist });
        }
        //console.log(timelimitorderslist);
      })
  },
  BuyNow0() {
    App.WxService.showModal({
      title: '提示！',
      content: '还不能抢购！',
    })
  },
  BuyNow(e) {
    if (this.data.userinfo.wx_openid) {
      this.showSelAddress();
      this.setData({
        showaddress: 1
      });
    } else {
      App.WxService.showModal({
        title: '您还没有登录，不能抢购',
        content: '确定要登录吗？',
      })
        .then(data => data.confirm == 1 && App.WxService.redirectTo('/pages/login/index', { url: '/pages/shop/seckill/index' }))
    }
    //console.log(id);
  },
  showSelAddress() {
    const userinfo = App.WxService.getStorageSync('user');
    const url = App.HttpResource('/smallprogramapi/store/getmyaddress')
    url.queryAsync({ 'openid': userinfo.wx_openid })
      .then(res => {
        const datas = res.data.addresslist;
        var checkid = 0;
        for (var i = 0; i < datas.length; i++) {
          if (datas[i]['often'] == '1') {
            // this.setData({
            //   addressid: datas[i]['id']
            // })
            var checkid = datas[i]['id'];
          }
        }
        //console.log(datas);
        if (datas.length > 0) {
          if (checkid == 0) {
            checkid = datas[0]['id'];
          }
          this.setData({
            myaddress: datas,
            addressid: checkid
          })
        } 
        if (this.data.timelimitdb.gettype == 0) {
          this.setData({           
            addressid: -1
          })
        }
      })
  },
  Hideshowaddress() {
    this.setData({
      buyid: 0,
      showaddress: 0,
      newaddress: { user: '', sex: 1, telphone: '', address: '' },
      remarks: ''
    });
  },
  radioChange(e) {
    const addressid = e.detail.value;
    this.setData({
      addressid: addressid
    })
  },
  changessex(e) {
    const sex = parseInt(e.currentTarget.dataset.id);
    this.setData({
      'newaddress.sex': sex
    })
  },
  newaddressName(e) {
    this.setData({
      'newaddress.user': e.detail.value
    })
  },
  newaddressTel(e) {
    this.setData({
      'newaddress.telphone': e.detail.value
    })
  },
  newaddressAdr(e) {
    this.setData({
      'newaddress.address': e.detail.value
    })
  },
  changeremarks(e) {
    this.setData({
      remarks: e.detail.value
    })
  },
  show_return(msg) {
    App.WxService.showModal({
      title: '友情提示',
      content: msg,
      showCancel: !1,
    })
  },
  BuyNow1() {
    let addressid = parseInt(this.data.addressid);
    //如果是使用新地址
    if (addressid == 0 && this.data.timelimitdb.gettype!=0) {
      let newaddress = this.data.newaddress;
      if (newaddress.user == '') {
        this.show_return('请填写联系人姓名' );
        return;
      }
      if (newaddress.telphone == '') {
        this.show_return('请填写联系人电话');
        return;
      }
      if (newaddress.address == '') {
        this.show_return('请填写联系人地址');
        return;
      }
      newaddress.openid = this.data.userinfo.wx_openid;
      newaddress.often = 1;
      const url = App.HttpResource('/smallprogramapi/store/addaddress')
      url.queryAsync(newaddress)
        .then(res => {
          if (res.data.meta.code == 0) {
            this.newadd_order(parseInt(res.data.data.id));
          } else {
            this.show_return('新地址保存失败！');
          }
        })
    } else {
      this.newadd_order(addressid);
    }
  },
  newadd_order(addressid) {
    const remarks = this.data.remarks;
    const tlid = parseInt(this.data.tlid);
    if (tlid > 0 && (addressid > 0 || this.data.timelimitdb.gettype==0 )) {
      const url = App.HttpResource('/smallprogramapi/store/posttimelimitorder')
      url.queryAsync({ tlid: tlid, addrid: addressid, openid: this.data.userinfo.wx_openid, remarks: remarks })
        .then(res => {
          this.Hideshowaddress();
          const datas = res.data;
          if (datas.meta.code == 0) {
            const orderinfo = datas.data.orderinfo; //console.log(orderinfo);
            //进入发起支付
            App.gotopay(
              { 
                'uid': orderinfo.uid,
                'title': orderinfo.goodstitle,
                'paymoney': orderinfo.paymoney,
                'table':'timelimitorder',
                'id': orderinfo.id
              },
              this.payover,
			  this.payerror
            );
          } else {
            App.WxService.showModal({
              title: '提示！',
              content: datas.meta.message,
            })
              .then(data => {
                if (data.confirm == 1) {
                  this.Hideshowaddress();
                } else {
                  this.Hideshowaddress();
                }
              })
          }
        })
    } else {
      this.show_return('参数有误！');
    }
  },
  payover(){
    App.WxService.navigateTo('/pages/user/seckill/index');
  },
  payerror(){
    App.WxService.navigateTo('/pages/user/seckill/index');
  },
  onShareAppMessage: function (ops) {
    let title = '[限时抢购]'+ this.data.timelimitdb.title;
    let path = 'pages/shop/seckill/detail/index?id=' + this.data.timelimitdb.id+'&foruid=' + this.data.userinfo.uid;
    console.log(path);
    return {
      title: title,
      path: path,
    }
  },
  //下拉刷新
  onPullDownRefresh() {
    this.getDetail(this.data.tlid);
    this.getThisOrder();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
})