const App = getApp()
var thisPay = require('../../../wxParse/pay.js');
Page({
  data: {
    orderinfo:{},
    goodsininorder:[],
    userinfo:null,
    id:9,
    showtype:'infos',
    comm_stars:{},
    comm_pic:[],
    comm_pic1: [],
    comm_remarks:''
  },
  onLoad: function (options) {
    if ('id' in options) {this.setData({ id: options.id})}
  },
  onShow() {
    //检查是否登录
    let url = "/pages/shop/order/index";
    const userinfo = App.checkIsLogin(url);
    this.setData({
      userinfo: userinfo
    })
    this.getorderdetail();
    this.get_order_comm();
  },
  showType(e) {
    const tyeps = e.currentTarget.dataset.id;
    this.setData({ showtype: tyeps })
  },
  //获取订单内容
  getorderdetail(){
    const url = App.HttpResource('/smallprogramapi/store/getorder')
    url.queryAsync({
      'openid': this.data.userinfo.wx_openid,
      'orderid': this.data.id,
    })
      .then(res => {
        const datas=res.data;        
        if (datas.orderinfo){
          datas.orderinfo.create_time = App.get_date_time(datas.orderinfo.create_time);
          datas.orderinfo.pay_time = parseInt(datas.orderinfo.pay_time) ? App.get_date_time(datas.orderinfo.pay_time):'还未支付';
          datas.orderinfo.receive_time = parseInt(datas.orderinfo.receive_time) ? App.get_date_time(datas.orderinfo.receive_time) : '还未受理';
          this.setData({
            orderinfo: datas.orderinfo,
            goodsininorder: datas.goodsininorder
          }) 
          //console.log(datas.orderinfo);
        }else{
          App.WxService.showModal({
            title: '友情提示',
            content: datas.meta.message,
            showCancel: !1,
          })
        }
      })
  },
  gotoshop(e) {
    const id = parseInt(e.currentTarget.dataset.id);
    App.WxService.navigateTo('/pages/shop/detail/index', { id: id })
  },
  //获取订单评价
  get_order_comm(){
    const url = App.HttpResource('/smallprogramapi/store/getcommentfororder')
    url.queryAsync({
      'openid': this.data.userinfo.wx_openid,
      'orderid': this.data.id,
    })
      .then(res => {        
        const datas = res.data;
        if (datas.meta.code==0){
          let stars = new Array();
          let pics = new Array();
          let pics1 = new Array();
          let remarks='';
          const comment = datas.data; //console.log(comment);
          for (var i = 0; i < comment.length; i++) {
            stars[i] = comment[i]['star'];
            if (pics.length<1){
              pics = comment[i]['pics'];
              pics1 = comment[i]['pics_lg'];
            }
            if (remarks==''){
              remarks = comment[i]['remarks'];
            }
          }
          this.setData({
            comm_stars: stars,
            comm_pic: pics,
            comm_pic1: pics1,
            comm_remarks: remarks
          }) 
        }
      })
  },
  payorder(){
    const orderinfo = this.data.orderinfo;
    if (orderinfo.pay_status == '1'){
      App.WxService.showModal({
        title: '友情提示',
        content: '该订单已经支付过了，不需要重复支付！',
        showCancel: !1,
      }) 
      return;
    }
    //进入发起支付
    App.gotopay(
      {
        'uid': orderinfo.uid,
        'title': orderinfo.order_sn,
        'paymoney': orderinfo.totalmoney,
        'table': 'storeorder',
        'id': orderinfo.id
      },
      this.payover,
      this.payerror
    );
  },
  gotopayformoney(e) {
    App.WxService.showModal({
      title: '友情提示',
      content: '确定要使用余额进行支付吗？',
    }).then(data => {
      if (data.confirm == true) {
          const index = parseInt(e.currentTarget.dataset.index);
          const orderid = parseInt(e.currentTarget.dataset.id);
          const url = App.HttpResource('/smallprogramapi/store/mymoneypayorder')
          url.queryAsync({
            'openid': this.data.userinfo.wx_openid,
            'orderid': orderid
          })
            .then(res => {
              App.WxService.showModal({
                title: '提示',
                content: res.data.meta.message
              });    
              this.payover();
            })
        } else {
          return false;
        }
      })
    return false;
  },
  payerror() {
  },
  payover() {
    this.getorderdetail();
  },
  comm_order(e){
    const id = parseInt(e.currentTarget.dataset.id);
    App.WxService.navigateTo('/pages/shop/comment/index', { id: id, url:'/pages/shop/orderdetail/index?id='+this.data.id})
  },
  /*******预览幻灯片的图片**********/
  previewImage(e) {
    const index = e.currentTarget.dataset.index;
    let urls = this.data.comm_pic1;
	for (var i = 0; i < urls.length; i++){
      urls[i] = urls[i].replace('http://', "https://")
    }
    const current = urls[Number(index)];
    App.WxService.previewImage({
      current: current,
      urls: urls,
    })
  },
})