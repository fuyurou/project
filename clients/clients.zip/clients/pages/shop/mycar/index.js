const App = getApp()
Page({
  data: {
    userInfo: {},
    mycarishide:true,
    postinfo:{},
    hidePostAddress:true,
    hideSelAddress: true,
    newaddress: {
      sex:1
    },
    addressid:0,
    myaddress:{},
    nomyaddress:true,
    goodscar:{},
    totalprice:0,
    nogoodscar: true,
    my: { data_money:0}
  },
  onLoad() {
    this.getmygoodscar();
    this.defaultaddress();
  },
  onShow() {
    this.checkLogin()
  },
  getmygoodscar(){
    const userinfo = App.WxService.getStorageSync('user');
    if (userinfo.wx_openid){
      const url = App.HttpResource('/smallprogramapi/store/getgoodslistincar')
      url.queryAsync({
        'openid': userinfo.wx_openid
      })
        .then(res => {
          const listdb=res.data.goodslist;
          if (listdb.length > 0){
            //处理数组
            var totalprice=0;
            for (var i = 0; i < listdb.length; i++) {
              listdb[i]['ifchoose'] = 1;
              totalprice += Math.abs(listdb[i]['num'] * listdb[i]['price']);
            }
            this.setData({ goodscar: listdb, totalprice: totalprice, nogoodscar: false,my:res.data.my})
          }else{
            this.setData({ nogoodscar: true })
          }
        })
    }
  },
  checkLogin(){
    const userinfo = App.WxService.getStorageSync('user');
    if (userinfo.wx_openid) {
      this.setData({
        userInfo: userinfo,
        mycarishide: false
      })
    }else{
      App.WxService.showModal({
        title: '您还没有登录，不能查看购物车',
        content: '确定要登录吗？',
      })
        .then(data => data.confirm == 1 && App.WxService.redirectTo('/pages/login/index', { url: '/pages/shop/mycar/index' }))
    }
  },
  handleMsgChange(e) {
    this.setData({
      'postinfo.msg': e.detail.value
    })
  },
  switchChange(e) {
    let ishidename = e.detail.value ? 1 : 0;
    this.setData({
      'postinfo.ishidename': ishidename
    })
  },
  buynow(e){
    var buynows = new Array();
    var carids = new Array();
    const goodscar = this.data.goodscar;
    var j=0;
    let listcars = new Array();
    let listcars1='';
    for (var i = 0; i < goodscar.length; i++) {
      if (goodscar[i]['ifchoose'] == 1) {
        carids[j] = { id: parseInt(goodscar[i]['id']), num: parseInt(goodscar[i]['num'])};
        listcars[j] = parseInt(goodscar[i]['id']) + '-' + parseInt(goodscar[i]['num']);
        j++;
      }
    }
    if (carids.length<1){
      App.WxService.showModal({
        title: '友情提示',
        content: '没有选中任何商品！',
        showCancel: !1,
      })      
      return;
    }else{
      listcars1 = listcars.join('|');
    }
    const addressid = this.data.addressid;
    if (addressid == 0) {
      App.WxService.showModal({
        title: '友情提示',
        content: '没有填写送货地址！',
        showCancel: !1,
      })
      return;
    }
    const ishidename=(this.data.postinfo.ishidename) ? this.data.postinfo.ishidename : '';
    const msg = (this.data.postinfo.msg) ? this.data.postinfo.msg : '';
    const userinfo = App.WxService.getStorageSync('user');
    const paytype=e.currentTarget.dataset.paytype;
    const url = App.HttpResource('/smallprogramapi/store/postorderfromcar');

    if (paytype =='mymoney'){
      //启用余额支付      
      const totalprice = parseFloat(e.currentTarget.dataset.totalprice);
      const mymoeny = parseFloat(e.currentTarget.dataset.mymoeny);
      //console.log('启用余额支付' + totalprice + '|' + mymoeny);
      if (totalprice > mymoeny){
        App.WxService.showModal({
          title: '友情提示',
          content: '您的余额不足以支付该订单！',
          showCancel: !1,
        })
        return false;
      }else{
        App.WxService.showModal({
          title: '友情提示',
          content: '确定要使用￥' + totalprice+'余额进行支付吗？',
        }).then(data => {
          if (data.confirm==true){
            buynows = { 'carids': listcars1, 'addrid': addressid, 'ishidename': ishidename, 'msg': msg, 'openid': userinfo.wx_openid,'paytype':'mymoney' };  
            url.queryAsync(buynows).then(res => {
              const data = res.data
              App.WxService.showModal({
                title: '友情提示',
                content: data.meta.message,
                showCancel: !1,
              })
              this.payover();           
              return;
            })
            return false;
          }else{
            return false;
          }
        })
      }
      return false;
    }else{
      buynows = { 'carids': listcars1,'addrid': addressid, 'ishidename': ishidename, 'msg': msg, 'openid': userinfo.wx_openid};
      //提交到订单的参数carids(购物车中id与数量)addressid（收货地址）ishidename（是否匿名）msg（订单留言）
      //提交订单到         
      url.queryAsync(buynows)
        .then(res => {
          const data = res.data
          if (data.meta.code == 1) {
            App.WxService.showModal({
              title: '友情提示',
              content: data.meta.message,
              showCancel: !1,
            })
          }else{
            const orderinfo = data.data;
            if (parseFloat(orderinfo.totalpay) < 0 || parseInt(orderinfo.orderid) < 1) {
              App.WxService.showModal({
                title: '提示',
                content: '定单参数有误'
              })
              return
            }
            //进入发起支付
            App.gotopay(
              {
                'uid': userinfo.uid,
                'title': orderinfo.ordersn,
                'paymoney': orderinfo.totalpay,
                'table': 'storeorder',
                'id': orderinfo.orderid
              },
              this.payover,
              this.payerror
            );
            //console.log(data);
            //App.WxService.redirectTo('/pages/shop/order/index');
          }
      })
    }
  },
  payerror() {
    App.WxService.redirectTo('/pages/shop/order/index');
  },
  payover() {
    App.WxService.redirectTo('/pages/shop/order/index');
  },
  /***************************************/
  handleTypeChange(e) {
    const value = e.detail.value
    this.setData({
      'newaddress.sex': value
    })
  },
  hidePostAddress(){
    this.setData({
      hidePostAddress: true,
      newaddress: {
        sex: 1,
        name: '',
        tel: '',
        address: ''
      }
    })
  },
  showPostAddress(){
    this.setData({
      hidePostAddress: false
    })
  },
  newaddressName(e) {
    this.setData({
      'newaddress.user': e.detail.value
    })
  },
  newaddressTel(e) {
    this.setData({
      'newaddress.telphone': e.detail.value
    })
  },
  newaddressAdr(e) {
    this.setData({
      'newaddress.address': e.detail.value
    })
  },
  //添加新地址
  addAddress(){
    let newaddress = this.data.newaddress;
    if (newaddress.user==''){
      App.WxService.showModal({
        title: '友情提示',
        content: '请填写联系人姓名',
        showCancel: !1,
      })
      return;
    }
    if (newaddress.telphone == '') {
      App.WxService.showModal({
        title: '友情提示',
        content: '请填写联系人电话',
        showCancel: !1,
      })
      return;
    }
    if (newaddress.address == '') {
      App.WxService.showModal({
        title: '友情提示',
        content: '请填写联系人地址',
        showCancel: !1,
      })
      return;
    }
    newaddress.openid = this.data.userInfo.wx_openid;
    const url = App.HttpResource('/smallprogramapi/store/addaddress')
    url.queryAsync(newaddress)
      .then(res => {
        console.log(res);
        if (res.data.meta.code == 0) {
          const datas = res.data.data;
          this.setData({
            'postinfo.sex': datas.sex,
            'postinfo.user': datas.user,
            'postinfo.telphone': datas.telphone,
            'postinfo.address': datas.address,
            addressid: datas.id
          })
          this.hidePostAddress();
        }else{
          App.WxService.showModal({
            title: '友情提示',
            content: '新地址插入失败！',
            showCancel: !1,
          })
          this.hidePostAddress();
        }
      })    
  },
  defaultaddress(){
    const userinfo = App.WxService.getStorageSync('user');
    const url = App.HttpResource('/smallprogramapi/store/defaultaddress')
    url.queryAsync({ 'openid': userinfo.wx_openid})
      .then(res => {
        if (res.data.meta.code == 0) {
          const datas = res.data.data;
          this.setData({
            'postinfo.sex': datas.sex,
            'postinfo.user': datas.user,
            'postinfo.telphone': datas.telphone,
            'postinfo.address': datas.address,
            addressid: datas.id
          })
        }else{
          this.setData({
            'postinfo.user': '姓名',
            'postinfo.telphone': '联系电话',
            'postinfo.address': '联系地址……',
          })
        }
      }) 
  },
  /****************************/
  radioChange(e){
    const addressid = e.detail.value;
    const myaddress = this.data.myaddress;    
    for (var i = 0; i < myaddress.length; i++) {
      if (myaddress[i]['id'] == addressid){
        this.setData({
          'postinfo.user': myaddress[i]['user'],
          'postinfo.telphone': myaddress[i]['telphone'],
          'postinfo.address': myaddress[i]['address'],
          addressid: addressid,
          hideSelAddress: true
        })
      }
    }
  },
  showSelAddress(){
    this.setData({
      hideSelAddress: false
    })
    const userinfo = App.WxService.getStorageSync('user');
    const url = App.HttpResource('/smallprogramapi/store/getmyaddress')
    url.queryAsync({ 'openid': userinfo.wx_openid })
      .then(res => {
        const datas = res.data.addresslist;
        if (datas.length>0){
          this.setData({
            myaddress: datas,
            nomyaddress:false
          })
        }else{
          this.setData({
            nomyaddress: true
          })
        }
      })
  },
  hideSelAddress(){
    this.setData({
      hideSelAddress: true
    })
  },
  ToaddAddress(){
    this.setData({
      hideSelAddress: true,
      hidePostAddress: false
    })
  },
  /******数量加减******/
  increase(e) {
    const id = e.currentTarget.dataset.id;
    const num = parseInt(e.currentTarget.dataset.a)+1;
    this.formatgoodscar(id, num);
  },
  decrease(e){
    const id = e.currentTarget.dataset.id;
    const num = parseInt(e.currentTarget.dataset.a) - 1;
    if(num<1){
      wx.showModal({
        title: "操作错误",
        content: "数量不能小于1",
        showCancel: false,
        confirmText: "确定"
      })
    }else{
      this.formatgoodscar(id, num);
    }    
  },
  bindKeyInput(e){
    const id = e.currentTarget.dataset.id;
    var num = parseInt(e.detail.value);
    if(num<1){
      num=1;
    }
    this.formatgoodscar(id, num);
  },
  formatgoodscar(id, num){
    // const url = App.HttpResource('/Smallprogramapi/Store/addcar')
    // url.queryAsync({
    //   'openid': this.data.userInfo.wx_openid,
    //   'goodsid': id,
    //   'quantity': num
    // })
    //   .then(res => {
    //     const goodscar = this.data.goodscar;
    //     //处理数组
    //     var totalprice = 0;
    //     for (var i = 0; i < goodscar.length; i++) {      
    //       if (goodscar[i]['goodsid'] == id){
    //         goodscar[i]['num']=num;
    //       }
    //       if (goodscar[i]['ifchoose']==1){
    //         //totalprice += Math.abs(goodscar[i]['num'] * goodscar[i]['price']);
    //         totalprice += Math.abs(goodscar[i]['num']) * Math.abs(goodscar[i]['price']);
    //       }
    //     }
    //     this.setData({ goodscar: goodscar, totalprice: totalprice })
    //   })
    const goodscar = this.data.goodscar;
    //处理数组
    var totalprice = 0;
    for (var i = 0; i < goodscar.length; i++) {      
      if (goodscar[i]['goodsid'] == id){
        goodscar[i]['num']=num;
      }
      if (goodscar[i]['ifchoose']==1){
        //totalprice += Math.abs(goodscar[i]['num'] * goodscar[i]['price']);
        totalprice += Math.abs(goodscar[i]['num']) * Math.abs(goodscar[i]['price']);
      }
    }
    this.setData({ goodscar: goodscar, totalprice: totalprice })
  },
  checkboxChange(e) {
    const id = e.currentTarget.dataset.id;
    var ifchoose = e.detail.value;
    if (ifchoose.length>0){
      ifchoose=1;
    }else{
      ifchoose = 0;
    }
    const goodscar = this.data.goodscar;
    //处理数组
    var totalprice = 0;
    for (var i = 0; i < goodscar.length; i++) {
      if (goodscar[i]['id'] == id) {
        goodscar[i]['ifchoose'] = ifchoose;
      }
      if (goodscar[i]['ifchoose'] == 1) {
        //totalprice += Math.abs(goodscar[i]['num'] * goodscar[i]['price']);
        totalprice += Math.abs(goodscar[i]['num']) * Math.abs(goodscar[i]['price']);
      }
    }
    this.setData({ goodscar: goodscar, totalprice: totalprice })
  },
  delcar(e){
    const id = e.currentTarget.dataset.id;
    const goodscar = this.data.goodscar;    
    const url = App.HttpResource('/Smallprogramapi/Store/removegoodsformcar')
    url.queryAsync({
      'openid': this.data.userInfo.wx_openid,
      'goodsid': id,
    })
      .then(res => {
        var goodcar1 = new Array();
        //处理数组
        var totalprice = 0;
        var j=0;        
        for (var i = 0; i < goodscar.length; i++) {
          if (goodscar[i]['goodsid'] != id) {
            //goodcar1[] = goodscar[i];
            goodcar1[j] = goodscar[i];
            j++;
            if (goodscar[i]['ifchoose'] == 1) {
              totalprice += Math.abs(goodscar[i]['num']) * Math.abs(goodscar[i]['price']);
            }
          }
        }
        if (goodcar1.length<0){
          this.setData({ nogoodscar: true })
        }
        this.setData({ goodscar: goodcar1, totalprice: totalprice })
      })
  },
  clearCar1(){
    const url = App.HttpResource('/Smallprogramapi/Store/emptymycar')
    url.queryAsync({
      'openid': this.data.userInfo.wx_openid,
    })
      .then(res => {
        this.setData({ goodscar: {}, totalprice: 0, nogoodscar: true})
      })
  },
  clearCar() {
    App.WxService.showModal({
      title: '是否确定清空购物车？',
      content: '确定清空',
    })
      .then(data => data.confirm == 1 && this.clearCar1())
  }
})