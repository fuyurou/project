const App = getApp()
Page({ 
  data:{
    userinfo: {},
    myorderinfo:{
      status:0,
      p:1,
      listdb:[],
      maxp:1
    }
  },
  onLoad(options) {
    this.checkLogin();
    if ('status' in options) {
      this.setData({
        'myorderinfo.status': parseInt(options.status)
      })
    }
    this.getmyorders();
  },
  onShow(){
    this.checkLogin();
    const myorders = this.data.myorderinfo.listdb;
    if (myorders[0]){
      this.setData({
        'myorderinfo.p': 1,
        'myorderinfo.maxp': 1,
        'myorderinfo.totalnum': 0,
        'myorderinfo.listdb': [],
        'myorderinfo.status': 0
      })
      this.getmyorders();
    }
  },
  checkLogin() {
    //App.RefreshUserinfo()
    const myinfo = App.WxService.getStorageSync('user'); //console.log(myinfo);
    if (myinfo.wx_openid) {
      this.setData({
        userinfo: myinfo
      })
    } else {
      App.WxService.redirectTo('/pages/login/index', { url: '/pages/user/index' });
    }
  },
  showType(e){
    const status = parseInt(e.currentTarget.dataset.id);
    this.setData({
      'myorderinfo.p': 1,
      'myorderinfo.maxp': 1,
      'myorderinfo.totalnum':0,
      'myorderinfo.listdb': [],
      'myorderinfo.status': status
    })
    this.getmyorders();
  },
  getmyorders(){
    const myorderinfo = this.data.myorderinfo;
    if (myorderinfo.p <= myorderinfo.maxp){
      const url = App.HttpResource('/smallprogramapi/store/getorderslist')
      url.queryAsync({
        'openid': this.data.userinfo.wx_openid,
        'p': myorderinfo.p,
        'status': myorderinfo.status
      })
        .then(res =>{
          let orderlistdb = res.data.orderlistdb;
          if (orderlistdb){
            for (var i = 0; i < orderlistdb.length; i++) {
              orderlistdb[i]['create_time'] = App.get_date_time(orderlistdb[i]['create_time']);
              orderlistdb[i]['shopnum'] = orderlistdb[i]['goodsinorder'].length;
            }
            const listorder1 = [...myorderinfo.listdb, ...orderlistdb]
            this.setData({
              'myorderinfo.p': myorderinfo.p + 1,
              'myorderinfo.maxp': res.data.pagearray.total_page,
              'myorderinfo.totalnum': res.data.pagearray.total,
              'myorderinfo.listdb': listorder1
            })
            //console.log(listorder1);
          }
        })
    }
  },
  //页面上拉触底事件的处理函数
  onReachBottom: function () {
    this.getmyorders();
  },
  gotocomm(e){
    const id = parseInt(e.currentTarget.dataset.id);
    App.WxService.navigateTo('/pages/shop/comment/index', { id: id, url:'/pages/shop/order/index'})
  },
  receiveorder(e){
    const id = parseInt(e.currentTarget.dataset.id);
    const url = App.HttpResource('/smallprogramapi/store/receiveorder')
    url.queryAsync({
      'openid': this.data.userinfo.wx_openid,
      'orderid': id
    })
      .then(res => {        
        if(res.data.meta.code == 0){
          App.WxService.showModal({
            title: '提示',
            content: res.data.meta.message
          })
            .then(data => { 
              if (data.confirm == 1){
                App.WxService.navigateTo('/pages/shop/comment/index', { id: id, url: '/pages/shop/order/index' })
              }else{
                this.receive_statusover(id);
              }
            })
        }
       })
  },
  receive_statusover(id){
    let myorderinfo = this.data.myorderinfo;
    for (var i = 0; i < myorderinfo.listdb.length; i++) {
      if (parseInt(myorderinfo.listdb[i]['id']) == id) {
        myorderinfo.listdb[i]['receive_status'] = '1';
      }
    }
    this.setData({
      myorderinfo: myorderinfo
    })
  },
  gotopay(e){
  
    const index = parseInt(e.currentTarget.dataset.id);
    const myorderinfo = this.data.myorderinfo;
    const orderinfo = myorderinfo.listdb[index];
    if (orderinfo.pay_status == '1' || parseFloat(orderinfo.totalmoney) < 0 || parseInt(orderinfo.id) < 1) {
      App.WxService.showModal({
        title: '提示',
        content: '定单参数有误'
      })
      return
    }
    //进入发起支付
    App.gotopay(
      {
        'uid': orderinfo.uid,
        'title': orderinfo.goodsremarks,
        'paymoney': orderinfo.totalmoney,
        'table': 'storeorder',
        'id': orderinfo.id
      },
      this.payover,
      this.payerror
    );
    this.setData({
      payindex: index
    })
  },
  gotopayformoney(e) {
    App.WxService.showModal({
      title: '友情提示',
      content: '确定要使用余额进行支付吗？',
    }).then(data => {
      if (data.confirm == true) {
        const index = parseInt(e.currentTarget.dataset.index);
        const orderid = parseInt(e.currentTarget.dataset.id); 
        const url = App.HttpResource('/smallprogramapi/store/mymoneypayorder')
        url.queryAsync({
          'openid': this.data.userinfo.wx_openid,
          'orderid': orderid
        }).then(res => {        
            App.WxService.showModal({
              title: '提示',
              content: res.data.meta.message
            });
            this.setData({
              payindex: res.data.meta.code==0?index:0
            });
            this.payover();
        })
      }else{
        return false;
      }
    })
    return false;
  },
  payerror(){
    //支付错误时的操作
  },
  payover() {
    const payindex = this.data.payindex;
    const myorderinfo = this.data.myorderinfo;
    for (var i = 0; i < myorderinfo.listdb.length; i++) {
      if (i == payindex) {
        myorderinfo.listdb[i]['pay_status'] = '1';
      }
    }
    this.setData({
      myorderinfo: myorderinfo
    })
  },
  //下拉刷新
  onPullDownRefresh() {
    //改变参数才能页面刷新
    this.setData({
      'myorderinfo.p': 1,
      'myorderinfo.maxp': 1,
      'myorderinfo.totalnum': 0,
      'myorderinfo.listdb': []
    })
    this.getmyorders();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
})