const App = getApp()
Page({
  data: {
    userinfo: {},
    givepwd: '',
    myzmkorders: [],
    baseinfo: {},
    checkzmk: { id: 0, mid: 0, show: 0 }
  },
  onLoad(options) {
    //检查是否登录
    let url = "/pages/pri/index";
    const userinfo = App.checkIsLogin(url);
    this.setData({ userinfo: userinfo })
    this.getmyzmkorders();
    this.getbaseinfo();
  },
  getbaseinfo() {
    const url = App.HttpResource('/smallprogramapi/business/getinfo')
    url.queryAsync()
      .then(res => {
        const datas = res.data;
        if (datas.meta.code == 0) {
          const baseinfo = datas.data;
          this.setData({
            baseinfo: baseinfo
          })
        }
      })
  },
  showFuCar(e) {
    const id = e.currentTarget.dataset.id;
    App.WxService.navigateTo('/pages/pri/share/index', { id: id })
    //console.log(id);
  },
  //打电话
  topPhoneCall() {
    wx.makePhoneCall({
      phoneNumber: this.data.baseinfo.contact_tel
    })
  },
  //打开地图
  topOpenMap() {
    const baseinfo = this.data.baseinfo;
    var maparr = baseinfo.contact_map.split(",");
    const latitude = parseFloat(maparr[0]);
    const longitude = parseFloat(maparr[1]);
    wx.openLocation({
      latitude: latitude,
      longitude: longitude,
      scale: 18,
      name: baseinfo.fullname,
      address: baseinfo.contact_address
    })
  },
  getmyzmkorders() {
    const url = App.HttpResource('/smallprogramapi/zmk/getzmkorderchildren');
    url.getAsync({ openid: this.data.userinfo.wx_openid })
      .then(res => {
        const datas = res.data;
        const zmkorderchildren = datas.zmkorderchildren;
        //console.log(zmkorderchildren);
        if (zmkorderchildren.length > 0) {
          this.setData({ myzmkorders: zmkorderchildren })
        }else{
          this.setData({ myzmkorders: null })
        }
        //console.log(zmkorderchildren);
      })
  },
  passChange(e) {
    let givepwd = e.detail.value;
    this.setData({ givepwd: givepwd })
  },
  checkzmkorderchildren(e) {
    const checkzmk = e.currentTarget.dataset;
    this.setData({
      'checkzmk.id': checkzmk.id,
      'checkzmk.mid': checkzmk.mid,
      'checkzmk.show': 1
    })
  },
  HideCheckzmk() {
    this.setData({
      'checkzmk.id': 0,
      'checkzmk.mid': 0,
      'checkzmk.show': 0,
      givepwd: ''
    })
  },
  PostCheckzmk() {
    const checkzmk = this.data.checkzmk;
    if (checkzmk.id == 0) {
      this.show_return('没有对应的副卡');
      return;
    }
    if (checkzmk.mid == 0) {
      this.show_return('没有对应的主卡');
      return;
    }
    if (this.data.givepwd == '') {
      this.show_return('请输入核销密码');
      return;
    }
    const url = App.HttpResource('/smallprogramapi/zmk/checkzmkorderchildren');
    url.getAsync({
      openid: this.data.userinfo.wx_openid,
      zmkorderchildrenid: checkzmk.id,
      checkpwd: this.data.givepwd
    })
      .then(res => {
        const meta = res.data.meta;
        if (meta.code == 1) {
          this.show_return(meta.message);
          return;
        } else {
          this.show_return(meta.message);
          this.getmyzmkorders();
          this.HideCheckzmk();
        }
        //console.log(meta);
      })
  },
  show_return(msg) {
    App.WxService.showModal({
      title: '友情提示',
      content: msg,
      showCancel: !1,
    })
  },
  //下拉刷新
  onPullDownRefresh() {
    this.getmyzmkorders();
    this.getbaseinfo();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
})