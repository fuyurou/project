const App = getApp()
Page({
  data: {
    userinfo: {},
    zmkorders:{},
    id:81
  },
  onLoad(option) {
    if ('foruid' in option) {
      App.WxService.setStorageSync('foruid', option.foruid);
    }
    if ('id' in option) {
      this.setData({ id: option.id })
    }
    App.RefreshUserinfo(this.checkLogin)
  },
  onShow: function () {
    // const myinfo = App.WxService.getStorageSync('user');
    // if (myinfo.uid != this.data.userinfo.uid){
    //   App.RefreshUserinfo(this.checkLogin)
    // }
  },
  checkLogin() {
    const myinfo = App.WxService.getStorageSync('user');
    if (!myinfo.wx_openid) {
      App.WxService.redirectTo('/pages/login/index', { url: '/pages/pri/share/index?id='+this.data.id });
    } else {
      this.setData({
        userinfo: myinfo
      })
      this.getzmkorders();
    }
  },
  getzmkorders() {
    const url = App.HttpResource('/smallprogramapi/zmk/getzmkorderchildreninfo');
    url.getAsync({ zmkorderchildrenid: this.data.id })
      .then(res => {
        const datas = res.data;
        if (datas.meta.code==0){
          const datainfo = datas.data;
          this.setData({ zmkorders: datainfo })
          //console.log(datainfo);
          //this.postzmkorderchildren();
        }else{
          App.WxService.showModal({
            title: '提示',
            content: '没有相应的副卡！',
          })
            .then(data => data.confirm == 1 && wx.navigateBack({ changed: true }))
        }
      })
  },
  postzmkorderchildren(){
    const zmkorders = this.data.zmkorders;
    if (zmkorders.activetype == '2'){
      // const orders = {
      //   'uid': this.data.userinfo.uid,
      //   'title': zmkorders.zmkchildrentitle,
      //   'paymoney': zmkorders.needpay,
      //   'table': 'buyzmkchl',
      //   'id': zmkorders.id
      // }
      // console.log(orders);
      //进入发起支付
      App.gotopay(
        {
          'uid': this.data.userinfo.uid,
          'title': zmkorders.zmkchildrentitle,
          'paymoney': zmkorders.needpay,
          'table': 'buyzmkchl',
          'id': zmkorders.id
        },
        this.payover,
        this.payerror
      ); 
    }else{
      const url = App.HttpResource('/smallprogramapi/zmk/postzmkorderchildren');
      url.getAsync({
        openid: this.data.userinfo.wx_openid,
        zmkorderid: this.data.zmkorders.zmk_mather_orderid,
        zmkorderchildrenid: this.data.id
      })
        .then(res => {
          const meta = res.data.meta;
          if (meta.code == 0) {
            App.WxService.showModal({
              title: '提示',
              content: meta.message,
              showCancel: !1,
            })
              .then(data => data.confirm == 1 && App.WxService.redirectTo('/pages/pri/myorder/index'))
          } else {
            App.WxService.showModal({
              title: '提示',
              content: meta.message,
            })
          }
        }) 
    }
  },
  payerror() {
    //支付错误时的操作
  },
  payover() {
    App.WxService.redirectTo('/pages/pri/myorder/index')
  },
  onShareAppMessage: function (ops) {
    let title = this.data.userinfo.nikename + "特意送您《" + this.data.zmkorders.zmkchildrentitle +"》";
    let path = 'pages/pri/share/index?id=' + this.data.id + '&foruid=' + this.data.userinfo.uid;
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: title,
      path: path,
      success: function (res) {
        //console.log(res);
        console.log("转发成功:");
      },
      fail: function (res) {
        console.log("转发失败:");
      }
    }
  }
})