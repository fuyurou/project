const App = getApp()
import config from '../../etc/config'
Page({
  data: {
    userinfo: {},
    showTypes:1,
    activeIndex:0,
    prinownum:0,
    primaxnum:0,
    priinfos:[],
    showmores:1,
    postzmkorder:0,
    postzmkorder1: 0,
    givepwd:'',
    zmkid:0,
    zmkorderid:0,
    childorder:{},
    myzmkorders:[],
    checkzmk:{id:0,mid:0,show:0},
    baseinfo: {},
  },
  onLoad(option) {
    if ('show' in option) {
      console.log(option.show);
    }
    if ('shows' in option) {
      this.setData({ showTypes: option.shows })
    }
    this.checkLogin();
  },
  onShow() {
    this.setData({ showTypes: 1 })
    this.checkLogin();
  },
  checkLogin(){
    const userinfo = App.WxService.getStorageSync('user');
    if (!userinfo.wx_openid) {
      App.WxService.redirectTo('/pages/login/index', { url: '/pages/pri/index' });
    }else{
      this.setData({ userinfo: userinfo })
      this.priinfos();
      this.getbaseinfo();
    }
  },
  getbaseinfo() {
    const url = App.HttpResource('/smallprogramapi/business/getinfo')
    url.queryAsync()
      .then(res => {
        const datas = res.data;
        if (datas.meta.code == 0) {
          const baseinfo = datas.data;          
          this.setData({
            baseinfo: baseinfo
          })
        }
      })
  },
  //打电话
  topPhoneCall() {
    wx.makePhoneCall({
      phoneNumber: this.data.baseinfo.contact_tel
    })
  },
  //打开地图
  topOpenMap() {
    const baseinfo = this.data.baseinfo;
    var maparr = baseinfo.contact_map.split(",");
    const latitude = parseFloat(maparr[0]);
    const longitude = parseFloat(maparr[1]);
    wx.openLocation({
      latitude: latitude,
      longitude: longitude,
      scale: 18,
      name: baseinfo.fullname,
      address: baseinfo.contact_address
    })
  },
  //下拉刷新
  onPullDownRefresh(){
    this.priinfos();
    this.getbaseinfo();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
  priinfos(){
    const url = App.HttpResource('/smallprogramapi/zmk/getzmklist');
    url.getAsync({ openid: this.data.userinfo.wx_openid })
      .then(res => { 
        const datas=res.data;
        if (!datas.meta){
          let zmklist = datas.zmklist;
          if (zmklist.length > 0) {
            for (var i = 0; i < zmklist.length; i++) {
              zmklist[i]['timestart'] = App.get_date_time(zmklist[i]['time_start']);
              zmklist[i]['timeend'] = App.get_date_time(zmklist[i]['time_end']);
              var childnum = parseInt(zmklist[i]['children_num']);
              if (childnum > 0) {
                zmklist[i]['starts'] = new Array(childnum);
              }
              var myorder = zmklist[i]['myorder'];
              if (myorder) {
                zmklist[i]['starts1'] = new Array(parseInt(myorder.star_1));
                zmklist[i]['starts2'] = new Array(parseInt(myorder.star_2));
              }
              if (zmklist[i]['children_orders'] == false) {
                var thisorders = new Array();
                for (var j = 0; j < parseInt(zmklist[i]['children_num']); j++) {
                  thisorders[j] = j;
                }
                zmklist[i]['childrenorders'] = thisorders;
              } else {
                zmklist[i]['childrenorders'] = zmklist[i]['children_orders'];
              }
            }
            const prinownum = parseInt(this.data.prinownum); //console.log(zmklist);
            this.setData({ priinfos: zmklist, primaxnum: zmklist.length - 1, childorder: zmklist[prinownum] })
            this.getmyzmkorders();
          }
        }else{
          App.WxService.showModal({
            title: '友情提示',
            content: datas.meta.message,
            showCancel: !1,
          })
            .then(data => {
              App.WxService.redirectTo('/pages/login/index', { url: '/pages/pri/index' });
            })
        }
      })
  },
  getmyzmkorders(){
    const url = App.HttpResource('/smallprogramapi/zmk/getzmkorderchildren'); 
    url.getAsync({ openid: this.data.userinfo.wx_openid })
      .then(res => { 
        const datas = res.data;
        const zmkorderchildren = datas.zmkorderchildren;
        if (zmkorderchildren.length>0){
          this.setData({ myzmkorders: zmkorderchildren })
        }
        //console.log(zmkorderchildren);
      })
  },
  HideZmkorder(){
    this.setData({ givepwd: '', postzmkorder:0})
  },
  passChange(e) {
    let givepwd = e.detail.value;
    this.setData({givepwd: givepwd})
  },
  bindChange(e) {
    var current = parseInt(e.detail.current);
    const priinfos = this.data.priinfos;
    //console.log(priinfos[current]);
    this.setData({
      prinownum: current,
      childorder: priinfos[current]
    })
  },
  showTypes(e){
    this.setData({
      showTypes: parseInt(e.currentTarget.dataset.id)
    })
  },
  showTypes2(){
    App.WxService.navigateTo('/pages/pri/myorder/index')
  },
  showmores(e){
    this.setData({
      showmores: parseInt(e.currentTarget.dataset.id)
    })
  },
  receive_pri(e){
    const id = parseInt(e.currentTarget.dataset.id);
    this.setData({ postzmkorder: 1, zmkid:id })
  },
  PostZmkorder(){
    if (this.data.zmkid==0){
      this.show_return('没有选中要领取的主卡');
      return;
    }
    if (this.data.givepwd == '') {
      this.show_return('请输入领到密码');
      return;
    }
    const url = App.HttpResource('/smallprogramapi/zmk/postzmkorder');
    url.getAsync({ 
      openid: this.data.userinfo.wx_openid,
      zmkid: this.data.zmkid,
      checkpwd: this.data.givepwd
    })
      .then(res => { 
        const datas=res.data;
        if (datas.meta.code==1){
          this.show_return(datas.meta.message);
        }else{
          App.WxService.showModal({
            title: '友情提示',
            content: '恭喜您主卡领取成功',
            showCancel: !1,
          })
            .then(res1 => {
              this.HideZmkorder();
              this.priinfos();
             })
        }
      })
  },
  show_return(msg) {
    App.WxService.showModal({
      title: '友情提示',
      content: msg,
      showCancel: !1,
    })
  },
  ShowNext(){
    const prinownum = this.data.prinownum;
    if (prinownum < this.data.primaxnum){
      this.setData({
        prinownum: prinownum+1,
        activeIndex: prinownum+1
      })
    }
  },
  ShowPrav(){
    const prinownum = this.data.prinownum;
    if (prinownum > 0) {
      this.setData({
        prinownum: prinownum - 1,
        activeIndex: prinownum - 1
      })
    }
  },
  checkzmkorderchildren(e) {
    const checkzmk = e.currentTarget.dataset;
    this.setData({
      'checkzmk.id': checkzmk.id,
      'checkzmk.mid': checkzmk.mid,
      'checkzmk.show': 1
    })
  },
  showFuCar(e){
    const id = e.currentTarget.dataset.id;
    App.WxService.navigateTo('/pages/pri/share/index', { id: id})
    //console.log(id);
  },
  HideCheckzmk(){
    this.setData({
      'checkzmk.id': 0,
      'checkzmk.mid': 0,
      'checkzmk.show': 0,
      givepwd:''
    })
  },
  PostCheckzmk(){
    const checkzmk = this.data.checkzmk;
    if (checkzmk.id==0){
      this.show_return('没有对应的副卡');
      return;
    }
    if (checkzmk.mid == 0) {
      this.show_return('没有对应的主卡');
      return;
    }
    if (this.data.givepwd == '') {
      this.show_return('请输入核销密码');
      return;
    }
    const url = App.HttpResource('/smallprogramapi/zmk/checkzmkorderchildren');
    url.getAsync({ 
      openid: this.data.userinfo.wx_openid,
      zmkorderchildrenid: checkzmk.id,
      checkpwd: this.data.givepwd
    })
      .then(res => { 
        const meta = res.data.meta;
        if (meta.code==1){
          this.show_return(meta.message);
          return;
        }else{
          this.show_return(meta.message);
          this.getmyzmkorders();
          this.HideCheckzmk();
        }
        console.log(meta);
      })
  },
  checkzmkorder(e) {
    const id = parseInt(e.currentTarget.dataset.id);
    this.setData({ postzmkorder1: 1, zmkorderid: id })
  },
  HideCheckzmkorder(){
    this.setData({ postzmkorder1: 0, zmkorderid: 0, givepwd:'' })
  },
  PosCheckzmkorder() {
    if (this.data.zmkorderid == 0) {
      this.show_return('没有选中要核销的主卡');
      return;
    }
    if (this.data.givepwd == '') {
      this.show_return('请输入核销密码');
      return;
    }
    const url = App.HttpResource('/smallprogramapi/zmk/checkzmkorder');
    url.getAsync({
      openid: this.data.userinfo.wx_openid,
      zmkorderid: this.data.zmkorderid,
      checkpwd: this.data.givepwd
    })
      .then(res => {
        const datas = res.data;
        if (datas.meta.code == 1) {
          this.show_return(datas.meta.message);
        } else {
          App.WxService.showModal({
            title: '友情提示',
            content: '恭喜您主卡核销成功',
            showCancel: !1,
          })
            .then(res1 => {
              this.HideCheckzmkorder();
              this.priinfos();
            })
        }
      })
  },
  onShareAppMessage(ops) {
    let title = '分享特权卡';
    let path = 'pages/forcode/index?foruid=' + this.data.userinfo.uid + '&tabname=pri';
    console.log(path);
    return {
      title: title,
      path: path,
    }
  },
})