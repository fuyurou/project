const App = getApp()
var timer;
Page({
  data: {
    userInfo: {},
    money:'',
    mycodeimg:'',
    showcodeimg:0,
    erkey:''
  },  
  onLoad: function (options) {
    App.RefreshUserinfo(this.checkLogin)
  },
  checkLogin() {
    const myinfo = App.WxService.getStorageSync('user');
    if (!myinfo.wx_openid) {
      App.WxService.redirectTo('/pages/login/index', { url: '/pages/user/paymoney/index' });
    } else {
      //console.log(myinfo)
      const money = parseFloat(myinfo.money);
      if (money <= 0){
        App.WxService.showModal({
          title: '提示！',
          content: '您的没有可以支付的余款',
          showCancel: !1,
        })
          .then(res => { 
            App.WxService.switchTab('/pages/user/index');
          })
      }
      this.setData({userInfo: myinfo})
    }
  },
  nomeyChange(e) {
    let money = this.checkmoney(e.detail.value);
    const mymoney = parseFloat(this.data.userInfo.money);
    if (money > mymoney){
      App.WxService.showModal({
        title: '提示！',
        content: '您支付的金额超出您的帐户余额！',
        showCancel: !1,
      })
      money='';
    }
    this.setData({
      money: money
    })
  },
  //金额输入限制
  checkmoney(money) {
    var regStrs = [
      ['^0(\\d+)$', '$1'], //禁止录入整数部分两位以上，但首位为0  
      ['[^\\d\\.]+$', ''], //禁止录入任何非数字和点  
      ['\\.(\\d?)\\.+', '.$1'], //禁止录入两个以上的点  
      ['^(\\d+\\.\\d{2}).+', '$1'] //禁止录入小数点后两位以上  
    ];
    for (var i = 0; i < regStrs.length; i++) {
      var reg = new RegExp(regStrs[i][0]);
      money = money.replace(reg, regStrs[i][1]);
    }
    return money;
  },
  formSubmit: function (e) {
    const inputs = e.detail.value;
    const userInfo = this.data.userInfo;
    const mymoney = parseFloat(userInfo.money);
    const money = parseFloat(inputs.money);
    if (!money || money > mymoney) {
      App.WxService.showModal({
        title: '提示！',
        content: '支付金额不对！',
        showCancel: !1,
      })
        .then(data => {
          this.setData({money: '' })
        })
      return;
    } 
    const url = App.HttpResource('/smallprogramapi/business/showofflinepayqr')
    url.queryAsync({
      'openid': userInfo.wx_openid,
      'paymoney': money
    })
      .then(res => { 
        const datas = res.data;
        if (datas.meta.code == 0){
          //console.log(datas.data);
          this.setData({ mycodeimg: datas.data.qrurl, showcodeimg: 1, erkey: datas.data.erkey})
          this.paymoneyover();
        }else{
          App.WxService.showModal({
            title: '提示！',
            content: datas.meta.message,
            showCancel: !1,
          })
        }
      })
  },
  HideMyCodeBox() {
    this.setData({
      showcodeimg: 0
    })
    clearTimeout(timer);
  },
  paymoneyover(){
    const erkey = this.data.erkey;
    const that = this;
    const url = App.__config.basePath + '/smallprogramapi/business/getofflinepaystatus';
    wx.request({
      url: url,
      data: {'erkey': erkey},
      method: "POST",
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function(res){
        if (res.data.meta.code == 0) {
          clearTimeout(timer);
          App.WxService.showModal({
            title: '提示！',
            content: '余额支付成功',
            showCancel: !1,
          })
            .then(data => { 
              App.RefreshUserinfo(that.afterpaymoney);
            })
        } else {
          timer = setTimeout(function () {
            that.paymoneyover();
          }, 1000)
        }
      }
    })
    //console.log(url);
    // const url = App.HttpResource('/smallprogramapi/business/getofflinepaystatus')
    // url.queryAsync({
    //   'erkey': erkey
    // })
    //   .then(res => {
    //     //console.log(res.data);
    //     if (res.data.meta.code == 0) {
    //       clearTimeout(timer);
    //       App.WxService.showModal({
    //         title: '提示！',
    //         content: '余额支付成功',
    //         showCancel: !1,
    //       })
    //         .then(data => { 
    //           App.RefreshUserinfo(that.afterpaymoney);
    //         })
    //     } else {
    //       timer = setTimeout(function () {
    //         that.paymoneyover();
    //       }, 1000)
    //     }
    //    })
  },
  afterpaymoney(){
    App.WxService.switchTab('/pages/user/index');
  }
})