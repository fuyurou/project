const App = getApp();
Page({
  data: {
    userInfo: {},
    listytpe: { 'type': 0, 'p': 1, 'totalP': 1 },
    myvoucher: [],
    myvoucher0: [],
    ListSorts: 'default',
    postpw: {},
    setInter1: ''
  },
  onLoad(options) {
    this.checkLogin();
    this.getmyvoucher();
  },
  onHide(){
    //页面隐藏清除检测卡券核销状态
    clearInterval(this.data.setInter1);
  },
  onUnload() {
    //页面卸载清除检测卡券核销状态
    clearInterval(this.data.setInter1);
  },
  checkLogin() {
    let url = "/pages/user/myvip/index";
    const userinfo = App.checkIsLogin(url);
    this.setData({ userInfo: userinfo })
  },
  ListType(e) {
    const thistype = parseInt(e.currentTarget.dataset.id);
    this.setData({
      myvoucher: [],
      myvoucher0: [],
      'listytpe.type': thistype,
      'listytpe.p': 1,
      'listytpe.totalP': 1,
      ListSorts: 'default'
    })
    this.getmyvoucher();
  },
  ListSorts(e) {
    const thistype = e.currentTarget.dataset.id;
    this.setData({
      myvoucher: [],
      'listytpe.p': 1,
      'listytpe.totalP': 1,
      ListSorts: thistype
    })
    //this.setData({ ListSorts: thistype})
    this.getmyvoucher();
  },
  ShowListSorts(thistype) {
    const myvoucher0 = this.data.myvoucher0;
    //console.log(myvoucher0);
    if (thistype == '') {
      this.setData({ myvoucher: myvoucher0 })
    } else {
      let listdb = new Array();
      var j = 0;
      for (var i = 0; i < myvoucher0.length; i++) {
        if (myvoucher0[i]['fromkey'] == thistype) {
          listdb[j] = myvoucher0[i];
          j++
        }
      }
      this.setData({ myvoucher: listdb })
    }
  },
  telCall(e) {
    const tel = e.currentTarget.dataset.id;
    wx.makePhoneCall({
      phoneNumber: tel
    })
  },
  getmyvoucher() {
    const listytpe = this.data.listytpe;
    let page = listytpe.p;
    if (page <= listytpe.totalP) {
      const url = App.HttpResource('/smallprogramapi/voucher/getmyvoucher')
      url.queryAsync({
        'openid': this.data.userInfo.wx_openid,
        'p': page,
        'isused': listytpe.type,
        'fromkey': this.data.ListSorts
      })
        .then(res => {
          const datas = res.data;
          const myvoucher = this.data.myvoucher;
          let listdb = datas.myvoucherlist;
          for (var i = 0; i < listdb.length; i++) {
            listdb[i]['lastuse_time'] = App.get_date_time(listdb[i]['lastusetime']);
          }
          let myvoucher1 = [...myvoucher, ...listdb]
          const totaP = datas.pagearray.total_page;
          this.setData({
            'listytpe.p': page + 1,
            'listytpe.totalP': totaP,
            myvoucher: myvoucher1
          })
          //this.ShowListSorts(this.data.ListSorts);
          //console.log(listdb);
        })
    }

  },
  //页面上拉触底事件的处理函数
  onReachBottom() {
    this.getmyvoucher();
  },
  show_return(msg) {
    App.WxService.showModal({
      title: '友情提示',
      content: msg,
      showCancel: !1,
    })
  },
  userCar(e) {
    const index = parseInt(e.currentTarget.dataset.index);
    const thisCar = this.data.myvoucher[index];
    const nowtime = parseInt(new Date().getTime() / 1000);
    if (thisCar.aftercanuse > nowtime) {
      var note1 = '';
      if (thisCar.voucher_checkonce == '1') {
        note1 = '每天只能用一次';
      } else if (thisCar.voucher_checkonce == '2') {
        note1 = '每周只能用一次';
      } else if (thisCar.voucher_checkonce == '3') {
        note1 = '每月只能用一次';
      }
      this.setData({
        postpw: {
          'showbox': 1, 'nouse': 1, 'name': '当前卡券还不能使用', 'note1': note1, 'time': App.get_date_time(thisCar.aftercanuse)
        }
      })
      return;
    }
    const id = parseInt(e.currentTarget.dataset.id);
    const url = App.HttpResource('/smallprogramapi/voucher/showvoucherqr')
    url.queryAsync({
      'openid': this.data.userInfo.wx_openid,
      'voucherorderid': id
    })
      .then(res => {
        const datas = res.data;
        if (datas.meta.code == 0) {
          this.setData({
            postpw: { 'orderid': id, 'showbox': 1, 'pw': '', 'num': 1, 'qrurl': datas.data.qrurl, 'erkey': datas.data.erkey }
          })
          this.uservoucherover();
        } else {
          this.setData({
            postpw: { 'orderid': id, 'showbox': 1, 'pw': '', 'num': 1, 'qrurl': 'error', 'usertype': '1' }
          })
        }
      })
  },
  uservoucherover() {
    const that = this;
    var limittime = 0;
    clearInterval(that.data.setInter1);
    that.data.setInter1 = setInterval(
      function () {
        limittime += 2;
        if (limittime>120){
          clearInterval(that.data.setInter1);
        }
        const erkey = that.data.postpw.erkey;
        const url = App.__config.basePath + '/smallprogramapi/voucher/uservoucherstatus';
        wx.request({
          url: url,
          data: { 'erkey': erkey },
          method: "POST",
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            if (res.data.meta.code == 0) {
              that.HidePostpw();
              App.WxService.showModal({
                title: '提示！',
                content: '核销成功',
                showCancel: !1,
              })
                .then(data => {
                  //改变参数才能页面刷新
                  that.setData({
                    myvoucher: [],
                    myvoucher0: [],
                    'listytpe.p': 1,
                    'listytpe.totalP': 1
                  })
                  that.getmyvoucher();
                })
            }
          }
        })
      }, 2000);
  },
  HidePostpw() {
    clearInterval(this.data.setInter1);
    this.setData({
      postpw: {}
    })
  },
  MoveUseNum() {
    let num = this.data.postpw.num;
    if (num < 2) {
      this.show_return('使用数量必须是大于1！');
    } else {
      num--;
    }
    this.setData({ 'postpw.num': num })
  },
  AddUseNum() {
    this.setData({ 'postpw.num': this.data.postpw.num + 1 })
  },
  numChange(e) {
    let num = e.detail.value;
    if (!this.checkInt(num)) {
      this.show_return('使用数量必须是大于1的整数！');
      num = 1;
    }
    this.setData({ 'postpw.num': num })
  },
  checkInt(num) {
    let pat = new RegExp('^[0-9]+$');
    return pat.test(num)
  },
  CheckPostpw() {
    const pwinfo = this.data.postpw;
    if (!pwinfo.orderid) {
      this.show_return('没有指定使用的卡券');
      return;
    }
    if (pwinfo.pw == '') {
      this.show_return('没有输入使用密码');
      return;
    }
    const url = App.HttpResource('/smallprogramapi/voucher/checkone')
    url.queryAsync({
      'openid': this.data.userInfo.wx_openid,
      'voucherorderid': pwinfo.orderid,
      'checkpwd': pwinfo.pw,
      'vouchernum': pwinfo.num
    })
      .then(res => {
        const meta = res.data.meta;
        if (meta.code == 1) {
          this.show_return(meta.message);
          return;
        } else {
          App.WxService.showModal({
            title: '友情提示',
            content: meta.message,
            showCancel: !1,
          })
            .then(data => {
              this.setData({
                myvoucher: [],
                listytpe: { 'type': this.data.listytpe.type, 'p': 1, 'totalP': 1 }
              })
              this.getmyvoucher();
              this.HidePostpw();
            })
        }
      })
  },
  passChange(e) {
    let givepwd = e.detail.value;
    this.setData({ 'postpw.pw': givepwd })
  },
  usertype(e) {
    this.setData({
      'postpw.usertype': e.currentTarget.dataset.id
    })
  },
  //下拉刷新
  onPullDownRefresh() {
    //改变参数才能页面刷新
    this.setData({
      myvoucher: [],
      myvoucher0: [],
      'listytpe.p': 1,
      'listytpe.totalP': 1
    })
    this.getmyvoucher();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
})