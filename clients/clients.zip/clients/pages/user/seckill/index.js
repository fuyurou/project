const App = getApp()
Page({  
  data: {
    userinfo: null,
    orderlist: [],
    page:{p:1,totalnum:0,maxp:1},
    ShowTypes:1,
    orderinfo:{},
    payindex:0
  },
  onLoad(options) {
    //检查是否登录
    let url = "/pages/user/seckill/index";
    const userinfo = App.checkIsLogin(url);
    this.setData({ userinfo: userinfo })
    this.getmyorders();
  },
  onShow() {
    //检查是否登录
    let url = "/pages/user/seckill/index";
    const userinfo = App.checkIsLogin(url);
    this.setData({userinfo: userinfo})
  },
  getmyorders() {
    const page = this.data.page;
    if (page.p <= page.maxp){
      const url = App.HttpResource('/smallprogramapi/store/timelimitmyorder')
      url.queryAsync({
        'openid': this.data.userinfo.wx_openid,
        'p': page.p
      })
        .then(res => { 
          let listorder = res.data.mytimelimitorders; 
          if (listorder.length > 0) {
            for (var i = 0; i < listorder.length; i++) {
              listorder[i]['create_time'] = App.get_date_time(listorder[i]['posttime']);
            }
            const orderlist = this.data.orderlist
            const listorder1 = [...orderlist, ...listorder]
            this.setData({
              orderlist: listorder1,
              'page.p': page.p+1,
              'page.totalnum': res.data.pagearray.total,
              'page.maxp': res.data.pagearray.total_page
            })
            //console.log(listorder1);
          }
        }) 
    } 
  },
  gotoreceive(e){
    const id = parseInt(e.currentTarget.dataset.id);
    if(id>0){
      App.WxService.showModal({
        title: '提示',
        content: '请确认在收到商品后操作哦',
      })
        .then(data => data.confirm == 1 && this.gotoreceive1(id))
      // wx.showLoading({
      //   title: '领取中……',
      // })
      // const url = App.HttpResource('/smallprogramapi/store/timelimitorderover')
      // url.queryAsync({
      //   'openid': this.data.userinfo.wx_openid,
      //   'timelimitorderid': id
      // })
      //   .then(res => {
      //     if (res.data.meta.code == 0){
      //       wx.hideLoading();
      //       let orderlist = this.data.orderlist;
      //       for (var i = 0; i < orderlist.length; i++) {
      //         if (parseInt(orderlist[i]['id']) == id) {
      //           orderlist[i]['receive_status'] = '1';
      //         }
      //       }
      //       this.setData({
      //         orderlist: orderlist
      //       })
      //     }else{
      //       App.WxService.showModal({
      //         title: '提示',
      //         content: res.data.meta.message
      //       })
      //     }
      //   })
    }
  },
  gotoreceive1(id) {
    wx.showLoading({
      title: '领取中……',
    })
    const url = App.HttpResource('/smallprogramapi/store/timelimitorderover')
    url.queryAsync({
      'openid': this.data.userinfo.wx_openid,
      'timelimitorderid': id
    })
      .then(res => {
        if (res.data.meta.code == 0) {
          wx.hideLoading();
          let orderlist = this.data.orderlist;
          for (var i = 0; i < orderlist.length; i++) {
            if (parseInt(orderlist[i]['id']) == id) {
              orderlist[i]['receive_status'] = '1';
            }
          }
          this.setData({
            orderlist: orderlist
          })
        } else {
          App.WxService.showModal({
            title: '提示',
            content: res.data.meta.message
          })
        }
      })
  },
  gotoshow(e){
    const index = parseInt(e.currentTarget.dataset.id);
    const orderlist = this.data.orderlist;
    this.setData({
      orderinfo: orderlist[index],
      ShowTypes:2
    })
  },
  reBack(){
    this.setData({
      ShowTypes: 1
    })
  },
  gotopay(e){
    const index = parseInt(e.currentTarget.dataset.id);
    const orderinfo = this.data.orderlist[index];
    if (orderinfo.ispay == '1' || orderinfo.paymoney < 0 || parseInt(orderinfo.id)<1){
      App.WxService.showModal({
        title: '提示',
        content: '定单参数有误'
      })
      return
    }
    //进入发起支付
    App.gotopay(
      {
        'uid': orderinfo.uid,
        'title': orderinfo.goodstitle,
        'paymoney': orderinfo.paymoney,
        'table': 'timelimitorder',
        'id': orderinfo.id
      },
      this.payover,
	  this.payerror
    );
    this.setData({
      payindex: index
    })
  },
  payerror(){
    //支付错误时的操作
  },
  payover(){
    const payindex = this.data.payindex;
    let orderlist = this.data.orderlist;
    for (var i = 0; i < orderlist.length;i++){
      if (i == payindex){
        orderlist[i]['ispay']='1';
      }
    }
    this.setData({
      orderlist: orderlist
    })
  },
  //页面上拉触底事件的处理函数
  onReachBottom: function () {
    this.getmyorders();
  },
  //下拉刷新
  onPullDownRefresh() {
    //改变参数才能页面刷新
    this.setData({
      orderlist: [],
      'page.p': 1,
      'page.maxp': 1
    })
    this.getmyorders();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
})