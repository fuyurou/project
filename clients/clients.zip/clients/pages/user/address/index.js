const App = getApp()
Page({
  data: {
    userInfo: {},
    myaddress:[],
    toAddressEdit:false,
    addrid:0,
    editaddress:{}
  },
  onLoad(options) {
    this.checkLogin();
    this.showAddress();
  },
  onShow() {
    this.checkLogin();
  },
  checkLogin() {
    const myinfo = App.WxService.getStorageSync('user');
    if (!myinfo.wx_openid) {
      App.WxService.redirectTo('/pages/login/index', { url: '/pages/user/address/index' });
    } else {
      this.setData({
        userInfo: myinfo
      })
    }
  },
  showAddress() {
    const url = App.HttpResource('/smallprogramapi/store/getmyaddress')
    url.queryAsync({ 
      'openid': this.data.userInfo.wx_openid 
    })
      .then(res => {
        if(res.data.meta){
          const meta = res.data.meta;
          if (meta.code == 1){
            App.WxService.showModal({
              title: '友情提示',
              content: meta.message,
              showCancel: !1,
            })
          }
        }
        if (res.data.addresslist){
          const datas = res.data.addresslist;
          this.setData({
            myaddress: datas
          })
        } 
      })
  },
  //修改地址
  toAddressEdit(e){
    const myaddress = this.data.myaddress;
    let thisaddress = new Array();
    for (var i = 0; i < myaddress.length; i++) {
      if (myaddress[i]['id'] == e.currentTarget.dataset.id) {
        thisaddress = myaddress[i];
      }
    }
    this.setData({
      editaddress: thisaddress,
      toAddressEdit:true,
      addrid: e.currentTarget.dataset.id
    })
  },
  formSubmit: function (e) {
    let inputinfo = e.detail.value;
    if (!inputinfo.sex){
      App.WxService.showModal({
        title: '友情提示',
        content: '请选择性别！',
        showCancel: !1,
      })
      return;
    }
    if(!inputinfo.user){
      App.WxService.showModal({
        title: '友情提示',
        content: '请填写联系人姓名',
        showCancel: !1,
      })
      return;
    }
    if (!inputinfo.telphone) {
      App.WxService.showModal({
        title: '友情提示',
        content: '请填写电话',
        showCancel: !1,
      })
      return;
    }
    if (!inputinfo.address) {
      App.WxService.showModal({
        title: '友情提示',
        content: '请填写地址',
        showCancel: !1,
      })
      return;
    }
    let often = inputinfo.often==true ? '1' : '0';

    let inputarray = new Array();
    inputarray.user=inputinfo.user;
    inputarray.sex =inputinfo.sex;
    inputarray.telphone = inputinfo.telphone;
    inputarray.address = inputinfo.address;
    inputarray.often = often;
    inputarray.openid = this.data.userInfo.wx_openid;
    inputarray.addrid = this.data.addrid;

    //console.log(inputarray);
    const url = App.HttpResource('/smallprogramapi/store/addaddress')
    url.queryAsync(inputarray)
      .then(res => {//console.log(res);
        if (res.data.meta.code == 0) {          
          this.showAddress();
        } else {
          App.WxService.showModal({
            title: '友情提示',
            content: '新地址插入失败！',
            showCancel: !1,
          })
        }
        this.setData({
          editaddress: {},
          toAddressEdit: false,
          addrid: 0
        })
      }) 
  },
  toAddressDel(e){
    const id = e.currentTarget.dataset.id;
    App.WxService.showModal({
      title: '友情提示',
      content: '确定要删除当前地址吗？',
    })
      .then(data => data.confirm == 1 && this.AddressDel(id))
  },
  AddressDel(id){
    const url = App.HttpResource('/smallprogramapi/store/deladdress')
    url.queryAsync({
      openid : this.data.userInfo.wx_openid,
      addrid : id
    })
      .then(res => {//console.log(res);
        if (res.data.meta.code == 0) {
          this.showAddress();
        } else {
          App.WxService.showModal({
            title: '友情提示',
            content: '删除失败！',
            showCancel: !1,
          })
        }
      }) 
  },
  addNewAddress(){
    this.setData({
      editaddress: {},
      toAddressEdit: true,
      addrid: 0
    })
  },
  hidePostAddress(){
    this.setData({
      editaddress: {},
      toAddressEdit: false,
      addrid: 0
    })
  }
})