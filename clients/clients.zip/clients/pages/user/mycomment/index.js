const App = getApp()
Page({
  data: {
    userinfo:{},
    pageinfo:{'p':1,'maxp':1,'totalnum':0,'listdb':[]}
  },
  onLoad: function (options) {
    App.RefreshUserinfo(this.checkLogin)
  },
  onShow: function () {
  
  },
  checkLogin() {
    const myinfo = App.WxService.getStorageSync('user');
    if (!myinfo.wx_openid) {
      App.WxService.redirectTo('/pages/login/index', { url: '/pages/user/mycomment/index' });
    } else {
      this.setData({ userinfo: myinfo })
      this.getcomment();
    }
  },
  getcomment() {
    const pageinfo = this.data.pageinfo; //console.log(pageinfo);
    if (pageinfo.p <= pageinfo.maxp){
      const url = App.HttpResource('/smallprogramapi/store/getcommentall')
      url.queryAsync({ 'p': pageinfo.p, 'uid': this.data.userinfo.uid })
        .then(res => { 
          const datas = res.data 
          let comments = datas.commlistdb;
          if (comments){
            for (var i = 0; i < comments.length; i++) {
              comments[i]['commtime'] = App.get_date_time(comments[i]['commtime']);
            }
            const comments2 = [...pageinfo.listdb, ...comments];
            this.setData({
              'pageinfo.listdb': comments2,
              'pageinfo.p': pageinfo.p + 1,
              'pageinfo.maxp': datas.pagearray.total_page,
              'pageinfo.totalnum': datas.pagearray.total,
            })
            //console.log(comments2);
          }
          //console.log(datas);
        })
    }
  },
  //评论图片
  previewImage1(e) {
    const commlist = this.data.pageinfo.listdb;
    const index1 = e.currentTarget.dataset.index;
    const index = e.currentTarget.dataset.id;
    let urls = commlist[index]['pics_lg'];
	for (var i = 0; i < urls.length; i++){
      urls[i] = urls[i].replace('http://', "https://")
    }
    const current = urls[index1];
    App.WxService.previewImage({
      current: current,
      urls: urls,
    })
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.setData({
      'pageinfo.listdb': [],
      'pageinfo.p': 1,
      'pageinfo.maxp': 1,
      'pageinfo.totalnum': 0,
    })
    this.getcomment();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.getcomment();    
  }
})