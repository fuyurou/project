const App = getApp()
Page({
  data:{
    userInfo: {},
    mycodeimg:''
  },
  onLoad() {
    //刷新用户数据
    //App.RefreshUserinfo(this.checkLogin)
	},
  onShow() { 
    App.RefreshUserinfo(this.checkLogin)
  },
  checkLogin(){
    let myinfo = App.WxService.getStorageSync('user');
    if (!myinfo.wx_openid){
      App.WxService.redirectTo('/pages/login/index', { url: '/pages/user/index' });
    }else{
      myinfo.showpaymoney = 1;
      this.setData({
        userInfo: myinfo
      })
    }
  },
  //获取我的二维码
  getmycodeimg(){
    const url = App.HttpResource('/Smallprogramapi/Store/downloadqr')
    url.queryAsync({
      'openid': this.data.userInfo.wx_openid,
      'path': 'pages/forcode/index?foruid',
      'width':300
    })
      .then(res => {
        const datas = res.data;
        if (datas.meta.code==0){
          this.setData({
            mycodeimg: datas.data.myqrurl,
            'userInfo.codeimg': 1
          })
        }else{
          App.WxService.showModal({
            title: '提示',
            content: datas.data
          })
        }
      })
  },
  showMyCode(){
    if (this.data.mycodeimg == ''){
      this.getmycodeimg();
    }else{
      this.setData({
        'userInfo.codeimg': 1
      })
    }
  },
  HideMyCodeBox(){
    this.setData({
      'userInfo.codeimg': 0
    })
  },
  logout() {
    	App.WxService.showModal({
        title: '友情提示', 
        content: '确定要缓存数据吗？', 
      })
        .then(data => data.confirm == 1 && this.signOut())
  },
  signOut() {
    this.setData({
      userInfo:{}
    })
    wx.clearStorage() //清除数据缓存
    wx.clearStorageSync()
    // App.WxService.removeStorageSync('token');
    // App.WxService.removeStorageSync('user');
    // App.globalData.userInfo = null;
    setTimeout(function () {
      App.WxService.switchTab('/pages/index/index');
    }.bind(this), 300)    
  },
  //下拉检测用户登录
  onPullDownRefresh(){
    //刷新用户数据
    App.RefreshUserinfo(this.checkLogin);
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  }
})