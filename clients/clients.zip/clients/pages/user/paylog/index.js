const App = getApp()
Page({
  data: {
    userInfo:{},
    page: { p: 1, totalnum: 0, maxp: 1, listdb:[] }
  },
  onLoad: function (options) {
    App.RefreshUserinfo(this.checkLogin)
  },
  onShow: function () {
  
  },
  checkLogin() {
    let myinfo = App.WxService.getStorageSync('user');
    if (!myinfo.wx_openid) {
      App.WxService.redirectTo('/pages/login/index', { url: '/pages/user/paylog/index' });
    } else {
      this.setData({
        userInfo: myinfo
      })
      this.getpaylog();
    }
  },
  getpaylog() {
    const page = this.data.page;
    if (page.p <= page.maxp) {
      const url = App.HttpResource('/smallprogramapi/business/getmymoneyhis')
      url.queryAsync({
        'openid': this.data.userInfo.wx_openid,
        'p': page.p
      })
        .then(res => {
          const datas = res.data;
          let listdb = datas.hislistdb;
          const pagearray = datas.pagearray;
          for (var i = 0; i < listdb.length; i++){
            listdb[i]['time'] = App.get_date_time(listdb[i]['addtime']);
          }
          const listdb1 = [...page.listdb, ...listdb]
          this.setData({
            'page.p': page.p + 1,
            'page.maxp': pagearray.total_page,
            'page.totalnum': pagearray.total,
            'page.listdb': listdb1
          })
          //console.log(listdb);
        })
    }
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.setData({
      'page.p':1,
      'page.maxp': 1,
      'page.totalnum': 0,
      'page.listdb': []
    })
    this.getpaylog(); 
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.getpaylog();
  },
})