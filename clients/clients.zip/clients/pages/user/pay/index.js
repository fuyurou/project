const App = getApp()
Page({
  data: {
    userInfo:{},
    money:'',
    rechargeinfo:{'isset':0}
  },
  onLoad(options) {
    //this.checkLogin();
  },
  onShow() {
    App.RefreshUserinfo(this.checkLogin);
    this.getRechargeMoneyInfo();
  },
  checkLogin() {
    const myinfo = App.WxService.getStorageSync('user'); //console.log(myinfo);
    if (myinfo.wx_openid) {
      this.setData({
        userInfo: myinfo
      })
    } else {
      App.WxService.redirectTo('/pages/login/index', { url: '/pages/user/pay/index' });
    }
  },
  nomeyChange(e) {
    let money = this.checkmoney(e.detail.value);
    this.setData({
      money: money
    })
  },
  formSubmit: function (e) {
    const inputs = e.detail.value;
    const userInfo = this.data.userInfo;
    let money = parseFloat(inputs.money);
    if (!money){
      App.WxService.showModal({
        title: '提示！',
        content: '请输入充值金额',
      })
    }else{
      //进入发起支付
      App.gotopay(
        {
          'uid': userInfo.uid,
          'title': userInfo.nikename + '充值',
          'paymoney': money,
          'table': 'chargeorder',
          'id': userInfo.uid
        },
        this.payover,
		this.payerror
      );
    }
  },
  payover() {
    this.RefreshUserinfo();
  },
  payerror(){
    //支付错误时的操作
  },
  //获取商家充值赠送设置信息
  getRechargeMoneyInfo(){
    const url = App.HttpResource('/smallprogramapi/business/getrechargsetinfo');
    url.queryAsync()
      .then(res => {
        if (res.data.meta.code == 0) {
          this.setData({
            'rechargeinfo.isset':1,
            'rechargeinfo.arrays': res.data.data
          })
        } else {
          this.setData({
            'rechargeinfo.isset': 0
          })
        }
        //console.log(res.data.data);
      })
  },
  //刷新用户信息
  RefreshUserinfo() {
    const myinfo = App.WxService.getStorageSync('user');
    const url = App.HttpResource('/smallprogramapi/index/checkuserinfo');
    url.queryAsync({ 'token': App.WxService.getStorageSync('token'), 'openid': myinfo.wx_openid })
      .then(res => {
        if (res.data.meta.code == 0) {
          const userinfo = res.data.data;
          App.WxService.setStorageSync('user', userinfo);
          App.WxService.switchTab('/pages/user/index')
        } else {
          App.WxService.removeStorageSync('token');
          App.WxService.removeStorageSync('user');
          App.WxService.switchTab('/pages/index/index')
        }
      })
  },
  //金额输入限制
  checkmoney(money) {
    var regStrs = [
      ['^0(\\d+)$', '$1'], //禁止录入整数部分两位以上，但首位为0  
      ['[^\\d\\.]+$', ''], //禁止录入任何非数字和点  
      ['\\.(\\d?)\\.+', '.$1'], //禁止录入两个以上的点  
      ['^(\\d+\\.\\d{2}).+', '$1'] //禁止录入小数点后两位以上  
    ];
    for (var i = 0; i < regStrs.length; i++) {
      var reg = new RegExp(regStrs[i][0]);
      money = money.replace(reg, regStrs[i][1]);
    }
    return money;
  },
  //下拉检测用户登录
  onPullDownRefresh() {
    //刷新用户数据
    App.RefreshUserinfo(this.checkLogin);
    this.getRechargeMoneyInfo();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  }
})