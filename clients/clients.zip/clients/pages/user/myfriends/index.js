const App = getApp()
Page({
  data: {
    fromuid:0,
    userinfo:{},
    pageinfo:{'p':1,'maxp':1,'totalnum':0,'listdb':[],'fromuserinfo':[]}
  },
  onLoad: function (options) {
    if ('fromuid' in options) {
      this.setData({
        fromuid: options.fromuid
      })
    }
    App.RefreshUserinfo(this.checkLogin)
  },
  onShow: function () {
  
  },
  checkLogin() {
    const myinfo = App.WxService.getStorageSync('user');
    if (!myinfo.wx_openid) {
      App.WxService.redirectTo('/pages/login/index', { url: '/pages/user/myfriends/index' });
    } else {
      this.setData({ userinfo: myinfo })
      this.getfriends();
    }
  },
  getfriends() {
    const pageinfo = this.data.pageinfo; //console.log(pageinfo);
    if (pageinfo.p <= pageinfo.maxp){
      const url = App.HttpResource('/smallprogramapi/user/getmyfriends')
      url.queryAsync({ 'p': pageinfo.p, 'uid': this.data.userinfo.uid, 'fromuid': this.data.fromuid })
        .then(res => { 
          const datas = res.data 
          let userslistdb = datas.userslistdb;
          if (userslistdb[0]){          
            const userslistdb2 = [...pageinfo.listdb, ...userslistdb];
            this.setData({
              'pageinfo.listdb': userslistdb2,
              'pageinfo.p': pageinfo.p + 1,
              'pageinfo.maxp': datas.pagearray.total_page,
              'pageinfo.totalnum': datas.pagearray.total,
              'pageinfo.fromuserinfo': datas.fromuserinfo,
            })
            //console.log(userslistdb2);
          }
          //console.log(datas);
        })
    }
  },
 
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.setData({
      'pageinfo.listdb': [],
      'pageinfo.p': 1,
      'pageinfo.maxp': 1,
      'pageinfo.totalnum': 0,
    })
    this.getfriends();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.getfriends();    
  }
})