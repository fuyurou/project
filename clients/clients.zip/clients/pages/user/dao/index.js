const App = getApp()
Page({
  data: {
    userinfo: {},
    myorders:{
      p:1,
      totalnum:0,
      maxp:1,
      listdb:[]
    },
    helporders: {
      p: 1,
      totalnum: 0,
      maxp: 1,
      listdb: []
    },
    ShowType:1,
    orderinfo:{}
  },
  onLoad(options) {
    let url = "/pages/user/dao/index";
    const userinfo = App.checkIsLogin(url);
    this.setData({ userinfo: userinfo});
    this.getmyorders();
    this.helpmyorders();
  },
  ShowType(e) {
    const types = parseInt(e.currentTarget.dataset.id);
    this.setData({
      ShowType: types
    })
  },
  getmyorders() {
    const myorders = this.data.myorders;
    if (myorders.p <= myorders.maxp){
      const url = App.HttpResource('/smallprogramapi/store/kanjiamyorder')
      url.queryAsync({
        'openid': this.data.userinfo.wx_openid,
        'p': myorders.p
      })
        .then(res => { 
          const datas = res.data;
          let listorder = datas.kanjiaordercuthislist;
          if (listorder.length > 0) {
            for (var i = 0; i < listorder.length; i++) {
              listorder[i]['create_time'] = App.get_date_time(listorder[i]['posttime']);
            }
            const listorder1 = [...myorders.listdb, ...listorder]
            this.setData({
              'myorders.listdb': listorder1,
              'myorders.p': myorders.p + 1,
              'myorders.totalnum': datas.pagearray.total,
              'myorders.maxp': datas.pagearray.total_page
            })
            //console.log(listorder1);
          }
        })
    }  
  },
  helpmyorders(){
    const helporders = this.data.helporders;
    if (helporders.p <= helporders.maxp) {
      const url = App.HttpResource('/smallprogramapi/store/kanjiamycuthis')
      url.queryAsync({
        'openid': this.data.userinfo.wx_openid,
        'p': helporders.p
      })
        .then(res => { 
          const datas = res.data;
          let listorder = datas.mykanjiacuthis;
          if (listorder.length > 0) {
            for (var i = 0; i < listorder.length; i++) {
              listorder[i]['create_time'] = App.get_date_time(listorder[i]['posttime']);
            }
            const listorder1 = [...helporders.listdb, ...listorder]
            this.setData({
              'helporders.listdb': listorder1,
              'helporders.p': listorder1.p + 1,
              'helporders.totalnum': datas.pagearray.total,
              'helporders.maxp': datas.pagearray.total_page
            })
            //console.log(listorder1);
          }
        })
    }
  },
  //页面上拉触底事件的处理函数
  onReachBottom: function () {
    const ShowType = this.data.ShowType;
    if (ShowType==1){
      this.getmyorders();
    } else if (ShowType == 2) {
      this.helpmyorders();
    }
  },
  gotopay(e) {
    const index = parseInt(e.currentTarget.dataset.id);
    const orderinfo = this.data.myorders.listdb[index];
    if (orderinfo.pay_status == '1' || orderinfo.price_last < 0 || parseInt(orderinfo.id) < 1) {
      App.WxService.showModal({
        title: '提示',
        content: '定单参数有误'
      })
      return
    }
    //进入发起支付
    App.gotopay(
      {
        'uid': orderinfo.uid,
        'title': orderinfo.cut_remarks,
        'paymoney': orderinfo.price_last,
        'table': 'kanjiaorder',
        'id': orderinfo.id
      },
      this.payover,
	  this.payerror
    );
    this.setData({
      payindex: index
    })
  },
  payover() {
    const payindex = this.data.payindex;
    let myorders = this.data.myorders;
    for (var i = 0; i < myorders.listdb.length; i++) {
      if (i == payindex) {
        myorders.listdb[i]['pay_status'] = '1';
      }
    }
    this.setData({
      myorders: myorders
    })
  },
  payerror(){
    //支付错误时的操作
  },
  gotoshow(e) {
    const index = parseInt(e.currentTarget.dataset.id);
    const orderlist = this.data.myorders.listdb;
    this.setData({
      orderinfo: orderlist[index],
      ShowType: 3
    })
    console.log(orderlist[index]);
  },
  reBack() {
    this.setData({
      ShowType: 1
    })
  },  
  gotoreceive(e) {
    const id = parseInt(e.currentTarget.dataset.id);
    if (id > 0) {
      App.WxService.showModal({
        title: '提示',
        content: '请确认在收到商品后操作哦',
      })
        .then(data => data.confirm == 1 && this.gotoreceive1(id))
      // wx.showLoading({
      //   title: '领取中……',
      // })
      // const url = App.HttpResource('/smallprogramapi/store/kanjiaorderover')
      // url.queryAsync({
      //   'openid': this.data.userinfo.wx_openid,
      //   'kanjiaorderid': id
      // })
      //   .then(res => {
      //     if (res.data.meta.code == 0) {
      //       App.WxService.showModal({
      //         title: '提示',
      //         content: res.data.meta.message,
      //       })
      //         .then(data => {
      //           wx.hideLoading();
      //           let myorders = this.data.myorders;
      //           for (var i = 0; i < myorders.listdb.length; i++) {
      //             if (parseInt(myorders.listdb[i]['id']) == id) {
      //               myorders.listdb[i]['get_status'] = '1';
      //             }
      //           }
      //           this.setData({
      //             myorders: myorders
      //           }) 
      //         })
      //     } else {
      //       App.WxService.showModal({
      //         title: '提示',
      //         content: res.data.meta.message
      //       })
      //     }
      //   })
    }
  },
  gotoreceive1(id){
    wx.showLoading({
      title: '领取中……',
    })
    const url = App.HttpResource('/smallprogramapi/store/kanjiaorderover')
    url.queryAsync({
      'openid': this.data.userinfo.wx_openid,
      'kanjiaorderid': id
    })
      .then(res => {
        if (res.data.meta.code == 0) {
          App.WxService.showModal({
            title: '提示',
            content: res.data.meta.message,
          })
            .then(data => {
              wx.hideLoading();
              let myorders = this.data.myorders;
              for (var i = 0; i < myorders.listdb.length; i++) {
                if (parseInt(myorders.listdb[i]['id']) == id) {
                  myorders.listdb[i]['get_status'] = '1';
                }
              }
              this.setData({
                myorders: myorders
              })
            })
        } else {
          App.WxService.showModal({
            title: '提示',
            content: res.data.meta.message
          })
        }
      })
  },
  //下拉刷新
  onPullDownRefresh() {
    //改变参数才能页面刷新
    this.setData({
      'myorders.p': 1,
      'myorders.maxp': 1,
      'myorders.listdb': [],
      'helporders.p': 1,
      'helporders.maxp': 1,
      'helporders.listdb': [],
    })
    this.getmyorders();
    this.helpmyorders();
    wx.stopPullDownRefresh();  //下拉刷新后马上回弹
  },
})