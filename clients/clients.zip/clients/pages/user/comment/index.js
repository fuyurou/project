const App = getApp()
import config from '../../../etc/config'
var util = require('../../../helpers/util.js')
Page({
  data: {
    comment:{
      goodsid:'5',
      orderid:'4',
      fromkey:'timelimit',
      star:5,
      imgs:[{},{},{}],
      remarks:''
    },
    commentinfo:{},
    userinfo:{},
    goodsinfo:{},
    postFileUrl: config.basePath + '/smallprogramapi/store/uploadfile?openid=',
    configurl: config.basePath
  },
  onLoad: function (options) {
    this.setData({ 
      'comment.goodsid': options.goodsid,
      'comment.orderid': options.orderid,
      'comment.fromkey': options.fromkey
    })
    //检查是否登录
    let url = "/pages/user/comment/index";
    const userinfo = App.checkIsLogin(url);
    this.setData({
      userinfo: userinfo
    })
    this.getgoodsone();
  },
  onShow: function () {
    
  },
  getgoodsone(){
    const comment = this.data.comment;
    const url = App.HttpResource('/smallprogramapi/store/getgoodsone')
    url.queryAsync({ goodsid: comment.goodsid})
      .then(res => { 
        //console.log(res.data.goodsinfo);
        if(!res.data.goodsinfo){
          App.WxService.showModal({
            title: '提示',
            content: '没有相应的商品！',
          })
            .then(data => data.confirm == 1 && wx.navigateBack({ changed: true }))
        }else{
          this.setData({
            goodsinfo: res.data.goodsinfo
          })
          this.commentinfo();
        }
      })
  },
  commentinfo(){
    const comment = this.data.comment;
    const url = App.HttpResource('/smallprogramapi/store/getcommentother')
    url.queryAsync({
      'openid': this.data.userinfo.wx_openid,
      'goodsid': comment.goodsid,
      'orderid': comment.orderid,
      'fromkey': comment.fromkey
    })
      .then(res => {
        //console.log(res.data);
        if (res.data.data != null){
          let commentinfo = res.data.data[0]
          this.setData({
            commentinfo: commentinfo
          })
        }
      })
  },
  setstar(e) {
    const star = e.currentTarget.dataset.set;
    this.setData({
      'comment.star': star
    })
  },
  chooseImage(e) {
    let that = this;
    const index = parseInt(e.currentTarget.dataset.id);
    //console.log(index);
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        wx.showLoading({
          title: '正在上传',
        })
        let files = res.tempFilePaths;
        for (let i = 0; i < files.length; i++) {
          //that.postimgs(files[i],index);
          that.postPic(files[i], index);
        }
      },
      fail: function (e) {
        console.error(e)
      }
    })
  },
  postimgs(imgurl, index) {
    let comment = this.data.comment;
    for (let i = 0; i < comment.imgs.length; i++) {
      if (i == index) {
        comment.imgs[i]['ulr'] = imgurl;
      }
    }
    this.setData({
      comment: comment
    })
    //console.log(comment);
  },
  delimgs(e) {
    const index = parseInt(e.currentTarget.dataset.id);
    let comment = this.data.comment;
    for (let i = 0; i < comment.imgs.length; i++) {
      if (i == index) {
        comment.imgs[i]['ulr'] = '';
      }
    }
    this.setData({
      comment: comment
    })
  },
  /*** 上传图片 
     * 注意,每次上传图片都会执行一次onShow事件,尽量不要把事件写在onShow那里,
     * 并且上传事件,调试器的Network是看不到的.
     * ***********/
  postPic(filePath, index) {
    const that = this;
    wx.uploadFile({
      url: that.data.postFileUrl + this.data.userinfo.wx_openid,
      filePath: filePath,
      name: 'photo',
      success: function (res) {
        wx.hideLoading();
        let datas = JSON.parse(res.data);
        if (datas.data.picurl) {
          that.postimgs(datas.data.picurl, index);
        }
      },
      fail: function (e) {
        //util.showModel('上传图片失败', '')
        return;
      }
    })
  },
  handleMsgChange(e) {
    // this.setData({
    //   'comment.remarks': e.detail.value
    // })
    let content = e.detail.value;
    var num = this.strlen(content);
    if (num <= 160) {console.log('aaa');
      this.setData({ 'comment.remarks': content })
    } else {
      App.WxService.showModal({
        title: '提示',
        content: '评论内容不以超出80个字',
        showCancel: !1,
      })
      this.setData({ 'comment.remarks': this.data.comment.remarks })
    }
  },
  strlen(str) {
    var len = 0;
    for (var i = 0; i < str.length; i++) {
      var c = str.charCodeAt(i);
      //单字节加1 
      if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
        len++;
      }
      else {
        len += 2;
      }
    }
    return len;
  },
  formSubmit: function (e) {
    const that = this;
    const comment = this.data.comment;
    if (comment.remarks == ''){
      util.showModel('提示', '请填写商品评价内容')
      return
    }
    if (parseInt(comment.orderid) < 1 || parseInt(comment.goodsid) < 1 || comment.fromkey == ''){
      util.showModel('提示', '评价参数有误')
      return
    }
    let lisimgs = new Array();
    var j = 0;
    for (let i = 0; i < comment.imgs.length; i++) {
      if (comment.imgs[i]['ulr']) {
        lisimgs[j] = comment.imgs[i]['ulr'];
        j++;
      }
    }
    const url = App.HttpResource('/smallprogramapi/store/postcommentother')
    url.queryAsync({
      'openid': this.data.userinfo.wx_openid,
      'star': comment.star,
      'pics': lisimgs.join('|'),
      'remarks': comment.remarks,
      'goodsid': comment.goodsid,
      'fromkey': comment.fromkey,
      'orderid': comment.orderid
    })
      .then(res => {
        if(res.data.meta.code == 0){
          util.showModel('提示', '商品评价成功')
          that.commentinfo();
        }else{
          util.showModel('提示', res.data.meta.message)
        }
       })
  },
  //评论图片
  previewImage1(e) {
    let imgs = this.data.commentinfo.pics_lg;
    const index = parseInt(e.currentTarget.dataset.id);
    App.WxService.previewImage({
      current: imgs[index],
      urls: imgs,
    })
  },
})