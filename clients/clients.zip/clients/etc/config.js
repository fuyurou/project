export default {
	 basePath: 'https://uqj1539853469.smallprogram.kingmembers.com',
	 domain: 'https://uqj1539853469.smallprogram.kingmembers.com', 
}