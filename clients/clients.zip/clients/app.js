import WxValidate from './assets/plugins/wx-validate/WxValidate'
import WxService from './assets/plugins/wx-service/WxService'
import HttpResource from './helpers/HttpResource'
import HttpService from './helpers/HttpService'
import __config from './etc/config'

App({
	getUserInfo(liveData) {
    let info = null;
    if (liveData == true) {
      let token = this.WxService.getStorageSync('token');
      let myinfo = this.WxService.getStorageSync('user');
      let url = this.HttpResource('/smallprogramapi/index/checkuserinfo');
      return url.queryAsync({ 'token': token, 'openid': myinfo.wx_openid })
        .then(res => {
          const data = res.data
          info = data.data;
          this.globalData.userInfo = info;
          return info;
        })
    }else{
      info = this.WxService.getStorageSync('user');
      this.globalData.userInfo = info;
      return info;
    }
	},
  checkLogin(url) {
    this.getUserInfo(true).then(info => {
      if (info) {
        return info;
      } else {
        this.WxService.redirectTo('/pages/login/index?url=' + escape(url));
      }
    });
  },
  checkIsLogin(url){
    const userinfo = this.WxService.getStorageSync('user');
    if (userinfo.wx_openid){
      return userinfo;
    }else{
      this.WxService.redirectTo('/pages/login/index?url=' + escape(url));
    }
  },
	globalData: {
		userInfo: null
	},
  getToken(){
    return this.WxService.getStorageSync('token');
  },
  //刷新用户信息
  RefreshUserinfo(cb) {
    const myinfo = this.WxService.getStorageSync('user');
    const url = this.HttpResource('/smallprogramapi/index/checkuserinfo');
    url.queryAsync({ 'token': this.WxService.getStorageSync('token'), 'openid': myinfo.wx_openid })
      .then(res => {
        if (res.data.meta.code == 0) {
          const userinfo = res.data.data;
          this.WxService.setStorageSync('user', userinfo);
        } else {
          this.WxService.removeStorageSync('token');
          this.WxService.removeStorageSync('user');
        }
        cb();
      })
  },
  //时间格式显示
  format_time(time) {
    var second = Math.floor(time);// 秒数
    var day = this.fill_zero_prefix(Math.floor(second / 86400));// 天
    var hr = this.fill_zero_prefix(Math.floor((second - day * 86400) / 3600));// 小时位
    var min = this.fill_zero_prefix(Math.floor((second - day * 86400 - hr * 3600) / 60));// 分钟位    
    var sec = this.fill_zero_prefix((second - day * 86400 - hr * 3600 - min * 60));// 秒位
    return day + "天" + hr + "时" + min + "分" + sec + '秒';
  },
  format_time1(time) {
    var second = Math.floor(time);// 秒数
    var day = this.fill_zero_prefix(Math.floor(second / 86400));// 天
    var hr = this.fill_zero_prefix(Math.floor((second - day * 86400) / 3600));// 小时位
    var min = this.fill_zero_prefix(Math.floor((second - day * 86400 - hr * 3600) / 60));// 分钟位    
    var sec = this.fill_zero_prefix((second - day * 86400 - hr * 3600 - min * 60));// 秒位
    return { 'day': day, 'hr': hr, 'min': min, 'sec': sec };
  },
  // 位数不足补零
  fill_zero_prefix(num) {
    return num < 10 ? "0" + num : num
  },
  get_date_time(time) {
    time = parseInt(time);
    var date = new Date(time * 1000);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
    var Y = date.getFullYear() + '-';
    var M = this.fill_zero_prefix(date.getMonth() + 1) + '-';
    var D = this.fill_zero_prefix(date.getDate()) + ' ';
    var h = this.fill_zero_prefix(date.getHours()) + ':';
    var m = this.fill_zero_prefix(date.getMinutes()) + ':';
    var s = this.fill_zero_prefix(date.getSeconds());
    return Y + M + D + h + m + s;
  },
	renderImage(path) {
        if (!path) return ''
        if (path.indexOf('http') !== -1) return path
        return `${this.__config.domain}${path}`
    },
	WxValidate: (rules, messages) => new WxValidate(rules, messages), 
	HttpResource: (url, paramDefaults, actions, options) => new HttpResource(url, paramDefaults, actions, options).init(), 
	HttpService: new HttpService({
		baseURL: __config.basePath,
	}), 
	WxService: new WxService, 
	__config, 

  /**支付公共函数**/
  //发起支付
  gotopay(orders,cb,cd) {
    let paymoney = parseFloat(orders.paymoney);
    if (paymoney > 0 && orders.id != '') {
      const url = this.HttpResource('/smallprogramapi/weixin/pay')
      url.queryAsync({
        'uid': orders.uid,
        'title': orders.title,
        'pricetotal': paymoney,
        'table': orders.table,
        'tableid': orders.id
      })
        .then(res => {
          const datas = res.data;
          if (datas.meta.code == 0) {
            const paydata = datas.data;
            this.pay(paydata, cb, cd);
          } else {
            this.WxService.showModal({
              title: '出错了!',
              content: datas.meta.message,
            })
              .then(data => {
                cd();
              })
          }
        })
    }else{
      this.WxService.showModal({
        title: '出错了!',
        content: '支付参数有误',
      })
        .then(data => {
          cd();
        })
    }
  },
  //操作支付
  pay(result, cb, cd) {
    let that = this;
    wx.requestPayment({
      'timeStamp': result.timeStamp,
      'nonceStr': result.nonceStr,
      'package': result.package,
      'signType': result.signType,
      'paySign': result.paySign,
      success: function (res) {
        wx.showLoading({
          title: '支付成功',
        })
        that.paystatus(result.ordersn, cb);
      },
      fail: function (res) {
        that.WxService.showModal({
          title: '出错了!',
          content: '支付失败',
        })
          .then(data => {
            cd();
          })
      }
    })
  },
  //结束支付
  paystatus(ordersn,cb) {
    const that = this;
    const userinfo = that.WxService.getStorageSync('user');
    const url = that.HttpResource('/smallprogramapi/weixin/paystatus')
    url.queryAsync({
      'ordersn': ordersn,
      'openid': userinfo.wx_openid
    })
      .then(res => {
        if (res.data.meta.code == 0) {
          wx.hideLoading();
          that.WxService.showModal({
            title: '提示!',
            content: '确认支付成功',
          })
            .then(data => {
              cb();
            })
        } else {
          setTimeout(function () {
            that.paystatus(ordersn, cb);
          }, 500)
        }
      })
  },
})